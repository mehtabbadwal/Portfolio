# Screen Building Reference

Detailed guidance for building hi-fi screens and wireframes with component
discipline, layer hygiene, device accuracy, and annotated interaction flows.

---

## Table of Contents
1. Pre-Build Checklist
2. Component Instance Rules
3. Layer Naming System
4. Device Frames and Component Scale
5. Missing Component Audit Format
6. Annotation System
7. Prototype Flow Notation

---

## 1. Pre-Build Checklist

Before placing anything on the canvas:

- [ ] Confirm device target (mobile / tablet / desktop)
- [ ] Read the component library — know what exists before building
- [ ] Identify the screen's single primary purpose
- [ ] Confirm the screen state (default / empty / loading / error / success / edge case)
- [ ] Know the entry point (what triggers this screen) and exit points (what can a user do next)

---

## 2. Component Instance Rules

### The Rule
**If a pattern exists in the component library, use an instance. Always.**
Never draw a button, input, card, badge, avatar, nav bar, modal, tag, toast, or
any recognized component from raw shapes.

### Applying Properties Correctly

#### Variant Properties
Control the visual form of the component.

| Property | What to check |
|---|---|
| Type | Primary / Secondary / Tertiary / Destructive etc. |
| Size | Small / Medium / Large — must match device tier |
| State | Default, Hover, Active, Disabled, Loading, Error, Success |
| Orientation | Horizontal / Vertical where applicable |

Never leave a component in its default state if the context requires a different one.
Example: a disabled submit button while a form is incomplete MUST use the Disabled variant.

#### Boolean Properties
Control structural visibility inside the component.

| Pattern | Correct approach |
|---|---|
| Add a leading icon | Toggle `Has Leading Icon = true`, then swap the icon instance |
| Remove a subtitle | Toggle `Has Subtitle = false` — never manually hide layers |
| Show a badge | Toggle `Has Badge = true`, update badge text override |
| Show loading state | Toggle `Is Loading = true` or switch to Loading variant |

Never hide internal layers of a component manually. Always use the Boolean property.
If the Boolean property doesn't exist yet → add it to the Missing Components list.

#### Text Overrides
Every text layer in every component instance must use realistic content.

| Replace | With |
|---|---|
| "Button" | The actual CTA label |
| "Label" | The actual field label |
| "Lorem ipsum" | Representative realistic content |
| "Title" | The actual screen or card title |
| "Username" | A realistic name (e.g. "Sarah Chen") |
| "Description" | 1–2 sentences of real or representative body copy |

Text length must reflect real use:
- Short labels: test at shortest and longest expected value
- Body copy: use content that fills approximately the expected line count

#### Nested Instance Swaps
When a component contains a nested icon, avatar, or image:
- Select the nested instance in the layers panel
- Use the instance swap panel to replace with the correct asset
- Never detach and manually edit — always swap

---

## 3. Layer Naming System

### Mandatory Rules
- Every layer must have a name. "Frame 47", "Group 3", "Rectangle 12" are never acceptable.
- Name layers BEFORE grouping or framing them.
- Use Title Case for screen and section names.
- Use kebab-case for icons and tokens.

### Naming Patterns

```
SCREENS
[Screen Name] — [State]
Examples:
  Dashboard — Default
  Dashboard — Empty State
  Onboarding — Step 2 of 4
  Settings — Danger Zone
  Project Detail — Error

SECTIONS (top-level frames within a screen)
  Header
  Sidebar
  Content
  Footer
  Nav Bar
  Tab Bar
  Action Bar
  Modal Overlay
  Drawer

COMPONENT INSTANCES
Use the component path as the layer name:
  Button/Primary/Medium
  Input/Text/Default
  Card/Project/Default
  Avatar/Medium
  Badge/Status/Success

GROUPS AND FRAMES
Describe the content or purpose:
  User Info
  Filter Row
  Stats Overview
  Action Buttons
  Empty State
  Error Message

TEXT LAYERS
Name by role or leading words:
  Page Title
  Section Heading
  Body Copy
  Helper Text
  Error Message
  "John Appleseed" (for name fields, use actual content as layer name)

IMAGES AND MEDIA
  Project Thumbnail
  Avatar — Sarah Chen
  Cover Image
  Icon — chevron-right
  Illustration — Empty State

DIVIDERS AND DECORATIVE
  Divider (always, never "Line 4")
  Background Texture
  Gradient Overlay

ANNOTATION LAYERS
  Annotations (locked)
  Annotation — #1 Login Button
  Annotation — #2 Forgot Password
```

### Grouping Rules
- Use **frames** (not groups) for layout containers — frames support auto-layout
- Use **groups** only for purely visual combinations (icon + label that move together)
- Lock the Annotations frame so it can't be accidentally selected or moved
- Mark non-printing layers with a `_` prefix: `_Annotations`, `_Guides`

---

## 4. Device Frames and Component Scale

### Frame Sizes

| Device | Frame Width | Frame Height | Notes |
|---|---|---|---|
| iPhone 14 / 15 | 390px | 844px | Primary mobile target |
| iPhone SE | 375px | 667px | Smaller mobile edge case |
| Android (standard) | 360px | 800px | Android baseline |
| iPad (portrait) | 768px | 1024px | Tablet baseline |
| iPad Air | 820px | 1180px | Larger tablet |
| MacBook / Web | 1440px | 900px | Primary desktop target |
| Desktop HD | 1920px | 1080px | Large screen |
| Desktop Dense | 1280px | 800px | Compact desktop |

### Component Size by Device

| Device | Buttons & Inputs | Body Text | Icon Size | Min Touch |
|---|---|---|---|---|
| Mobile | 48px height | 16px | 24px | 44×44px |
| Tablet | 44–48px | 15–16px | 22–24px | 44×44px |
| Desktop | 40px height | 14px | 20px | 32px OK |
| Desktop Dense | 36px height | 13px | 16–20px | 32px OK |

### Device-Appropriate Patterns

#### Mobile
- Bottom navigation bar (5 items max)
- Full-width primary buttons
- Single-column content
- No hover states — use active/pressed states instead
- Thumb-zone rule: primary actions in the bottom 60% of screen
- Avoid right-click or keyboard-shortcut dependent interactions
- Sheet overlays instead of modals for confirmations
- Swipe gestures for common actions (delete, archive)

#### Tablet
- Side navigation or persistent tab bar
- 2-column layouts for content-heavy screens
- Cards can be side-by-side (not stacked)
- Touch targets still 44px minimum
- Popovers instead of bottom sheets where appropriate

#### Desktop
- Left sidebar navigation (240px expanded / 64px collapsed)
- Multi-column layouts (2–4 columns)
- Hover states on all interactive elements
- Higher information density acceptable
- Right-click context menus for power users
- Keyboard shortcut hints visible in tooltips
- Sticky headers for long tables / lists

---

## 5. Missing Component Audit

Run this audit after completing every screen, before presenting to the user.

### How to Audit
Scan the screen layer by layer. For each element that is:
- A raw shape (rectangle, frame) styled to look like a component
- A detached component instance
- A manually drawn pattern that matches a UI convention

→ Add it to the Missing Components list.

### Output Format

```
⚠️ MISSING COMPONENTS — [Screen Name]

[n] elements were built without library components. Review and decide:

#1  [Element description]
    Location: [Section name, e.g. "Card Header"]
    Suggested name: [ComponentName/Variant/Size]
    Dimensions: [w × h]px
    Used on this screen: [n] times
    Recommendation: [Create as component / Leave as one-off]

#2  [Element description]
    Location: [Section name]
    Suggested name: [ComponentName/Variant/Size]
    Dimensions: [w × h]px
    Used on this screen: [n] times
    Recommendation: [Create as component / Leave as one-off]

RECOMMENDATION LOGIC:
→ Used 2+ times on this screen: strongly recommend creating as component
→ Appears in 2+ screens: must become a component
→ Used once, unique to this screen: leave as one-off unless it's a universal pattern
```

If all elements are instances: output `✅ All elements use library components. No missing components found.`

---

## 6. Annotation System

Annotations explain interaction behavior for handoff, stakeholder review, and
prototype documentation. They live on a locked layer and accompany every screen
that has interactive elements.

### Annotation Layer Setup
- Layer name: `_Annotations` (locked, non-printing)
- Chip style: white fill, `rgba(0,0,0,0.12)` border 1px, 11px/Regular text, 4px radius
- Number chips: 16×16px circle, brand color fill, white text
- Connecting line: 1px, `rgba(0,0,0,0.3)`, no arrow (keep it clean)
- Place chips outside the screen frame, connected to the element

### Annotation Types and Format

#### Type 1: Interactive Element
```
[#n] [Element Name]
Trigger: tap | click | long press | swipe left | swipe right | hover
Action: [describe what happens in plain language]
Destination: → [Screen name] | [Describes in-screen change]
```

Examples:
```
[#1] Login Button
Trigger: tap
Action: Validates form. If valid, authenticates user.
Destination: → Dashboard — Default

[#2] Forgot Password Link
Trigger: tap
Action: Opens password reset modal over current screen.
Destination: → Reset Password Modal (overlay)

[#3] Project Card
Trigger: tap
Action: Navigates to project detail view with slide-in transition.
Destination: → Project Detail — Default
```

#### Type 2: Conditional / State Change
```
[#n] [Element Name]
Condition: [when this is true]
Shows: [what becomes visible]
Hides: [what becomes hidden]
Transition: [instant | fade | slide | expand]
```

Example:
```
[#4] Search Input
Condition: User begins typing
Shows: Search Results Dropdown, Clear (×) button
Hides: Placeholder text
Transition: fade in (150ms)
```

#### Type 3: Form Validation
```
[#n] [Field Name]
Validates: [what rule is checked]
Error state: [error message text]
Success state: [visual confirmation if applicable]
```

#### Type 4: Flow Note (decision point)
```
FLOW NOTE: [Plain language description of branching logic or edge case]
```

Example:
```
FLOW NOTE: If user is on a free plan and clicks "Export", show upgrade
prompt instead of downloading. Pro users download immediately.
```

### Written Annotations Summary Output

After annotating, always output this written summary in the conversation:

```
SCREEN ANNOTATIONS: [Screen Name]
Device: [Mobile / Tablet / Desktop]
Screen state: [Default / Empty / Error / etc.]

━━━ INTERACTIVE ELEMENTS ([n] total) ━━━
#1  [Element] — [Trigger] → [Action] → [Destination]
#2  [Element] — [Trigger] → [Action] → [Destination]
...

━━━ CONDITIONAL STATES ([n] total) ━━━
#n  [Element] — [Condition] → Shows [X], Hides [Y]
...

━━━ FLOW NOTES ━━━
- [Any branching logic, edge cases, or design decisions worth flagging]

━━━ MISSING COMPONENTS ━━━
[Result of component audit, or ✅ All components accounted for]
```

---

## 7. Prototype Flow Notation

When building a multi-screen prototype (not just a single screen):

### Flow Map Header
Before building any screen, output a flow map:

```
FLOW: [Flow Name]
Entry: [What triggers this flow]
Screens:
  1. [Screen Name] — [Purpose]
  2. [Screen Name] — [Purpose]
  3. [Screen Name] — [Purpose]
Exits:
  - Success: → [Destination]
  - Cancel: → [Destination]
  - Error: → [Destination]
```

### Screen Connection Notation
In the written annotations summary, end each screen with:

```
FROM THIS SCREEN:
→ [Action / Element] leads to [Screen n: Screen Name]
→ [Action / Element] leads to [Screen n: Screen Name]
← Back / Cancel returns to [Screen Name]
```

### States to Build Per Screen
For each screen in a flow, build these variants as separate frames:

| State | When to build |
|---|---|
| Default | Always |
| Loading | Any screen that fetches data |
| Empty state | Any list, table, or content container |
| Error state | Any form or data-dependent screen |
| Success state | Any form submission or destructive action |
| Partial (edge case) | Only if the flow logic requires it |

Label each frame variant: `[Screen Name] — [State]` so the flow is readable
at a glance from the Figma canvas.
