# Platform Design Guidelines

When building for a specific platform, platform conventions take priority over
generic UI preferences. Users have muscle memory for their platform. Breaking
conventions creates friction even when the design looks good.

Read the relevant section before building any native mobile or desktop UI.

---

## Table of Contents
1. How to Choose the Right Platform Guidelines
2. Apple Human Interface Guidelines (HIG) — iOS / iPadOS / macOS
3. Google Material Design 3 — Android / Web
4. Microsoft Fluent Design — Windows / Web / M365
5. Cross-Platform Considerations
6. When to Deviate from Platform Guidelines

---

## 1. How to Choose the Right Platform Guidelines

| Context | Apply |
|---|---|
| iOS app, iPhone/iPad | Apple HIG |
| Android app | Material Design 3 |
| macOS desktop app | Apple HIG (macOS section) |
| Windows desktop app | Fluent Design |
| Web app (cross-platform) | Material or Fluent as baseline, then diverge |
| React Native / Flutter | Read both HIG and Material; flag conflicts |
| Enterprise desktop (M365 context) | Fluent Design |

When building a cross-platform product, pick ONE platform as the primary
reference and adapt for the other. Never mix navigation paradigms.

---

## 2. Apple Human Interface Guidelines (HIG)

Source: developer.apple.com/design/human-interface-guidelines

### Core Philosophy
- **Clarity:** Text legible at all sizes. Icons precise and lucid. Adornment minimal.
- **Deference:** UI helps users understand and interact with content — never competes with it.
- **Depth:** Visual layers and realistic motion convey hierarchy and position.

### Navigation Paradigms

**iOS — use one, not a hybrid:**

| Pattern | Use when |
|---|---|
| Tab bar | 3–5 distinct top-level destinations, equal importance |
| Navigation stack (push/pop) | Hierarchical content, drilldown flows |
| Modal (sheet) | Task completion that doesn't belong in the main flow |
| Split view | iPad/macOS: master-detail, settings panels |

Tab bar: always visible, 5 items max, icon + label, active tab highlighted.
Never hide the tab bar when scrolling on iOS — it destroys orientation.

**Navigation stack rules:**
- Back button always top-left, shows previous screen title or "Back"
- Swipe-from-left-edge to go back — never block this gesture
- Large title on root screens; standard title on drill-down screens

### iOS Component Rules

**Buttons:**
- System button style by default (tintColor)
- Filled button: primary CTA only
- Corner radius: system default is continuous curve (squircle), not circular
- Minimum tappable area: 44×44pt — add invisible padding rather than enlarging visually

**Inputs and Forms:**
- Grouped table view style for settings-type forms (inset rounded sections)
- Keyboard dismissal: tap outside field OR drag-down gesture
- Always account for keyboard pushing content — use `KeyboardAvoidingView`

**Lists and Tables:**
- UITableView patterns: plain, grouped, inset grouped
- Swipe actions: leading = positive (flag, pin), trailing = destructive (delete)
- Pull-to-refresh on scrollable content

**Sheets and Modals:**
- Bottom sheet (half or full): for tasks initiated from the current screen
- Full-screen modal: for self-contained flows (camera, compose)
- Detented sheet: allow user to drag between sizes (iOS 16+)
- Always include a drag indicator at the top of sheets

**Alerts:**
- 2 buttons max in alerts: one per line (preferred) or side by side for short labels
- Destructive action on the left for side-by-side layout (least accessible position)
- Never use alerts for non-critical information — use banners or toasts instead

### iOS Typography
- System font: SF Pro (automatic with system label styles)
- Dynamic Type: ALWAYS support — users who increase text size deserve a working UI
- Text styles to use: largeTitle, title1–3, headline, body, callout, subheadline, footnote, caption1–2

### iOS Color
- Always use semantic system colors (label, secondaryLabel, systemBackground, etc.)
- These adapt to light/dark mode and accessibility settings automatically
- Accent: one tintColor per app — applied system-wide
- Avoid pure black backgrounds in dark mode — use systemBackground (off-black)

### iOS Gestures (respect these, never block them)
- Swipe left from edge: back navigation
- Swipe down on modal: dismiss
- Long press: context menu (UIContextMenu)
- Pinch: zoom in supported content types
- Pull down from top: Notification Center (never intercept)

### macOS Specifics
- Menu bar: app-level actions live here, not in the window
- Toolbar: document or view-specific actions
- Sidebar: 220–260px, collapsible, source list style
- Window controls: red/yellow/green top-left (never move or hide)
- Right-click always available: provide context menus for all primary actions
- Keyboard shortcuts: document all with ⌘ modifier, show in menus

### HIG Accessibility Essentials
- VoiceOver: every element needs a meaningful accessibility label
- Dynamic Type: layouts must not break at any text size (xxxLarge)
- Reduce Motion: respect `UIAccessibility.isReduceMotionEnabled`
- Increase Contrast: respect `UIAccessibility.isDarkerSystemColorsEnabled`
- Touch Accommodations: ensure all targets work with assistive touch

---

## 3. Google Material Design 3

Source: m3.material.io

### Core Philosophy
- **Adaptive:** works across screen sizes, platforms, and use cases
- **Personal:** color extracted from user wallpaper (dynamic color), expressive theming
- **Accessible:** built with inclusive design from the ground up

### The Material You Color System

Material 3 uses a dynamic tonal palette derived from a seed color:

| Role | Use |
|---|---|
| Primary | Key components, active states, primary buttons |
| On Primary | Text/icons on primary containers |
| Primary Container | Less prominent primary surfaces |
| Secondary | Complementary accent, filters, chips |
| Tertiary | Contrasting accent, highlighted sections |
| Error | Error states only |
| Surface | Backgrounds, cards, sheets |
| Outline | Borders, dividers |

**Tone:** Material 3 uses lightness tones (0–100) not arbitrary hex values.
When defining a custom palette, generate a full tonal palette (5, 10, 20, 30,
40, 50, 60, 70, 80, 90, 95, 99, 100) and map roles to tones.

### Navigation Paradigms

**Mobile:**
- Navigation bar: 3–5 destinations, persistent at bottom, icon + optional label
- Navigation drawer: for 5+ destinations or secondary navigation
- Bottom sheet: for contextual actions, not primary navigation

**Tablet / Desktop:**
- Navigation rail: vertical, left-side, icons only or icons + labels
- Navigation drawer: persistent on large screens, modal on mobile
- Top app bar + tabs: for content-heavy apps with flat hierarchy

### Material 3 Components

**Buttons (5 types — use the hierarchy):**
1. **Filled:** highest emphasis — single primary action per screen
2. **Filled Tonal:** medium-high — secondary primary action
3. **Outlined:** medium — important but not primary
4. **Elevated:** medium — alternatives in flat layouts
5. **Text:** lowest — least critical, tertiary actions

FAB (Floating Action Button): ONE per screen, primary action only.
Extended FAB: use when label adds essential context.

**Text Fields:**
- Filled (default): cleaner in dense UIs
- Outlined: when field needs to stand out on a colored surface
- Never mix filled and outlined in the same form

**Cards:**
- Elevated: default surface + shadow
- Filled: surface + tonal background, no shadow
- Outlined: border, no shadow or elevation

**Chips (4 types):**
- Assist: shortcuts for tasks
- Filter: toggle to filter content (show selected state clearly)
- Input: represent items added (removable)
- Suggestion: dynamic suggestions (search, autocomplete)

### Material Motion System

Material uses the **M3 Easing and Duration** system:

| Token | Easing | Duration | Use |
|---|---|---|---|
| Emphasized | cubic-bezier(0.2, 0, 0, 1) | 500ms | Large spatial transitions |
| Emphasized Decelerate | cubic-bezier(0.05, 0.7, 0.1, 1) | 400ms | Elements entering |
| Emphasized Accelerate | cubic-bezier(0.3, 0, 0.8, 0.15) | 200ms | Elements exiting |
| Standard | cubic-bezier(0.2, 0, 0, 1) | 300ms | General transitions |
| Standard Decelerate | cubic-bezier(0, 0, 0, 1) | 250ms | Entering |
| Standard Accelerate | cubic-bezier(0.3, 0, 1, 1) | 200ms | Exiting |

Container transform: shared element transitions between screens (use for cards → detail).

### Material 3 Elevation

Elevation in M3 is expressed as **tonal surface color**, not shadow:
- Level 0: Surface (base)
- Level 1: +5% primary tint
- Level 2: +8% primary tint (navigation drawer, menus)
- Level 3: +11% primary tint (FAB)
- Level 4: +12% primary tint (app bar)
- Level 5: +14% primary tint (dialogs, modals)

Shadows are secondary reinforcement — not the primary elevation signal.

### Material Accessibility
- Touch target: 48×48dp minimum (note: dp not px)
- Contrast: 4.5:1 for body text, 3:1 for large text and UI components
- Screen reader: contentDescription on all interactive elements
- Focus order: logical, matches reading order
- TalkBack gestures: don't intercept swipe-right/swipe-left (reading gestures)

---

## 4. Microsoft Fluent Design

Source: fluent2.microsoft.design

### Core Philosophy
- **Familiar:** feels at home on Windows and in Microsoft 365
- **Effortless:** tasks complete with less cognitive load
- **Inclusive:** accessible to all, adaptable to every context

### Fluent 2 Design Tokens

Fluent 2 is fully token-based. Core token categories:
- **Color:** brand ramp (Brand10–Brand160), neutral ramp (Grey2–Grey254), semantic tokens
- **Typography:** type ramp from Caption2 (10px) to Display (68px)
- **Spacing:** 2, 4, 6, 8, 10, 12, 16, 20, 24, 32, 40, 48, 64, 80, 120px
- **Border radius:** 0, 2, 4, 6, 8, 12, 16, 20, 24px
- **Shadow:** shadow2, shadow4, shadow8, shadow16, shadow28, shadow64

### Navigation Paradigms

**Web / Teams-style apps:**
- Left nav rail: icons + labels, collapsible
- Breadcrumbs: for deep hierarchies (3+ levels)
- Pivot / Tab: for content switching within a page
- Command bar: top-aligned toolbar for primary actions

**Windows desktop:**
- NavigationView: left rail that converts to hamburger on narrow widths
- Breadcrumb bar: always visible for deep content trees
- Ribbon: for complex document-editing apps (Office pattern)
- Status bar: bottom, persistent context information

### Fluent Components (Key Rules)

**Buttons:**
- Primary: filled, one per section
- Standard (Default): outlined or subtle
- Subtle: minimal chrome, for toolbars
- Transparent: ghost, lowest emphasis
- Always use `size="medium"` (32px) as default; `size="large"` (40px) for primary CTAs

**Input (TextField):**
- Underline style by default on Windows native
- Outline style for web/web-embedded contexts
- Hint text (not label) appears inside until typed — BUT always include a label above for accessibility

**Dialogs:**
- Confirmation dialogs: title + body + 2 buttons (max)
- Action required: modal, cannot be dismissed by clicking outside
- Non-blocking: use Snackbar/MessageBar instead

**MessageBar (not Toast):**
- Fluent prefers inline MessageBar over floating toasts for important feedback
- Types: info, success, warning, error
- Placed directly above the content it relates to

### Fluent Typography

| Style | Size | Weight | Use |
|---|---|---|---|
| Display | 68px | 600 | Hero, marketing |
| LargeTitle | 40px | 600 | Page title |
| Title1 | 28px | 600 | Section header |
| Title2 | 24px | 600 | Card title |
| Title3 | 20px | 600 | Subsection |
| Body1 Strong | 14px | 600 | Emphasized body |
| Body1 | 14px | 400 | Default body |
| Body2 | 12px | 400 | Secondary body |
| Caption1 | 12px | 400 | Labels, captions |
| Caption2 | 10px | 400 | Fine print |

System font: Segoe UI Variable (Windows), fallback to system-ui.

### Fluent Accessibility
- WCAG 2.1 AA minimum for all Microsoft products
- High Contrast mode: MUST work — never use `forced-colors: none`
- Focus visible: Windows users rely on keyboard — 2px focus outline always visible
- Narrator (Windows screen reader): test with this, not just NVDA

---

## 5. Cross-Platform Considerations

When a product ships on both iOS and Android (or iOS and Web):

| Element | iOS (HIG) | Android (Material) |
|---|---|---|
| Primary nav | Tab bar (bottom) | Navigation bar (bottom) |
| Back navigation | Swipe left edge + top-left button | System back button / gesture |
| Primary CTA button | Filled, centered or full-width | Filled (M3), right-aligned FAB for creation |
| Form fields | Inset grouped (settings), clean (forms) | Filled or Outlined text field |
| Alerts | UIAlertController style | AlertDialog (title + body + actions) |
| Context menu | Long press UIContextMenu | Long press ContextMenu or bottom sheet |
| Pull to refresh | Native UIRefreshControl | SwipeRefreshLayout |
| Selection | Checkmark trailing | Checkbox leading |
| Switches | UISwitch (right-aligned) | Switch (right-aligned, but taller) |

**Shared rules that hold across all platforms:**
- 44–48px minimum touch targets
- System font unless brand font is established and legible
- System colors for semantic states unless brand overrides
- Never fight the platform's default safe areas and insets

---

## 6. When to Deviate from Platform Guidelines

Deviating is acceptable when:
- Brand identity requires it AND the deviation doesn't harm usability
- The interaction pattern is genuinely better and users can discover it
- You're building a game or highly immersive experience

Deviating is NOT acceptable when:
- It breaks expected navigation (e.g., hiding back navigation on iOS)
- It makes the app feel "web-wrapped" on a native platform
- It introduces friction for accessibility users
- The only reason is aesthetic preference

**Rule:** When you deviate, document why. Undocumented deviations become
technical debt that future designers can't evaluate without re-doing the research.
