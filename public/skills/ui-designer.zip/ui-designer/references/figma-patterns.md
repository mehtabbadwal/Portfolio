# Figma Patterns Reference

Detailed guidance for working inside Figma files — component architecture,
token strategy, auto-layout rules, and system hygiene.

---

## Token Strategy: Variables vs. Styles

### Use Variables for:
- Color tokens (supports light/dark mode switching via modes)
- Spacing values (8pt grid values as number variables)
- Border radius (radius tokens for system consistency)
- Opacity levels

### Use Styles for:
- Typography (text styles: family, size, weight, line height, letter spacing)
- Effects (drop shadows, inner shadows — when not tokenized)
- Grids (layout grids for frame-level guidance)

### Variable Naming Convention:
```
[category]/[tier]/[variant]

Examples:
color/brand/primary
color/brand/primary-hover
color/neutral/100
color/semantic/error-bg
spacing/4
spacing/8
radius/sm
radius/md
radius/lg
```

### Mode Setup:
- Create a "Light" and "Dark" mode for all color variables
- Create an optional "Dense" and "Comfortable" mode for spacing variables
- Assign the collection mode at the frame level, not the component level

---

## Auto-Layout Rules

Auto-layout on every frame. No absolute positioning except:
- Overlays (modals, drawers, tooltips)
- FABs (floating action buttons)
- Sticky elements (nav bars, bottom bars)
- Decorative elements that intentionally break grid

### Nesting Pattern:
```
Page Frame (auto-layout, vertical, 64px gap between sections)
└── Section (auto-layout, vertical, 32px gap)
    └── Card (auto-layout, vertical, 16px internal padding)
        └── Card Header (auto-layout, horizontal, 8px gap)
            └── Icon + Label
```

Key rule: gap between sibling frames ≥ internal padding of their parent. Violating
this makes the group feel disconnected from its container.

### Sizing Defaults for Screens (Fill + Hug Rule)

**This is the global default for all screen-level layout.** Apply it unless an explicit exception applies.

- **Width → Fill container** on every section, content block, card, row, and text element
- **Height → Hug contents** on every section, content block, card, row, and text element

This means screens grow naturally with content. Nothing has an arbitrary fixed height that will clip or leave dead space when content changes.

**Exceptions — fixed sizing is correct for:**
| Element | Sizing |
|---|---|
| Nav bar / top header | Fixed height (48–64px), fill width |
| Tab bar / bottom bar | Fixed height (48–83px), fill width |
| Image / thumbnail | Fixed width AND height |
| Icon frame | Fixed 20×20 or 24×24 |
| Divider | Fixed height 1px, fill width |
| Button / input | Fixed height (per size tier), hug or fill width depending on context |

### Hugging vs. Fixed:
- Components (buttons, tags, inputs): hug content horizontally, fixed height
- Layout containers (cards, sections): fill container horizontally, hug vertically
- Full-width elements: fill width, fixed or hug height

### Resizing:
- Set `Min Width` on components that shouldn't collapse (buttons: 80px min)
- Set `Max Width` on content containers (prose: 640-720px max)
- Use `Clip Content` on image containers to prevent overflow

---

## Component Architecture

### Single Component, Multiple Variants:
One master component with variant properties > separate components per state.

```
Button
├── Property: Type = Primary | Secondary | Tertiary | Destructive
├── Property: Size = Small | Medium | Large
├── Property: State = Default | Hover | Active | Disabled | Loading
├── Property: Icon = None | Leading | Trailing | Only
└── Property: Width = Hug | Fill
```

### Variant Property Naming:
- Use Title Case for property names: `Type`, `Size`, `State`
- Use Title Case for values: `Primary`, `Default`, `Loading`
- Keep consistent — if one component uses `Disabled`, all components use `Disabled` (not `Inactive`)

### Nested Components:
- Prefer swapping nested instances over boolean show/hide for semantic elements (icons, avatars)
- Use boolean properties for structural changes: `Has Icon`, `Has Badge`, `Has Subtitle`
- Expose only the properties that consumers need — don't surface internal layout properties

### Base + Composition Pattern:
```
Base/Icon           ← raw icon with correct sizing
Base/Avatar         ← base avatar with size variants
Component/Button    ← uses Base/Icon internally
Component/UserCard  ← uses Base/Avatar + Component/Button
```

---

## Design Token Validation Checklist

Before shipping a component to the design system:

- [ ] All colors reference variables (no raw hex values)
- [ ] All spacing values are from the spacing variable collection (or 8pt multiples)
- [ ] All radius values reference radius variables
- [ ] Typography uses text styles only (no detached font properties)
- [ ] All states are variant properties, not separate components
- [ ] Component has a description in the "Component description" field
- [ ] Variants are logically grouped in the variants panel

---

## Handling Inconsistencies

### When you find a deviation from the system:
1. Check if it's intentional — look for an annotation comment on the frame
2. If no annotation: flag with a comment, don't silently fix
3. Use format: `⚠️ [Component]: Uses raw value [value] instead of token [token-name]. Intentional?`

### When to detach a component:
- Only when a one-off variation is truly unique and won't recur
- Always leave a comment on the detached frame: `Detached: [reason]`
- Never detach just to override spacing or color — use component override instead

### System debt tracking:
- Use a dedicated "Design Debt" page or section in large files
- Log deviations with: component name, deviation, location, owner, status

---

## Icon System Rules

- Frame size: 20×20 or 24×24 (pick one size class per product, use both only if density requires it)
- Stroke: converted to outlines before adding to component (not live strokes)
- Corner radius: consistent across all icons in the set (typically 0.5-1px for filled, 1-1.5px for outlined)
- Optical sizing: verify icons feel visually equal in weight — some geometric shapes appear heavier; adjust fill
- Icon-only interactive: always wrap in a button component with `aria-label` annotation
- Mixed icon sets: never mix outlined and filled styles in the same interface unless one style = interactive, other = decorative

---

## Figma-Specific Accessibility Annotations

Use an annotation layer (locked, non-printing) to document:
- Tab order numbers for complex interactive flows
- ARIA roles for non-standard components (custom selects, comboboxes)
- Screen reader labels that differ from visible labels
- Focus trap boundaries for modals and drawers

Annotation format:
```
[A11Y] Tab: 3
[A11Y] Role: combobox
[A11Y] Label: "Filter by status"
[A11Y] Focus trap: start / end
```
