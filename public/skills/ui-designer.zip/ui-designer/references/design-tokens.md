# Design Tokens

Complete token scales for spacing, color, typography, shadows, and radii.
Read when establishing or auditing a visual design system.

---

## Spacing Scale (8pt Grid)

```css
--space-0: 0px;
--space-1: 4px;    /* fine-tuning inside components */
--space-2: 8px;    /* tight spacing, icon gaps */
--space-3: 12px;   /* label-to-input gap */
--space-4: 16px;   /* default internal padding */
--space-5: 20px;   /* compact section spacing */
--space-6: 24px;   /* card padding, form field gaps */
--space-7: 32px;   /* section spacing */
--space-8: 40px;   /* large section gaps */
--space-9: 48px;   /* section dividers */
--space-10: 64px;  /* page section spacing */
--space-11: 80px;  /* hero spacing */
--space-12: 96px;  /* major page divisions */
--space-13: 128px; /* page-level whitespace */
```

**Rule:** Internal spacing ≤ external spacing. Always.

---

## Neutral Color Scales

### Light Mode
```css
--gray-50: #FAFAFA;   /* page background */
--gray-100: #F5F5F5;  /* subtle backgrounds */
--gray-200: #E5E5E5;  /* borders, dividers */
--gray-300: #D4D4D4;  /* disabled elements */
--gray-400: #A3A3A3;  /* placeholder text */
--gray-500: #737373;  /* secondary text */
--gray-600: #525252;  /* icons */
--gray-700: #404040;  /* body text */
--gray-800: #262626;  /* headings */
--gray-900: #171717;  /* primary text */
--gray-950: #0A0A0A;  /* high emphasis */
```

### Dark Mode
```css
--dark-bg: #0A0A0A;         /* deepest background */
--dark-surface-1: #141414;  /* card backgrounds */
--dark-surface-2: #1E1E1E;  /* raised surfaces */
--dark-surface-3: #282828;  /* highest elevation */
--dark-border: rgba(255,255,255,0.08);  /* subtle borders */
--dark-border-hover: rgba(255,255,255,0.12);
--dark-text-primary: #F5F5F5;
--dark-text-secondary: #A3A3A3;
--dark-text-tertiary: #737373;
```

**Dark mode rules:**
- Elevation = lighter surfaces (not shadows)
- Desaturate primary colors 10-15%
- Never pure white text — use #E5E5E5 to #F5F5F5
- Borders use semi-transparent white, not solid grays
- Test at night in a dim room

---

## Type Scales

### Minor Third (1.200) — Balanced, most web apps
```css
--text-xs: 0.694rem;   /* 11.1px — captions, badges */
--text-sm: 0.833rem;   /* 13.3px — labels, helper text */
--text-base: 1rem;     /* 16px — body text */
--text-lg: 1.2rem;     /* 19.2px — subheadings */
--text-xl: 1.44rem;    /* 23px — section headings */
--text-2xl: 1.728rem;  /* 27.6px — page headings */
--text-3xl: 2.074rem;  /* 33.2px — hero headings */
```

### Major Third (1.250) — Marketing, editorial
```css
--text-xs: 0.64rem;    /* 10.2px */
--text-sm: 0.8rem;     /* 12.8px */
--text-base: 1rem;     /* 16px */
--text-lg: 1.25rem;    /* 20px */
--text-xl: 1.563rem;   /* 25px */
--text-2xl: 1.953rem;  /* 31.3px */
--text-3xl: 2.441rem;  /* 39.1px */
```

### Line Heights
```css
--leading-tight: 1.15;   /* large headings */
--leading-snug: 1.3;     /* small headings, labels */
--leading-normal: 1.5;   /* body text */
--leading-relaxed: 1.625; /* long-form reading */
```

### Letter Spacing
```css
--tracking-tighter: -0.04em;  /* large headings (32px+) */
--tracking-tight: -0.02em;    /* medium headings */
--tracking-normal: 0;          /* body text */
--tracking-wide: 0.025em;     /* small labels */
--tracking-wider: 0.05em;     /* ALL CAPS text */
--tracking-widest: 0.1em;     /* CAPS small labels */
```

---

## Shadow Scale

### Light Mode
```css
--shadow-xs: 0 1px 2px rgba(0,0,0,0.04);
--shadow-sm: 0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04);
--shadow-md: 0 4px 6px rgba(0,0,0,0.06), 0 2px 4px rgba(0,0,0,0.04);
--shadow-lg: 0 10px 15px rgba(0,0,0,0.06), 0 4px 6px rgba(0,0,0,0.04);
--shadow-xl: 0 20px 25px rgba(0,0,0,0.08), 0 8px 10px rgba(0,0,0,0.04);
```

**Hover states:** rise one level (xs → sm, sm → md)

### Dark Mode
Use surface color elevation instead of shadows:
- Resting: `--dark-surface-1`
- Hover: `--dark-surface-2`
- Active/modal: `--dark-surface-3`
- Add subtle `border: 1px solid rgba(255,255,255,0.06)` for definition

---

## Border Radius

Pick one style and commit across the entire product:

```css
/* Sharp (professional, editorial) */
--radius-sm: 2px;
--radius-md: 4px;
--radius-lg: 6px;
--radius-full: 9999px;

/* Medium (modern SaaS) */
--radius-sm: 4px;
--radius-md: 8px;
--radius-lg: 12px;
--radius-full: 9999px;

/* Round (playful, consumer) */
--radius-sm: 8px;
--radius-md: 12px;
--radius-lg: 16px;
--radius-full: 9999px;
```

**Rule:** Nested elements have SMALLER radius than parent.
Formula: `child-radius = parent-radius - padding`

---

## Data Visualization Palette

A safe base palette for charts and graphs — distinct from semantic colors,
tested for the 3 most common color blindness types (deuteranopia, protanopia,
tritanopia). Use this as a starting point; adjust to your brand.

```css
/* Categorical — up to 6 distinct series */
--dataviz-1: #4C78A8;  /* blue — safe for all color blindness types */
--dataviz-2: #F58518;  /* orange — distinct from blue for deuteranopia */
--dataviz-3: #54A24B;  /* green — safe paired with orange */
--dataviz-4: #B279A2;  /* purple — distinct from all above */
--dataviz-5: #FF9DA7;  /* pink — readable in most conditions */
--dataviz-6: #9D755D;  /* brown — final safe series */

/* Sequential — single metric by intensity */
--dataviz-seq-1: #EFF3FF;  /* lightest */
--dataviz-seq-2: #BDD7E7;
--dataviz-seq-3: #6BAED6;
--dataviz-seq-4: #2171B5;
--dataviz-seq-5: #084594;  /* darkest */

/* Diverging — values above/below a midpoint (e.g. profit/loss) */
--dataviz-neg-strong: #D73027;
--dataviz-neg-light:  #FC8D59;
--dataviz-mid:        #FEE08B;
--dataviz-pos-light:  #91CF60;
--dataviz-pos-strong: #1A9850;
```

**Rules:**
- Never reuse semantic colors (error-red, success-green) as chart series — this
  causes users to interpret data as errors or successes
- Always label chart series with text, not color alone
- Zero-baseline is mandatory for bar and area charts — never truncate the Y axis
- Test the full palette in grayscale to verify distinguishability without color
- Use the sequential palette for single-metric heatmaps and choropleths
- Use the diverging palette only when a midpoint is meaningful (e.g. -/+ delta)

---

## Responsive Breakpoints

```css
--bp-sm: 640px;    /* mobile landscape */
--bp-md: 768px;    /* tablet portrait */
--bp-lg: 1024px;   /* tablet landscape / small desktop */
--bp-xl: 1280px;   /* desktop */
--bp-2xl: 1536px;  /* large desktop */
```

Container max-widths: 640px (narrow), 768px (reading), 1024px (app),
1280px (wide app), 1536px (dashboard)
