# UI Patterns Reference

Decision frameworks and specifications for recurring UI challenges.
These patterns appear in almost every product — handle them consistently
or they become the most visible design debt in the system.

---

## Table of Contents
1. Loading States — When to Use What
2. Empty States
3. Error Handling Patterns
4. Content Truncation and Overflow
5. Image Treatment
6. Internationalization (i18n) Basics
7. Onboarding Patterns

---

## 1. Loading States — When to Use What

### The Decision Framework

Choose the loading pattern based on two axes: **duration** and **context**.

| Duration | Context | Pattern |
|---|---|---|
| < 300ms | Any | No indicator (too fast to perceive) |
| 300ms–1s | Inline element loading | Skeleton screen |
| 300ms–1s | Button/action triggered | Button loading state (spinner in button) |
| 1–3s | Page or section loading | Skeleton screen |
| 1–3s | Known progress | Progress bar |
| 3–10s | Page-level, unknown duration | Skeleton + optional message |
| > 10s | Long operation (export, upload, processing) | Progress bar + status message + cancel option |
| Indeterminate | Background sync | Subtle status indicator (not blocking) |

### Skeleton Screens
- Mirror the actual layout — shape, size, and position of real content
- Use actual content dimensions (not generic rectangles) — a 3-line text block needs 3 skeleton lines
- Animate with shimmer (left-to-right sweep, 1.5s linear infinite)
- Never show more than 2–3 skeleton screens simultaneously — it amplifies emptiness
- Replace skeleton immediately on load — don't fade out, just swap
- For images: show skeleton in the correct aspect ratio

### Spinners
- Use for actions, not page loads (button spinner, inline spinner next to a field)
- Size: 16px inline, 24px in buttons, 32px for section-level loading
- Never use a full-page spinner for content-heavy pages — use skeleton instead
- Full-page spinner acceptable for: authentication redirects, payment processing

### Progress Bars
- Use when you know (or can estimate) the percentage complete
- Always show what is being processed ("Uploading 3 of 5 files...")
- Include a cancel action for anything > 5 seconds
- On completion: brief success state (green + checkmark), then auto-dismiss or transition
- Indeterminate progress bar (bouncing): only when truly no progress info is available

### Optimistic UI
- Immediately reflect the user's action as if it succeeded
- Revert with an error message only if the action actually fails
- Use for: toggling likes/bookmarks, reordering, simple creates
- Do NOT use for: payments, deletions, sends — these need confirmed feedback
- Always provide an undo path for optimistic updates

### Pull to Refresh
- Mobile only — never on desktop
- Show loading indicator during refresh
- On complete: briefly show "Updated just now" or new content count

---

## 2. Empty States

Every list, table, dashboard widget, inbox, search result, and filtered view
needs a designed empty state. "No records found" is not a design.

### The Five Types of Empty States

**① First-time empty (blank canvas)**
User has never created any content. This is the most important empty state.
- Illustration or icon (optional but effective)
- Headline: what this space is for ("Your projects live here")
- Body: one sentence on why it's valuable
- Primary CTA: the action to create the first item ("Create your first project")
- Optional: link to docs, template gallery, or sample data

**② User-cleared empty (they deleted everything)**
- Simpler treatment — they know what this is
- Message acknowledging the cleared state ("All caught up")
- Optional: undo or create new CTA

**③ Search / filter empty (no results)**
- Show what was searched/filtered for ("No results for "invoice template"")
- Suggest: clear filters, check spelling, try broader terms
- If appropriate: offer to create what they searched for

**④ Error-caused empty (couldn't load)**
- Distinguish from "no data" — show an error icon, not an empty illustration
- Explain what failed, not just that it failed
- Offer: retry button, contact support link
- Never show an empty list when the real issue is a failed fetch

**⑤ Permission-based empty (can't see this)**
- Explain why: "You don't have access to this section"
- Who to contact or how to request access
- Never just a blank screen — that reads as a bug

### Empty State Anatomy
```
[Illustration or icon — 80–120px, muted color]

[Headline — text-lg, font-weight-600]
[Body — text-base, text-secondary, max 2 lines]

[Primary CTA button]
[Secondary link — optional]
```

### Empty State Rules
- Always center vertically and horizontally in the empty container
- Illustration: simple, related to the content type, not generic
- Never use the same illustration for all empty states
- Copy: specific to the context, not generic ("No items" is never acceptable)
- Mobile: reduce illustration size, keep CTA full-width

---

## 3. Error Handling Patterns

### Error Hierarchy — Match the Pattern to the Severity

| Severity | Pattern | Example |
|---|---|---|
| Inline / field-level | Error text below field, red border | Form validation |
| Component-level | Error state within component | Chart failed to load |
| Page-level non-blocking | Toast / Snackbar | "Save failed, try again" |
| Page-level blocking | Inline error banner | Network offline |
| Full page error | Dedicated error screen | 404, 500, permission denied |
| Critical / system | Modal dialog | Session expired, data corruption risk |

### Field-Level Errors (Forms)
- Red border on the field
- Error icon (⚠ or ✕) inside or beside the field
- Error message below the field — specific, actionable, not just "Invalid"
  - Bad: "Invalid email"
  - Good: "Enter a valid email address (e.g. name@example.com)"
- Replace helper text with error message — don't stack them
- Clear error on correction, not on submission
- For multi-field errors on submit: scroll to first error, focus it

### Toast / Snackbar Errors
- Position: bottom-center (mobile), top-right or bottom-right (desktop)
- Auto-dismiss: info (4s), success (3s), warning (6s), error (never auto-dismiss)
- Error toasts must have a manual close button AND a retry action if relevant
- Stack if multiple toasts — max 3 visible at once (queue the rest)
- Don't show duplicate toasts for the same error

### Error Banners (Page-level, non-blocking)
- Placed at the top of the affected section, not floating
- Semantic color: red border-left or red background-tinted
- Icon + title + body + optional CTA
- Dismissible unless the error is ongoing (e.g. offline mode)

### Full-Page Errors

**404 — Not Found:**
- Acknowledge: "This page doesn't exist"
- Offer: return home, go back, search
- Tone: light — this is rarely the user's fault
- Include: navigation so they can find their way

**403 — No Permission:**
- Acknowledge: "You don't have access to this"
- Offer: request access, contact admin, or return to safe ground
- Never show a blank page or a generic 500 error for permission issues

**500 / Server Error:**
- Acknowledge: "Something went wrong on our end"
- Never expose: stack traces, error codes, or technical details to users
- Offer: retry, status page link, contact support
- Log: the error ID internally so support can look it up

**Network Offline:**
- Detect and show immediately (don't let the user experience silent failures)
- Persistent banner: "You're offline — changes won't be saved"
- Re-check on reconnect and confirm "You're back online"
- Queue any actions taken while offline and process on reconnect where possible

### Error Message Copy Rules
- Always explain what happened in plain language
- Always suggest what to do next
- Never use error codes alone
- Never blame the user ("You entered an invalid date") — reframe ("The date must be in the future")
- Never use "Oops" for serious errors — reserve for genuinely minor moments

---

## 4. Content Truncation and Overflow

### When to Truncate

Truncation hides information. Always ask: does the user need this information?
If yes, truncation is a last resort. If no, the content shouldn't be there.

### Truncation Patterns

**Single-line truncation (ellipsis):**
```css
.truncate {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
```
Use for: table cells, nav items, card titles, tag labels.
Rule: always show full content on hover via tooltip.

**Multi-line clamp:**
```css
.clamp-3 {
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
```
Use for: card descriptions, list item bodies, search result excerpts.
Rule: provide "Read more" or expand-on-click if content is primary.

**"Show more / Show less":**
Use for: comment threads, long descriptions, activity feeds.
Rule: show enough to establish context (2–3 lines). Expand in place — don't navigate.

### Never Truncate
- Financial figures (show full value; use tooltip if space is tight)
- Medication names (healthcare)
- Legal text (link to full document)
- Error messages (truncated errors are useless for debugging and support)
- Primary call-to-action labels

### Column Width and Content Stability
- Table columns must not jump width when content changes between rows
- Set min-width on columns that contain variable-length content
- Use fixed-width columns for: dates, currencies, status badges, action buttons
- Right-align numbers — they must align at the decimal point across rows

---

## 5. Image Treatment

### Aspect Ratios — Pick and Commit

| Context | Ratio | Notes |
|---|---|---|
| Product thumbnail | 1:1 | Square, easy to grid |
| Card cover image | 16:9 or 3:2 | Landscape, cinematic |
| Avatar | 1:1 | Always circular or squircle |
| Blog / article hero | 16:9 | |
| Social media preview | 1.91:1 | OG image standard |
| Portrait / headshot | 3:4 | |

Lock aspect ratios on image containers — never allow distortion.
Use `object-fit: cover` to fill the container; `object-position: center` unless
the subject is known to be off-center.

### Loading and Fallback States

**Loading:**
- Skeleton in the correct aspect ratio (not a generic rectangle)
- Subtle background color matching the image container's context
- Fade in on load (150–200ms opacity transition)

**Broken image:**
- Never show the broken image icon (browser default)
- Show a placeholder: icon + "Image unavailable" or a brand-consistent fallback
- For avatars: show initials in a colored circle (derive color from name, not random)

**Missing avatar fallback order:**
1. User-uploaded photo
2. Gravatar (if integrated)
3. Initials (First + Last) in a generated color
4. Generic person icon — last resort

**Generated avatar colors:**
- Derive from a hash of the user's name — same name = same color every time
- Ensure all generated colors meet 4.5:1 contrast with white initials
- Limit to a palette of 8–12 colors (not fully random)

### Image Overlay and Text on Images
- Never place body text directly on a photo without a scrim
- Scrim: linear gradient from `rgba(0,0,0,0)` at top to `rgba(0,0,0,0.7)` at bottom
- Ensure text on images meets WCAG AA contrast independently
- Test at the brightest part of the image — if it fails there, add more scrim

### Lazy Loading
- Lazy load all images below the fold
- Use `loading="lazy"` attribute
- Reserve space with the correct aspect ratio (prevent layout shift / CLS)
- Above-the-fold images: always eager load

---

## 6. Internationalization (i18n) Basics

### Text Expansion

When translated, text expands. Design with this in mind from the start.

| Source language | Expansion |
|---|---|
| English → German | +30–40% |
| English → French | +20–30% |
| English → Spanish | +15–25% |
| English → Japanese | −10–20% (contracts) |
| English → Arabic | Variable; RTL layout change |

**Rules:**
- Never use fixed-width containers for text — use `min-width` + `hug`
- Button labels must not clip or wrap at +40% text length
- Test all UI strings at 140% of English length before shipping
- Avoid designing labels that only work in English ("Sign Up" → "Registrieren" is 2.5× longer)

### Right-to-Left (RTL) Layouts

For Arabic, Hebrew, and other RTL languages:

- Page layout mirrors horizontally: sidebar moves to the right, content to the left
- Text alignment: right-aligned body text, right-aligned labels
- Icons that indicate direction MUST flip: back arrow → forward arrow visually
- Icons that are not directional do NOT flip: ✓, ✕, icons of objects
- Padding and margin: mirror left/right values (`padding-inline-start` instead of `padding-left`)
- Use logical CSS properties from the start: `margin-inline-start`, `border-inline-end`

### Date, Time, and Number Formats

**Never hardcode formats — use the locale:**
- Date: MM/DD/YYYY (US) vs DD/MM/YYYY (UK/EU) vs YYYY/MM/DD (ISO/Japan)
- Time: 12-hour AM/PM (US) vs 24-hour (most of the world)
- Numbers: 1,000.00 (US) vs 1.000,00 (Germany) vs 1 000,00 (France)
- Currency: always show the currency symbol AND code for international products

**Relative time:**
- "2 hours ago" is locale-neutral in concept but requires i18n strings
- Always provide the absolute date/time on hover for relative timestamps

### Character Support
- Ensure fonts support the full character set for target locales
- Latin Extended (ñ, ü, ö, é) must render correctly in your chosen typeface
- CJK (Chinese, Japanese, Korean): system font fallback is essential; load a
  CJK-compatible web font only if design requires brand consistency there

---

## 7. Onboarding Patterns

### The Onboarding Goal
Get the user to their first moment of value as fast as possible.
Everything else is in service of that.

### Pattern Selection Guide

| User type | Product complexity | Best pattern |
|---|---|---|
| Consumer, low context | Simple | Empty state + single CTA |
| Consumer, low context | Complex | Guided checklist (3–5 steps) |
| SMB, moderate context | Moderate | Goal-based setup wizard |
| Enterprise, professional | Complex | Progressive disclosure + empty state |
| Technical user | Any | Docs-first + sample data |

### Pattern Specifications

**① Empty State + Single CTA (simplest)**
Use when: the product's value is immediately clear and the first action creates it.
- Zero steps, zero modals
- Empty state IS the onboarding — the CTA creates the first item
- Success: user creates first item and sees populated UI

**② Guided Checklist**
Use when: there are 3–5 setup tasks but order doesn't matter.
- Persistent panel or page: tasks with completion checkmarks
- Progress bar showing 0/5 → 5/5
- Each task: title + one-line description + CTA
- Dismissible after completing the most critical task (not all of them)
- Return path: always accessible from main nav ("Set up your workspace")

**③ Goal-Based Setup Wizard**
Use when: initial configuration meaningfully changes the experience.
- Start with "What do you want to accomplish?" (2–4 options)
- Branch based on answer — don't show everyone the same setup
- Maximum 5 steps in the wizard
- Progress indicator at the top (Step 2 of 4)
- Skip available on every step — never block progress
- Final step: confirm + show what's been set up

**④ Progressive Disclosure (enterprise / power users)**
Use when: the product is complex and users arrive with existing context.
- Show a clean, minimal default state
- Surface features contextually as they're encountered ("Did you know you can...") 
- Use tooltips and coach marks on first encounter with a feature, not upfront
- Track per-user feature exposure — don't show the same tip twice

**⑤ Interactive Product Tour**
Use when: the product has key areas that aren't discoverable on their own.
- Maximum 5 steps — attention drops sharply after step 3
- Highlight the actual UI element (not screenshots)
- Trigger on first login, never on return visits
- Skip available at step 1 and throughout
- Completion state: brief celebration + first action CTA

### Onboarding Anti-Patterns
- Mandatory video before using the product
- Email verification before seeing any value
- Forcing profile completion before accessing core features
- 8+ step wizards with no skip option
- Re-triggering tours on every login
- Using onboarding to collect data for marketing (ask for what the product needs, nothing more)

### Measuring Onboarding Success
Design with these metrics in mind (even if you're not the one measuring):
- **Time to first value:** how long from sign-up to first meaningful action?
- **Setup completion rate:** what % complete the wizard / checklist?
- **Drop-off step:** which step do most users abandon?
- **Day-7 retention:** are onboarded users still active a week later?
