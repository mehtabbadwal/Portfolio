# Domain-Specific Design Guidelines

Every product domain has a different trust contract with its users, different
regulatory constraints, different cognitive load requirements, and different
conventions users already expect. Designing a fintech app like a consumer social
app will fail — not because the UI is bad, but because the domain contract is wrong.

Read the relevant section(s) before designing for a new domain.

---

## Table of Contents
1. How to Identify Your Domain
2. Fintech and Financial Services
3. Healthcare and Medical (HIPAA context)
4. Enterprise B2B SaaS
5. SMB / General SaaS
6. E-commerce (B2C)
7. B2B E-commerce / Procurement
8. AI / ML Products
9. Developer Tools / DevTools
10. C2C Marketplace
11. D2C (Direct-to-Consumer)
12. Social Commerce
13. B2G / B2A (Business-to-Government)
14. Domain Crossovers

---

## 1. How to Identify Your Domain

A product can span multiple domains. When it does, apply the stricter domain's
trust and compliance rules, and the more forgiving domain's visual expression.

| Product type | Primary domain | Secondary |
|---|---|---|
| Mobile banking app | Fintech | Consumer |
| Hospital patient portal | Healthcare | Enterprise |
| Project management tool | SaaS B2B | SMB |
| Online store | E-commerce B2C | Consumer |
| Procurement / purchasing platform | B2B E-commerce | Enterprise B2B |
| Insurance claims platform | Fintech + Healthcare | Enterprise |
| Clinical trial management | Healthcare | Enterprise B2B |
| ERP system | Enterprise B2B | — |
| AI chat or co-pilot product | AI / ML Products | SaaS B2B or B2C |
| Developer dashboard / API console | Developer Tools | Enterprise B2B |
| Peer marketplace (Airbnb, eBay, Etsy) | C2C | E-commerce |
| Brand-owned subscription product | D2C | E-commerce B2C |
| In-feed / livestream shopping | Social Commerce | E-commerce B2C |
| Government procurement portal | B2G | Enterprise B2B |
| Creator storefronts | Social Commerce | D2C |
| Peer payment app | C2C + Fintech | Consumer |

---

## 2. Fintech and Financial Services

### The Trust Contract
Users are giving you access to or visibility into their money. Trust is the
product. One confusing screen or ambiguous number can cause genuine harm.

### Core Design Principles
- **Clarity over cleverness:** Every number must be unambiguous. Show currency,
  sign (+/-), and precision explicitly. Never truncate a financial figure without
  a tooltip showing the full value.
- **Confirmation before action:** Any action that moves money, changes a limit,
  or affects an account requires explicit confirmation — not just a button press.
  Use a confirmation modal with a summary of what will happen.
- **Reversibility signaling:** Make it obvious which actions can be undone and
  which cannot. Irreversible actions (wire transfers, account closures) need
  extra friction: type-to-confirm, delay timer, or 2-step verification.
- **Status transparency:** Users need to know where their money is at all times.
  "Pending", "Processing", "Settled", "Failed" must be visually distinct and
  explained in plain language — not banking jargon.

### Visual Language
- **Color:** Conservative palette. Blue is trust (used by 70%+ of banks).
  Green = gain/positive. Red = loss/negative/alert — use precisely, never
  decoratively. Avoid playful color in financial contexts.
- **Typography:** High legibility at small sizes. Tabular numerals (monospaced
  number width) for all financial figures so columns align. Never use a
  display font for numbers.
- **Density:** Financial dashboards need high information density, but group
  related figures tightly. Users scan for specific numbers — don't bury them.
- **Iconography:** Conservative, literal icons. A house is a mortgage.
  An arrow up with a + is income. Never use abstract or decorative icons for
  financial actions.

### Key Components and Patterns
- **Balance display:** Always show currency symbol, 2 decimal places, and +/-
  sign for changes. Available balance vs. total balance clearly labeled.
- **Transaction list:** Merchant name (not internal ID), date, amount, status,
  category icon. Sortable and filterable. Running balance optional but useful.
- **Transfer flow:** Amount → Account selection → Confirmation summary →
  Authenticated confirm → Success/receipt. Never skip steps.
- **Charts:** Use area charts for portfolio value (continuous), bar for
  spending categories (discrete). Always label axes with currency and time period.
  Zero-baseline mandatory — never truncate the Y axis in financial charts.
- **Empty state:** "No transactions yet" not "Nothing here" — use precise language.

### Compliance and Regulatory Considerations
- **KYC (Know Your Customer):** ID verification flows must be clear, explain
  why information is needed, and show progress explicitly.
- **Disclosures:** Legal disclaimers must be present but can be de-emphasized
  typographically — small text is acceptable if not hiding material information.
- **Data display:** Never show full account numbers — mask as ••••1234.
  Card numbers: only last 4 digits visible by default.
- **Session timeout:** Warn before auto-logout. Never lose form data on timeout.
- **Error messages:** Never expose internal error codes to users ("Error 4031").
  Use plain language + next steps ("Your card was declined. Contact your bank or try a different card.").

### What Not to Do
- Gamification elements (streaks, points, badges) in serious financial contexts
- Playful micro-animations on financial figures updating
- Hiding fees or charges until the confirmation step
- Vague CTAs ("Continue") on irreversible actions — be specific ("Send $500")

---

## 3. Healthcare and Medical (HIPAA Context)

### The Trust Contract
Users are sharing the most sensitive information they have: their bodies, their
diagnoses, their mental state. The stakes of an error — a wrong medication dose,
a missed appointment, a misread result — are physical, not just financial.

### Core Design Principles
- **Precision over brevity:** Medical information must be complete and accurate.
  Do not simplify to the point of inaccuracy. When abbreviating, provide the
  expansion on hover/tap.
- **Reduce cognitive load ruthlessly:** Patients may be anxious, in pain, or
  under medication. Clinicians are overloaded. Every unnecessary word, step, or
  element is a liability.
- **Never cause alarm without cause:** Status indicators, color coding, and
  icons must be calibrated precisely. Red = clinically significant, not "this
  could be better."
- **Progress and wait times:** Clinical workflows have real time costs. Show
  progress, estimated wait, and queue position where possible.

### Visual Language
- **Color:** Restrained, clinical palette. Blue or teal for calm/neutral.
  Red strictly for alerts and critical values — not for errors in the generic
  UX sense. Green = normal range, not "success." Avoid orange (associated with
  warning/caution in clinical settings — reserve for genuine caution states).
- **Typography:** High legibility, generous line height. Support dynamic type
  fully — elderly and visually impaired users are core audience. Avoid
  decorative or brand fonts for clinical content.
- **Density:** Patient-facing: low density, generous touch targets, calm layout.
  Clinician-facing (EHR, clinical tools): high density acceptable — clinicians
  are trained users who need efficiency over aesthetics.
- **Imagery:** Use clinical illustration or photography thoughtfully. Diverse
  representation matters more in healthcare than almost any other domain.

### Key Components and Patterns
- **Vital signs / lab values:** Show value, normal range, unit, and trend.
  Flag out-of-range values with color + icon + label (not color alone).
- **Medication lists:** Drug name (generic + brand), dose, frequency, route,
  prescriber. Never truncate medication names.
- **Appointment booking:** Date, time, provider, location (or telehealth link),
  preparation instructions, cancellation policy — all on one confirmation screen.
- **Symptom checker / intake forms:** One question at a time (not a wall of
  questions). Save progress. Allow review before submit. Avoid leading questions.
- **Emergency content:** Crisis resources, emergency contacts, and "call 911"
  prompts must always be visible and accessible — never hidden behind a menu.

### Compliance and Regulatory Considerations
- **HIPAA (US):** PHI (Protected Health Information) must never appear in URLs,
  logs, or analytics. Session timeout required. Audit trails for data access.
- **Accessibility (ADA / Section 508):** Healthcare products serving US government
  or government-funded programs must meet Section 508, which is stricter than WCAG AA.
- **FDA guidance:** Any software intended to influence clinical decisions may be
  considered a Software as Medical Device (SaMD) — design changes may require
  regulatory review.
- **Plain Language:** Patient-facing content should target a 6th–8th grade
  reading level (Flesch-Kincaid). Medical jargon must be explained.

### What Not to Do
- Gamification of health behaviors (streaks, points) — can create shame for
  patients who miss targets during illness
- Decorative animations near clinical alerts or lab values
- Colloquial copy ("Awesome! Your labs look great!") for serious results
- Dark patterns in consent flows — healthcare consent must be genuine and informed

---

## 4. Enterprise B2B SaaS

### The Trust Contract
The buyer is a company; the user is an employee. They didn't choose the tool —
their company bought it. Efficiency, predictability, and learnability matter
more than delight. Power users need depth; occasional users need safety.

### Core Design Principles
- **Efficiency for power users:** Keyboard shortcuts, bulk actions, command
  palettes, saved views, and filters are not optional extras — they are core UX.
- **Predictability over surprise:** Don't change layouts between versions without
  migration paths. Don't move things users have memorized. Delight through speed,
  not novelty.
- **Configurability:** Enterprise users have diverse workflows. Defaults must be
  sensible; customization must be possible. Column ordering, dashboard widgets,
  notification preferences are table stakes.
- **Data density:** Enterprise users manage more records, more columns, more
  states than consumer users. High-density modes are expected and needed.
- **Audit and accountability:** Show who did what and when. Edit history, activity
  logs, and change attribution are product features, not afterthoughts.

### Visual Language
- **Color:** Restrained, professional palette. Deep blue or dark navy for
  primary. Avoid bright consumer colors. Neutral grays carry the majority of
  the UI weight. Accent color used sparingly for primary actions only.
- **Typography:** Dense, highly legible. 13–14px base font for desktop (higher
  density than consumer). System fonts are often preferred over brand fonts
  in enterprise — they load faster and feel native.
- **Density:** Default to medium density with a compact mode option. Tables
  should be scannable with 40–48px row height. Compact: 32–36px.
- **Sidebar navigation:** Always present on desktop. Collapsible. Grouped
  with section headers. Secondary navigation within sections via nested items
  or a sub-nav panel.

### Key Components and Patterns
- **Data tables:** Sortable, filterable, column-resizable, selectable rows,
  bulk actions bar that appears on selection, row-level actions (hover menu
  or kebab icon), sticky header, pagination or infinite scroll.
- **Filters and search:** Persistent filter bar, saved filter sets, advanced
  filter builder (AND/OR logic), global search with category scoping.
- **Command palette (⌘K):** Expected in modern enterprise SaaS. Fuzzy search
  across actions, records, and navigation.
- **Empty states:** Must include an actionable path — never just "No data."
  Show what will appear here and how to create it.
- **Bulk operations:** Select all, select page, deselect all. Confirm before
  destructive bulk actions. Show count of affected records.
- **Role-based UI:** Different users see different things. Design for all roles.
  Disabled states for actions the user can't take — show why (permission tooltip).

### Compliance and Regulatory Considerations
- **SSO and SCIM:** Enterprise customers expect SAML/OIDC SSO and user
  provisioning. Design flows that support this gracefully.
- **Data residency:** Some enterprise customers need data kept in specific
  regions — UI may need to surface this in settings.
- **SOC 2 / ISO 27001:** Security-conscious buyers will ask about audit logs,
  access controls, and session management — design these as visible features.

### What Not to Do
- Hiding power features behind "clean" minimal surfaces
- Removing configurability in favor of "opinionated" design
- Ignoring keyboard navigation — enterprise power users live on keyboards
- Forcing onboarding flows on returning users

---

## 5. SMB / General SaaS

### The Trust Contract
Small business users are generalists, not specialists. They may use the tool
weekly, not daily. Setup must be fast. Value must be visible immediately.
They are price-sensitive and will leave if confused.

### Core Design Principles
- **Time to value:** Users must see benefit within the first session, ideally
  the first 5 minutes. Onboarding is a product, not a tutorial.
- **Progressive disclosure:** Start simple, reveal complexity on demand.
  Don't show all features at once — surface them as users grow.
- **Helpful defaults:** Pre-populate, suggest, and auto-configure where possible.
  Every required field is a decision cost.
- **Friendly but professional:** More warmth than enterprise, less playfulness
  than consumer. Conversational copy, not clinical or corporate.

### Key Patterns
- **Onboarding:** Goal-oriented setup ("What do you want to accomplish first?"),
  sample data to make the product feel alive immediately, skip option always
  available, progress indicator.
- **Empty states:** Warmly explain what will appear and offer a clear first action.
  Sample data or templates remove fear of the blank canvas.
- **Pricing / upgrade prompts:** Non-intrusive. Show value before asking for
  upgrade. Contextual ("This feature is available on Pro — you're using X already").
- **Notifications:** Digestible summaries, not overwhelming feeds. Weekly digest
  option. Unsubscribe from any notification type easily.

---

## 6. E-commerce (B2C)

### The Trust Contract
Users want the product, not the checkout. Every added step between "I want this"
and "I have this" is revenue lost. Trust must be established instantly.
Returns and support must feel safe and accessible.

### Core Design Principles
- **Conversion-optimized flow:** Product → Cart → Checkout → Confirmation.
  Minimize steps, minimize required fields, offer guest checkout.
- **Trust signals:** Badges (secure checkout, returns policy, reviews) near
  CTAs, not buried in footers. Real customer photos, not only stock images.
- **Urgency and scarcity (used honestly):** "Only 3 left" and countdown timers
  are effective — but only when true. Dark patterns destroy long-term trust.
- **Mobile-first:** 70%+ of e-commerce browsing is mobile. Product pages,
  cart, and checkout must be optimized for thumb navigation.

### Visual Language
- **Product photography:** Consistent backgrounds, multiple angles, lifestyle
  and clinical shots. Zoom on hover/pinch. Video where possible.
- **Color:** Brand-led, expressive. More latitude for color than B2B. However,
  Add to Cart and Checkout CTAs should still be high-contrast and prominent.
- **Typography:** Product names scannable at a glance. Price large and prominent.
  Discounted price: old price struck-through, new price in accent color.

### Key Components and Patterns
- **Product card:** Image (primary), product name, price, rating, quick-add.
  Hover: second product image or quick-add CTA.
- **Product page:** Image gallery → Product name → Price + savings →
  Variant selectors → Quantity → Primary CTA ("Add to Cart") → Trust signals →
  Description → Reviews → Related products.
- **Cart:** Persistent (slide-out drawer or dedicated page). Show thumbnail,
  name, variant, quantity stepper, price, remove. Order summary sticky.
- **Checkout:** Progress indicator. Guest checkout prominent. Address
  autocomplete. Card input with real-time validation. Order summary always visible.
- **Search:** Autocomplete with product thumbnails, category suggestions,
  recent searches. Instant results on keystroke.

### Compliance
- **Cookie consent:** Required in EU/UK. Non-dark pattern: accept/reject both
  equally prominent.
- **Accessibility (ADA):** US e-commerce has significant ADA lawsuit exposure.
  WCAG AA minimum.
- **Payment security:** PCI-DSS compliance affects what you can show/store.
  Use tokenized payment widgets — never design your own card input.

---

## 7. B2B E-commerce / Procurement

### The Trust Contract
Buyers are purchasing agents, not end consumers. They need to justify every
purchase to their organization. Price, availability, delivery timeline, and
invoice documentation are more important than visual delight.

### Core Design Principles
- **Efficiency over emotion:** Repeat purchasing (reorder, favorites lists,
  bulk upload via CSV) is more important than discovery.
- **Organizational structure:** Multiple users under one account, purchase
  approvals, budget limits, cost center codes — these are features, not edge cases.
- **Documentation:** Purchase orders, invoices, delivery notes, and credit
  notes must be downloadable and formatted for accounting systems.
- **Pricing transparency:** Contract pricing, tier discounts, and volume
  pricing must be visible and accurate. No "call for pricing" where avoidable.

### Key Patterns
- **Quick order / bulk order:** SKU + quantity entry, CSV upload, repeat
  from order history.
- **Approval workflows:** Requisition → Manager approval → PO generation →
  Fulfillment. Each state clearly visualized.
- **Account hierarchy:** Company → Department → User. Permissions at each level.
- **Catalog management:** Contracted catalog (only items the customer can buy),
  custom pricing, product substitution suggestions when items are unavailable.

---

## 8. AI / ML Products

### The Trust Contract
Users are interacting with a system that is probabilistic, not deterministic.
They can't predict what the AI will do, and neither can you. The design must
make the AI feel capable and honest simultaneously — overconfident AI UX
destroys trust faster than admitting uncertainty.

### Core Design Principles
- **Explainability over magic:** Users need enough transparency to calibrate
  trust. Show what the AI used to reach a conclusion, not just the conclusion.
  "Based on your last 3 uploads" is better than "AI suggests…"
- **Confidence communication:** If the model has low confidence, the UI must
  reflect that. Don't present a 60% confidence result with the same visual
  weight as a 99% one. Use visual hedging: softer color, "(estimated)", ranges
  instead of single values.
- **Graceful failure:** AI will be wrong. Design the failure state before the
  success state. "I'm not sure about this — here's what I found" is a valid
  output. Make it easy to override, correct, or discard AI output.
- **Latency is a design material:** AI responses are slow (1–30s). Latency
  is not a bug to hide — it's a design constraint to design for. Never freeze
  the UI while waiting. Stream, animate, or stage the response.
- **Human control always visible:** The user must always feel in control.
  Every AI action should be reversible, editable, or dismissible. The AI
  suggests; the human decides.

### Visual Language
- **Color:** Neutral-forward. Use a distinct but subtle color to mark AI-generated
  content — not blue (too much like links), not green (too much like success).
  Purple or violet is a common convention for AI attribution. Keep it subtle.
- **Typography:** AI-generated text should be typographically identical to
  user-created content — don't create visual hierarchy that implies AI output
  is more authoritative than it is.
- **Iconography:** A consistent AI indicator icon (sparkle ✦, wand, or abstract
  mark) applied uniformly to all AI-touched content. Never use a robot icon —
  it creates uncanny valley effect.

### Key Components and Patterns

**Streaming text output:**
- Stream tokens as they generate — never wait for full response to display
- Use a blinking cursor or subtle trailing animation to show generation is live
- Allow interruption mid-stream (stop generating)
- On complete: subtle transition (cursor disappears), no jarring jump

**AI action confirmation:**
- For consequential AI actions (drafting an email, deleting records, making
  a booking): show a summary of what the AI will do before it does it
- "AI will send this email to 3 recipients. Review → Send" not "Sending…"
- One-click undo for any AI action that modifies existing content

**Prompt input:**
- Multi-line text area that grows with content (hug height)
- Send on Enter (⌘Enter for newline) — match chat conventions users expect
- Attach / context indicators: show what context the AI has access to
- Suggested prompts for first-time / empty states

**AI attribution:**
- Always mark AI-generated content clearly ("Generated by AI" or the product's
  AI name) — never present AI output as the user's own creation
- Show source or basis where possible ("Based on your project brief")
- Edited AI content: mark as "AI-generated, edited by [user]" for accountability

**Confidence and uncertainty:**
- High confidence: standard presentation
- Medium confidence: "(estimated)" label, softer color, range if numeric
- Low confidence: warning indicator, explicit "I'm not certain — verify this"
- No confidence: don't surface the output — show a "couldn't determine" state instead

**Loading and latency states:**
- < 1s: typing indicator (3-dot pulse) — don't show skeleton
- 1–5s: typing indicator + "Thinking…" or contextual message ("Analyzing your data…")
- 5–15s: progress indicator with stage labels ("Reading → Analyzing → Writing")
- > 15s: progress + time estimate + cancel option
- Never a blank screen while AI processes

**Feedback mechanisms:**
- Thumbs up / thumbs down on every AI output (minimum)
- "Regenerate" — try again with the same input
- "Edit prompt" — refine the input and retry
- Flag for review — for incorrect or harmful outputs

### Compliance and Responsibility
- **AI disclosure:** In many jurisdictions and use cases, disclosing when
  content is AI-generated is legally or ethically required (EU AI Act, FTC).
  Build disclosure into the component system, not as an afterthought.
- **Bias and fairness:** AI outputs can reflect training bias. For consequential
  decisions (hiring, lending, healthcare), design explicit human review steps.
- **Data use transparency:** Tell users what data is sent to the model.
  "Your message and project files are sent to [model] to generate this response."

### What Not to Do
- Anthropomorphize the AI with a name and personality that implies sentience
- Present low-confidence outputs without uncertainty indicators
- Freeze the UI during generation — always show progress
- Auto-apply AI changes without user review for consequential actions
- Use AI to generate content the user will present as their own without disclosure

---

## 9. Developer Tools / DevTools

### The Trust Contract
Users are professional experts. They chose this tool because it helps them
work faster and with more control. Treat them as the most demanding users
you'll ever design for — they will notice every inconsistency, every slow
interaction, and every missing keyboard shortcut. Efficiency is the product.

### Core Design Principles
- **Speed is the feature:** Every interaction must be fast. Load times,
  response times, and animation durations that would be acceptable in consumer
  products are unacceptable here. Target < 100ms for UI interactions.
- **Information density is expected:** Developer tools users work with large
  amounts of information simultaneously. Dense UI is not a flaw — sparse UI
  is an obstacle.
- **Keyboard-first:** Mouse is optional. Every action must be reachable via
  keyboard. Command palette (⌘K) is not a power feature — it's the primary
  navigation mechanism.
- **Precision over guidance:** Don't over-explain. Inline documentation is
  welcome; wizard-style hand-holding is condescending. Trust the user to RTFM.
- **Predictability:** Developer tools must behave the same way every time.
  Unexpected behavior in a production tool causes real damage. Never introduce
  UI surprises in a non-breaking-change update.

### Visual Language
- **Color:** Dark mode is the default expectation, not an option. Light mode
  must exist but is secondary. High contrast preferred. Accent color used
  precisely for interactive elements — no decorative color.
- **Typography:** Monospace for code, logs, terminal output, IDs, and any value
  the user might copy. Monospace must be a design token in the system.
  Sans-serif for UI chrome. Never use a display font.
- **Density:** Compact by default. 32–36px component height. 12–13px base font
  for dense views. Provide comfortable mode — don't force density on all users.
- **Iconography:** Literal and precise. Icons for code concepts must match
  the conventions of the IDE/platform ecosystem (e.g. file type icons matching
  VS Code's icon language). No decorative icons in functional UI.

### Key Components and Patterns

**Code display:**
- Syntax highlighting using a consistent, accessible color scheme
  (test all token colors for 4.5:1 contrast on the background)
- Line numbers: always visible, copyable-line gutter
- Copy button on all code blocks — appears on hover, stays on focus
- Language indicator in the top-right of the block
- Expandable for long blocks (collapse to N lines, expand on click)
- Diff view: green additions, red removals — never color alone, use + and - prefix

**Terminal and log output:**
- Monospace, high contrast on dark background
- ANSI color support — respect the tool's color output
- Auto-scroll to bottom with "scroll to bottom" button when user has scrolled up
- Search / filter within logs — keyboard shortcut to activate
- Clear button — always visible
- Timestamps: relative by default, absolute on hover

**Command palette (⌘K):**
- Opens instantly (< 50ms)
- Fuzzy search across all commands, pages, and records
- Recent commands at the top
- Keyboard navigation only (arrow keys, Enter, Escape)
- Grouped results with category headers
- Show keyboard shortcuts next to commands
- Dismiss on Escape or click outside

**API explorer / request builder:**
- Method selector (GET/POST/PUT/DELETE/PATCH) with color coding
- URL bar with variable highlighting `{{variable}}`
- Tab groups: Params, Headers, Body, Auth
- Response panel: status code (color-coded), time, size, formatted body
- History of recent requests

**Status and system health:**
- Status indicators: dot + label (green/yellow/red) — never color alone
- Uptime % shown with time period ("99.9% last 30 days")
- Incident banners: persistent at top, link to status page
- Degraded state vs outage visually distinct

**Error handling (developer context):**
- Show full error messages — don't truncate or sanitize for a developer audience
- Include: error code, message, stack trace (collapsible), documentation link
- Copy button on error details — developers will paste this into Slack/GitHub
- "Report this issue" with pre-filled context

**Empty states:**
- Show the CLI command or API call to create the first resource
- Link to quickstart documentation
- Sample/seed data option for dev/staging environments

### Navigation Patterns
- Left sidebar: primary navigation, collapsible, keyboard shortcut to toggle (⌘B)
- Breadcrumbs: always for deep hierarchies (project → environment → service → deployment)
- Tabs within a page: for related views on the same resource (Overview, Logs, Metrics, Settings)
- Split pane: common for file explorers, request/response, editor/preview

### Keyboard Shortcuts (must-haves)
| Action | Shortcut |
|---|---|
| Command palette | ⌘K |
| Search | ⌘F or / |
| New resource | ⌘N |
| Save | ⌘S |
| Toggle sidebar | ⌘B |
| Toggle dark/light | no standard, but must exist |
| Go back | ⌘[ |
| Go forward | ⌘] |

Show shortcuts in tooltips, menus, and the command palette — always.

### Compliance and Operational Considerations
- **Audit logging:** Every action a user takes that affects infrastructure or
  data must be logged with timestamp, user, and before/after state.
- **Role-based access:** Admin vs member vs viewer distinctions must be clear —
  show why an action is disabled, not just that it is.
- **API key and secret handling:** Never show full secrets after creation.
  Mask immediately. One-time reveal with confirmation. Copy button always available.
- **Destructive actions:** Type-to-confirm for deletes of production resources.
  Show what will be deleted — count of affected records, downstream dependencies.

### What Not to Do
- Onboarding wizards that block access to the tool
- Animations on data updates (logs, metrics) — this is distracting in a work context
- Hiding error details behind "Something went wrong"
- Removing features to "simplify" the UI without providing an advanced mode
- Auto-formatting or auto-correcting input (developers need exact control)
- Paginating terminal/log output — developers expect continuous scroll

---

## 10. C2C Marketplace (Consumer-to-Consumer)

### The Trust Contract
Neither party is a professional merchant. Buyers can't verify seller quality
upfront; sellers can't verify buyer intent. Trust must be designed into every
touchpoint — the platform IS the guarantor. If the platform feels untrustworthy,
the transaction doesn't happen.

### Core Design Principles
- **Dual-sided trust:** Every screen must serve two audiences with opposing
  needs. Buyers need assurance the product is as described; sellers need
  assurance they'll be paid and protected. Design explicitly for both.
- **Identity and reputation as UI:** Ratings, reviews, verified badges,
  response rate, member-since date, and transaction history are not secondary
  metadata — they are primary trust signals that belong at the top of profiles
  and listings, not buried.
- **Friction in the right places:** Make listing creation easy. Make payment
  simple. But add deliberate friction before irreversible actions (confirm
  purchase, mark as shipped, leave a review) — this reduces disputes.
- **Dispute design is product design:** Every C2C platform will have disputes.
  The resolution flow must be simple, fair-feeling, and fast. Poor dispute UX
  destroys both buyer and seller trust simultaneously.

### Visual Language
- **Color:** Warmer and more community-forward than B2B or Fintech. Trust
  colors (blue, green) for verified states and successful transactions.
  Avoid cold, corporate palettes — the human-to-human nature of C2C benefits
  from warmth.
- **Photography:** User-generated product photography is the norm — design
  image containers that handle inconsistent quality, aspect ratios, and
  backgrounds gracefully. Never assume studio-quality assets.
- **Density:** Medium — enough information to evaluate a listing without
  overwhelming. Listings must be scannable at a glance (image, title, price,
  seller rating).

### Key Components and Patterns

**Listing creation:**
- Step-by-step with progress indicator
- Photo upload first — image is the most important part
- Smart categorization suggestions based on title
- Pricing guidance ("similar items sold for $X–$Y")
- Preview before publish — show exactly how the listing will appear to buyers

**Listing page:**
- Image gallery (swipeable, zoomable) — dominant
- Seller profile inline: avatar, name, rating, response rate, verification badges
- Price + condition + shipping options prominent
- Social proof: "X people watching this", recent sales
- Primary CTA: "Buy Now" or "Make Offer" — clearly differentiated
- Safety tips contextually placed (not hidden in footer)

**Seller profile:**
- Verification badges (ID verified, phone verified, payment method verified)
- Rating with breakdown (communication, accuracy, shipping speed)
- Active listings + sold history
- "Member since" + response time + response rate
- Contact/Follow actions

**Transaction flow:**
- Payment held in escrow until buyer confirms receipt (or auto-release timer)
- Both parties notified at each stage: listed → sold → paid → shipped →
  delivered → complete
- Tracking integration where possible
- "Problem with order" always accessible during active transaction

**Reviews and ratings:**
- Mutual review system (both parties review each other after transaction)
- Blind review reveal (both submitted before either is shown — prevents retaliation)
- Specific dimensions: item as described, communication, shipping speed
- Flag/report option on every review

**Dispute resolution:**
- Step 1: Contact seller (message thread, time-boxed)
- Step 2: Open dispute (structured form: what happened, evidence upload)
- Step 3: Platform review (clear timeline shown)
- Step 4: Resolution (refund / partial refund / dismissed)
- Every step must communicate: what's happening, what's expected, how long it takes

### Compliance
- **Consumer protection laws:** Vary by country — platform must be clear
  about what protections apply to buyers (return policy, fraud protection).
- **Payment regulations:** Peer payment flows must comply with local money
  transmission laws. Never build your own payment flow — use regulated providers.
- **Tax reporting:** In many jurisdictions, platforms must report high-volume
  seller earnings. Design tax info collection into seller onboarding.

### What Not to Do
- One-sided trust design (optimizing only for buyers OR only for sellers)
- Burying safety tips and scam warnings where users won't see them
- Making dispute filing complicated or intimidating
- Auto-releasing payment to sellers before buyer confirmation window expires
- Allowing anonymous sellers for high-value transactions

---

## 11. D2C (Direct-to-Consumer)

### The Trust Contract
The brand IS the product. Users chose to buy directly from the brand rather
than a retailer — they want a relationship, not just a transaction. Brand
storytelling, community belonging, and personalization are expected. The
purchase is the beginning of the relationship, not the end.

### Core Design Principles
- **Brand experience wraps everything:** Every screen — homepage, PDP, cart,
  checkout, post-purchase — must feel like a coherent brand world, not a
  generic storefront. Visual consistency at the pixel level is non-negotiable.
- **Story before sell:** Lead with why the product exists, who made it, and
  what problem it solves before showing price and "Add to Cart." Users who
  understand the brand story convert at higher rates and return more often.
- **Subscription and retention are core, not optional:** D2C economics depend
  on repeat purchase. Subscribe & Save, replenishment reminders, loyalty
  programs, and referral mechanics are product features, not marketing add-ons.
- **Community as product:** UGC (user-generated content), ambassador programs,
  reviews with photos and video, and community spaces are differentiators.
  Design the infrastructure to showcase real customer voices.
- **Own the post-purchase:** The period between purchase and delivery is a
  brand moment. Branded order confirmation, shipping updates, unboxing
  anticipation content, and first-use guidance all happen here.

### Visual Language
- **Color:** Brand-defined and distinctive. D2C brands often own a signature
  color (Glossier pink, Oatly yellow, Athletic Greens green). The color system
  must extend consistently from marketing to checkout to email.
- **Typography:** Often editorial — display fonts in hero sections, refined
  serif or geometric sans for body. Typography carries significant brand weight.
  Must remain legible at all sizes; editorial choices should never sacrifice
  readability.
- **Photography:** Hero-quality product photography and lifestyle imagery are
  non-negotiable. D2C brands win or lose on visual quality. Design image
  containers for multiple orientations (portrait for mobile heroes, landscape
  for desktop).
- **Density:** Low — generous whitespace signals premium positioning. High
  density reads as discount/value, not premium/direct.

### Key Components and Patterns

**Homepage:**
- Hero: full-viewport, brand story or hero product, single CTA
- Social proof: press mentions, review count, key claim ("4.8 stars / 50k reviews")
- Product range overview with editorial photography
- Brand story / founder story section
- UGC gallery (real customer photos)
- Email capture: value-led ("Join 200k subscribers"), not just "Sign up"

**Product Detail Page (PDP):**
- Image gallery: studio shots, lifestyle, detail, scale reference, video
- Product story above fold — brand narrative before specs
- Variant selector (color, size, flavor): visual swatches, not dropdowns
- Subscribe & Save option alongside one-time purchase — clearly differentiated
- Social proof: star rating, review count, key review quotes
- Ingredients / materials / certifications (transparency as trust)
- UGC / real customer photos below the fold
- Bundling / "frequently bought together" — revenue mechanic

**Subscription management:**
- Dashboard showing: next delivery date, products, frequency, quantity
- Easy modification: skip, pause, swap product, change frequency, change date
- Never make cancellation hard to find — earned retention beats forced retention
- Win-back flow on cancel: offer skip, discount, or pause before full cancel

**Loyalty / rewards:**
- Points balance always visible (in nav or account)
- Clear earn and redeem mechanics
- Progress toward next tier shown
- Exclusive member benefits clearly listed

**Post-purchase:**
- Branded order confirmation page (not generic)
- First-use / getting started content (video, guide)
- Refer-a-friend prompt at peak satisfaction moment (right after delivery)
- Review request: timed for after the product has been experienced (not day of delivery)

### What Not to Do
- Generic checkout that doesn't carry brand identity
- Hiding subscription terms or making cancellation deliberately difficult
- UGC that is clearly fake or uniformly positive
- No post-purchase communication beyond a shipping email
- Treating loyalty program as an afterthought tab in account settings

---

## 12. Social Commerce

### The Trust Contract
Users are in discovery mode, not shopping mode. They encounter products while
consuming content — not while searching with purchase intent. The product must
earn attention within a content stream, and the path from "I want this" to
"I bought this" must be as short as possible. Creator authenticity is the
primary trust signal — not the brand, not the platform.

### Core Design Principles
- **Content and commerce are inseparable:** The product listing IS the content.
  Never interrupt content with commerce — integrate them. A product tagged in
  a video must be explorable without leaving the video.
- **Impulse architecture:** The gap between desire and purchase must be seconds,
  not minutes. Guest checkout, saved payment methods, address autofill, and
  one-tap purchase are mandatory. Every additional tap is lost revenue.
- **Creator authenticity over brand polish:** UGC, creator demos, and real
  customer videos convert better than brand photography in social commerce
  contexts. Design product presentation to showcase creator content first.
- **Social proof is real-time:** "X people viewing", "Y sold in the last hour",
  live chat during livestreams — these signals drive urgency without being
  dark patterns when they reflect real data.
- **Mobile-first, thumb-optimized:** Social commerce happens on phones, in
  thumbs-reach. Every CTA, product tag, and purchase button must be in the
  bottom 60% of the screen.

### Visual Language
- **Color:** Platform-adjacent palettes (TikTok: dark backgrounds, neon accents;
  Instagram: clean whites, brand colors). High saturation is acceptable — users
  are calibrated to vibrant content feeds.
- **Typography:** Bold, large, short. Users skim — copy must communicate in
  1–3 words at a glance. Price and CTA must be immediately legible over video
  or photography backgrounds.
- **Video-first containers:** All product cards and hero areas should support
  video natively, not just static images. Design for the video state first,
  image as a fallback.
- **Overlays:** Product tags, prices, and CTAs overlay content — must meet
  contrast requirements against variable backgrounds. Use semi-transparent
  dark scrim behind all text on video.

### Key Components and Patterns

**Shoppable video / post:**
- Product tags: tap to expand product card inline, without leaving content
- Product card (inline): image, name, price, "Buy Now" — 4 elements max
- Swipe up / tap through to full PDP (optional, not required for purchase)
- Creator attribution always visible with tagged products

**In-feed product card:**
- Video or image (auto-play, muted, loop)
- Creator handle + product tag
- Price + primary CTA in bottom overlay
- Heart / share / comment — maintain social interaction alongside commerce
- Scroll to next product — treat as a feed, not a grid

**Livestream commerce:**
- Product showcase rail: currently featured product pinned, recent products
  scrollable below
- Live chat alongside product info — never cover the product
- "Buy Now" button: persistent, prominent during product showcase moments
- Limited quantity / time signals when true: "10 left at this price"
- Replay with product timestamps for post-live content

**Cart in social context:**
- Mini cart: slide-up sheet, not a new page (preserve content context)
- One-tap checkout for returning users (saved payment + address)
- Guest checkout: phone number + payment only (minimum fields)
- Order confirmation: inline, without leaving the platform

**Creator storefronts:**
- Creator's curated product picks (not just brand catalog)
- Commission disclosure (legally required in many jurisdictions): clear, not buried
- Creator's own content featuring the product alongside the listing
- "Shop [Creator]'s picks" as a destination, not just a list

### Compliance
- **FTC / ASA disclosure:** Sponsored content and affiliate links MUST be
  disclosed. Design the disclosure into the creator content UI — not hidden
  in small text. "Ad", "Paid partnership", "#sponsored" must be visible without
  expanding or scrolling.
- **Minor protection:** Age-gating for age-restricted products. No behavioral
  targeting of minors for commerce.
- **Consumer rights:** Return policy, cancellation rights, and seller identity
  must be accessible before purchase — not only in post-purchase confirmation.

### What Not to Do
- Separating content and commerce into different flows (kills conversion)
- Full-page product redirects that lose the user's place in the feed
- Requiring account creation before purchase
- Fake urgency or fake social proof ("Only 2 left!" when there are 200)
- Covering live product demos with chat or UI chrome
- Hiding affiliate/sponsorship disclosure

---

## 13. B2G / B2A (Business-to-Government / Business-to-Administration)

### The Trust Contract
The buyer is a government body or public institution using taxpayer money.
Every decision is auditable, every vendor is accountable, and every interface
will be scrutinized by procurement officers, IT security teams, and compliance
reviewers — not just end users. Professionalism, compliance, and documentation
are the product. Delight is irrelevant.

### Core Design Principles
- **Accessibility is non-negotiable and legally binding:** Government-adjacent
  products in the US must meet Section 508 (based on WCAG 2.1 AA but with
  additional requirements). EU products must meet EN 301 549. This is a legal
  requirement, not a best practice. Any 508 failure is a contract risk.
- **Formal documentation over informal UX:** Government buyers expect formal
  procurement language, contract reference fields, purchase order numbers, and
  structured reporting. Informal copy ("You're all set!") reads as
  unprofessional and erodes trust.
- **Audit trail is the product:** Every action, every change, every access
  must be logged with timestamp, user, and context. This is not a backend
  concern — surface it as a visible feature (activity log, change history,
  export reports).
- **Security posture is visible:** Government buyers assess security visually
  before technical review. Session timeout, MFA requirement indicators,
  encryption status, and data residency information must be surfaced in the UI
  — not only in documentation.
- **Conservative visual language:** Avoid consumer-style animations, playful
  illustrations, and informal design patterns. Clean, neutral, and professional.
  Government buyers distrust interfaces that feel like consumer apps.

### Visual Language
- **Color:** Highly conservative. Navy, dark blue, or institutional gray as
  primary. Accent colors used only for action states and status indicators.
  No gradients, no expressive brand colors. Accessibility-first palette with
  all combinations tested at WCAG AA minimum.
- **Typography:** System fonts or highly legible, neutral typefaces (Inter,
  Source Sans, IBM Plex). No display fonts. All body text minimum 16px.
  All heading hierarchy explicit and consistent.
- **Density:** Medium to high — government users are often processing large
  volumes of vendor or contract data. Dense data tables are expected.
- **Iconography:** Literal and standard. Use recognizable, universally understood
  icons. No abstract or decorative iconography. All icons must have text labels
  — never icon-only for functional actions in B2G context.

### Key Components and Patterns

**Procurement / RFQ forms:**
- Contract reference number field on every relevant form
- Fiscal year, department code, and cost center fields where applicable
- Multi-approver signature workflows with clear status at each stage
  (Submitted → Under Review → Approved → Rejected with reason)
- Form save and resume — procurement forms are long; users must be able to
  return without losing progress
- PDF export of submitted forms — required for paper filing in many agencies

**Compliance and certification display:**
- FedRAMP / StateRAMP authorization level visible in app header or settings
- SOC 2 Type II, ISO 27001, FISMA status accessible from security settings
- Data residency selection and current status (US GovCloud, EU, etc.)
- Accessibility conformance statement link in footer — always

**Reporting and audit:**
- Activity log: user, action, timestamp, affected record — exportable to CSV
- System access log: login history with IP, device, location
- Data export: all reports available as CSV and PDF
- Scheduled reports: set frequency, recipients, delivery format

**User and access management:**
- Role-based access with explicit permission descriptions
- SSO integration (SAML, CAC/PIV card support for US federal)
- Session timeout configurable by admin (often required to be ≤ 30 minutes)
- MFA required by default — cannot be disabled by end users

**Section 508 requirements (beyond WCAG AA):**
- All video content: captions AND audio description
- All documents: must be screen-reader accessible (tagged PDFs)
- No flashing content (seizure risk) — strict 3 flashes per second limit
- Keyboard navigation: 100% of functionality reachable without a mouse
- Focus visible: never suppressed, always high contrast
- Timeout warnings: warn 2 minutes before session expiry, allow extension
- Error identification: errors identified in text, not color alone (WCAG 1.4.1)
- Name, Role, Value: all UI components expose correct ARIA name, role, and value
- Status messages: announced to screen readers without moving focus

### Compliance Landscape
- **US Federal:** Section 508 (VPAT documentation required), FedRAMP (cloud),
  FISMA (security), NIST 800-53 controls
- **US State / Local:** StateRAMP, individual state accessibility laws (CA, NY
  have additional requirements beyond federal)
- **EU:** EN 301 549, GDPR (data handling), accessibility directive for
  public sector websites
- **Procurement documentation:** VPAT (Voluntary Product Accessibility Template)
  is typically required before contract award — design teams must be able to
  produce one accurately

### What Not to Do
- Consumer-style onboarding or marketing language anywhere in the product
- Animations that cannot be disabled (Section 508 / WCAG 2.3.3)
- Icon-only buttons without text labels
- Any accessibility shortcut or bypass that assumes all users are abled
- Storing government data in non-compliant cloud regions
- Informal copy ("Oops!", "You're good to go!") in any government-facing surface
- Launching without a VPAT — this blocks sales to US federal agencies

---

## 14. Domain Crossovers

### Fintech + Healthcare (Insurance, Benefits platforms)
- Combine: fintech's precision for financial figures + healthcare's calm palette
- Avoid: gamification, playful micro-interactions, ambiguous status states
- Required: HIPAA + PCI compliance awareness; conservative disclosure design

### Enterprise + Consumer (Internal tools that also face consumers)
- Dual interface pattern: employee/admin view (dense, keyboard-friendly) +
  customer view (simple, mobile-first, warm)
- Never force consumer users through the same information architecture as
  enterprise admins
- Permission-based feature visibility is the key design mechanism

### SaaS + E-commerce (Usage-based billing, marketplace features)
- Pricing UI must be world-class — it's the trust moment before payment
- Usage meters and billing dashboards need fintech-grade number clarity
- Upgrade prompts: contextual and value-led, never alarming

### C2C + Fintech (Peer payments, split billing)
- Combine fintech's transaction precision with C2C's dual-sided trust design
- Confirmation step before any money movement — even between friends
- Payment status (Pending / Sent / Received / Failed) always surfaced
- Dispute flow must serve both payer and payee — never favor one side
- Mask full account/card details; show only last 4 digits

### D2C + Social Commerce (Brand-led impulse buying)
- Content and commerce fully integrated — the feed IS the storefront
- Brand storytelling wraps the purchase flow end to end
- Social proof (UGC, creator content) embedded directly in product pages
- Subscription mechanics and loyalty programs are core, not add-ons
- One-tap checkout mandatory — brand experience cannot add friction

### Social Commerce + C2C (Creator marketplaces, resale platforms)
- Creator/seller authenticity signals (ratings, verified badge) carry as much
  weight as platform trust signals
- Listing creation must be as simple as posting to social media
- Commission and affiliate disclosure always visible (FTC/ASA requirement)
- Dual review system: buyer reviews seller, seller reviews buyer

### B2G + Enterprise B2B (Government-adjacent commercial tools)
- Full Section 508 + WCAG AA compliance from day one — not retrofitted
- Formal procurement UI patterns (RFQ, PO number, contract reference fields)
- Audit trail and access control as prominent, exportable product features
- VPAT documentation must be accurate and current before any sales process

### AI Products + Enterprise B2B (AI-powered enterprise SaaS)
- AI confidence indicators visible at enterprise data scale
- Human review and override steps non-negotiable for consequential actions
- Audit log must capture AI actions alongside human actions with full attribution
- Enterprise users need to know what the AI produced vs what a human approved

### AI Products + Developer Tools (AI APIs, ML platforms, LLM tooling)
- Streaming output with token counts and latency metrics visible
- Full error detail always — never sanitize model errors for a developer audience
- API key management: mask immediately after creation, copy button always present
- Usage and cost tracking as first-class UI — developers are accountable for spend

---

## Domain Quick Reference

| Domain | Color approach | Density | Primary trust signal | Biggest mistake |
|---|---|---|---|---|
| Fintech | Conservative, blue/green/red precise | High | Number accuracy + confirmation steps | Vague statuses, hidden fees |
| Healthcare | Clinical calm, red = critical only | Low (patient) / High (clinical) | Precision + plain language | Alarm without cause, jargon |
| Enterprise B2B | Neutral, dark navy accent | High | Configurability + audit trail | Hiding power features |
| SMB SaaS | Friendly, moderate accent | Medium | Fast time to value | Overwhelming onboarding |
| E-commerce (B2C) | Brand-expressive, prominent CTA | Medium | Trust badges + reviews | Friction in checkout |
| B2B E-commerce | Functional, minimal | High | Price + availability accuracy | Poor repeat-order UX |
| AI / ML Products | Neutral + subtle AI accent (purple/violet) | Medium | Honest uncertainty + human control | Overconfident output, frozen UI during generation |
| Developer Tools | Dark-mode first, high contrast, monospace | High (compact default) | Speed + keyboard control + full error detail | Wizard onboarding, hidden errors, removing power |
| C2C Marketplace | Warm, community-forward | Medium | Dual-sided trust (buyer + seller) | One-sided trust design, weak dispute UX |
| D2C | Brand-expressive, editorial, story-led | Low–Medium | Brand story + community belonging | Generic checkout, no subscription or retention design |
| Social Commerce | Content-first, vibrant, creator-aligned | Low | Social proof + creator authenticity | Separating content from commerce, slow checkout |
| B2G / B2A | Conservative, accessible, neutral | Medium–High | Compliance + accessibility + audit trail | Section 508 failures, jargon, informal UI patterns |
