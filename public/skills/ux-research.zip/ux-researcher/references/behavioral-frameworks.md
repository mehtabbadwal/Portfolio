# Behavioral Frameworks Reference

Deep library for grounding UX research insights. Every framework here includes:
- What it explains
- How to recognize it in research data
- How to cite it in outputs
- Key source to reference

**Note:** This file covers behavioral interpretation — using frameworks to understand
*why* users behave as they do in research. For applying these principles to UI design
decisions, see `ux-designer/references/psychology-deep-dive.md`.

---

## Table of Contents

1. Cognitive Science
   - Dual Process Theory (System 1 / System 2)
   - Working Memory & Cognitive Load
   - Mental Models
   - Attention & the Cocktail Party Effect
2. Psychology
   - Self-Determination Theory
   - Habit Formation & Cue-Routine-Reward
   - Social Desirability Bias
   - The Intention-Action Gap
   - Peak-End Rule
   - Projection Bias
3. Behavioral Economics
   - Loss Aversion
   - Status Quo Bias / Default Effect
   - Sunk Cost Fallacy
   - Anchoring
   - Optimism Bias / Planning Fallacy
   - Social Proof
   - The Endowment Effect
   - Present Bias
4. Research-Specific Frameworks
   - Jobs-to-be-Done (JTBD)
   - Mental Model Mapping (Indi Young)
   - The Mom Test Principles
5. Key Books & Researchers

---

## 1. Cognitive Science

### Dual Process Theory (System 1 / System 2)
**Source:** Daniel Kahneman, *Thinking, Fast and Slow* (2011)

**What it explains:**
Humans operate on two cognitive systems simultaneously. System 1 is fast, automatic,
pattern-matching, emotional — it runs without effort and governs the vast majority of
daily decisions. System 2 is slow, deliberate, analytical — it engages only when the
problem demands it, and it's effortful.

**How to recognize it in research data:**
- User completes a task fluidly without being able to explain why they did it → System 1
- User pauses, backs up, re-reads → System 2 being recruited (signal of friction or
  novel decision)
- User's stated reasoning contradicts their observed behavior → They're post-hoc
  rationalizing System 1 decisions with System 2 language
- User says "I just knew where to go" → Learned pattern, System 1 pattern match

**Critical research implication:**
What users say in an interview is almost entirely System 2. What they do in a usability
session is mostly System 1. This is why interviews and observation must be paired —
neither alone gives you the full picture.

**How to cite:** "Kahneman's dual process model suggests this behavior is System 1 —
habitual and automatic — which means users won't be able to accurately report it in
interviews. Usability observation is required to surface the real pattern."

---

### Working Memory & Cognitive Load
**Source:** George Miller (1956), John Sweller (1988); expanded by Kahneman

**What it explains:**
Working memory holds approximately 4 discrete chunks simultaneously (revised from
Miller's original 7±2). Every unfamiliar decision, unclear label, or ambiguous state
consumes a chunk. When the limit is hit, users abandon, make errors, or defer.

**How to recognize it in research data:**
- User abandons a task mid-way without explanation → Working memory overflow
- User makes an error then immediately recovers → Chunking failure at a specific step
- User slows down at a specific screen consistently across participants → That screen
  has a cognitive load problem
- User asks "wait, where am I?" → Lost the thread — working memory cleared

**How to cite:** "Across 4/5 participants, hesitation clustered at the permissions
step. Sweller's cognitive load theory suggests this step is demanding more working
memory than available — users are managing both the decision and the unfamiliar
interface simultaneously."

---

### Mental Models
**Source:** Kenneth Craik (1943); expanded by Don Norman, *The Design of Everyday
Things* (1988/2013); Indi Young, *Mental Models* (2008)

**What it explains:**
Users arrive with an internal map of how a system *should* work, built from prior
experience with similar products. When a product's actual structure differs from this
map, users experience confusion — not because the product is complex, but because it
violates expectations.

**How to recognize it in research data:**
- User navigates to the wrong section first → Their mental model maps that function
  differently
- User uses wrong terminology for a feature → Their model has a different label for it
- User is surprised by what they find in a location → The information architecture
  doesn't match their model
- User's workaround reveals structure → Their workaround mirrors how they think the
  product should be organized

**Research technique:** Ask "If you were designing this, where would you look for X?"
The answer reveals their mental model directly.

**How to cite:** "The navigation error pattern suggests a mental model mismatch —
users' prior experience with [category] has established an expectation that [X] lives
under [Y], not under [Z]. Don Norman's gulf of evaluation applies here: users cannot
reconcile what they see with what they expected."

---

### Attention & Selective Filtering
**Source:** Cherry (1953) "cocktail party effect"; Treisman's feature integration theory

**What it explains:**
Attention is selective and finite. Users don't see everything on a screen — they see
what their current goal makes salient. Elements that don't match their active task
frame are filtered out, regardless of visual prominence.

**How to recognize it in research data:**
- User misses an obvious UI element → It was filtered because it didn't match their
  active goal frame
- User says "I didn't see the button" when it's clearly visible → Attentional filtering,
  not visibility problem
- User notices an element on the 3rd session that they ignored in the first two →
  Their goal frame has changed

**How to cite:** "Three participants missed the export option despite it being visible
in the toolbar. This is attentional filtering — the option wasn't aligned with their
active goal state at the moment they needed it. Placement and timing are the
intervention, not size or color."

---

## 2. Psychology

### Self-Determination Theory
**Source:** Deci & Ryan (1985, 2000); *Self-Determination and Intrinsic Motivation
in Human Behavior*

**What it explains:**
Humans have three core psychological needs that drive intrinsic motivation:
- **Autonomy** — the sense that actions are self-chosen
- **Competence** — the sense of growing skill and effectiveness
- **Relatedness** — the sense of meaningful connection to others

When products violate any of these, engagement drops — not because of usability, but
because the product's psychological architecture undermines motivation.

**How to recognize it in research data:**
- User feels "herded" by the product → Autonomy violation
- User avoids advanced features out of fear of "breaking something" → Competence threat
- User doesn't see value in collaboration features → Relatedness is not activated
- User describes the product as "making decisions for me" → Autonomy violation

**How to cite:** "The interview data reveals an autonomy violation — users describe
the automation as removing decision-making they want to retain. Per Deci & Ryan's
Self-Determination Theory, automation that reduces perceived control reduces intrinsic
motivation to engage, even when it produces better outcomes."

---

### Habit Formation & Cue-Routine-Reward
**Source:** Charles Duhigg, *The Power of Habit* (2012); B.J. Fogg, *Tiny Habits* (2019)

**What it explains:**
Behaviors become habits through a loop: Cue (trigger) → Routine (behavior) →
Reward (reinforcement). Existing habits are extremely resistant to change — users
will often continue a worse behavior over a better new one if the existing behavior
has a strong cue-reward loop already established.

**How to recognize it in research data:**
- User continues using an inferior workaround despite knowing about a better feature →
  Existing habit loop is stronger than the new behavior's reward
- User adopts a new feature in the context where they're already doing a related thing →
  Piggybacking on an existing cue
- User can't explain why they start a task a certain way → It's a cued habit, not
  a deliberate choice

**How to cite:** "Users continue to manage project updates in Slack despite having a
dedicated feature in the product. Duhigg's habit loop suggests the Slack behavior has
a stronger cue-reward structure — the notification is the cue, the quick reply is the
routine, the social acknowledgment is the reward. The product's feature lacks an
equivalent cue and reward chain."

---

### Social Desirability Bias
**Source:** Edwards (1953); extensively documented in survey and interview methodology

**What it explains:**
When asked questions in a research context, participants answer in ways that make
them appear more rational, competent, and positive than reality. They underreport
negative behaviors, overreport organized behaviors, and describe an idealized version
of their workflow.

**How to recognize it in research data:**
- Stated workflow is suspiciously tidy compared to observed workflow
- User describes current behavior as "usually" or "mostly" working well
- User predicts high frequency of a behavior they actually do rarely
- User is reluctant to criticize a competitor or current product by name

**Research defense:**
- Use behavioral questions, not opinion questions ("When did you last..." vs "How often do you...")
- Use task observation, not self-report, for behavioral data
- Create psychological safety: "We're evaluating the product, not evaluating you"
- Ask about others: "When do you see colleagues struggle with this?" often surfaces
  problems the participant won't claim personally

**How to cite:** "Stated frequency data from this interview should be treated with
caution — social desirability bias is likely inflating reported usage. The observed
session data is a more reliable signal."

---

### The Intention-Action Gap
**Source:** Sheeran (2002); Kahneman; also the foundation of Fogg's behavioral model

**What it explains:**
Humans reliably overpredict their own future behavior. They form intentions with
System 2, but behavior is executed by System 1. The gap between "I intend to do X"
and "I actually do X" is enormous — often 50%+ for new behaviors.

**How to recognize it in research data:**
- User says "I would definitely use that feature" → Discount heavily
- User describes an ideal future workflow that differs significantly from their
  current one → The gap between ideal and actual is the design opportunity
- "Would you pay for this?" receives positive answers → Stated willingness to pay
  is typically 3–5x actual willingness

**Research rule:** Never build a business case on stated intention data alone.
Pair with behavioral observation or existing behavioral proxies.

**How to cite:** "Positive stated intent from 6/8 participants is not a reliable
indicator of adoption. The intention-action gap — Sheeran's research shows stated
intentions predict only 20–30% of behavior — means observed proxy behaviors are
the more reliable signal."

---

### Peak-End Rule
**Source:** Kahneman & Fredrickson (1993), *When More Pain Is Preferred to Less*

**What it explains:**
People judge an experience by the emotional peak (best or worst moment) and
the ending — not by the average. Duration is largely ignored. This means a
product with one terrible moment is remembered as terrible, even if everything
else was fine.

**How to recognize it in research data:**
- User describes an overall experience negatively, but can only specifically name
  one frustrating moment → That moment is the peak-negative
- User remembers a flow positively despite several minor frictions → The ending
  was satisfying
- Ratings are driven by a single incident, not aggregate experience

**Research implication:** In synthesis, weight peak moments and endings more heavily
than average friction. Repairing a peak-negative moment has disproportionate impact
on overall experience perception.

**How to cite:** "User satisfaction ratings are being disproportionately driven by
the payment confirmation step — the peak-negative moment in the flow. Kahneman's
peak-end rule predicts this: fixing one high-friction endpoint will move overall
satisfaction more than smoothing ten minor frictions elsewhere."

---

### Projection Bias
**Source:** Loewenstein, O'Donoghue & Rabin (2003)

**What it explains:**
Humans predict their future preferences based on their current state. They
systematically underestimate how differently they'll feel, think, or behave in
a future context — projecting their present experience onto the future.

**How to recognize it in research data:**
- User predicts high usage of a feature they've never used
- User's stated frequency for future behavior is higher than their historical behavior
- User designs for their current skill level, not their future one (novice assumes
  they'll always be a novice; expert assumes everyone is an expert)

**How to cite:** "Projection bias is likely inflating reported interest here — users
are predicting their future behavior from their current context, which includes
active engagement in a research interview about this exact topic."

---

## 3. Behavioral Economics

### Loss Aversion
**Source:** Kahneman & Tversky, Prospect Theory (1979); Kahneman, *Thinking, Fast
and Slow* (2011)

**What it explains:**
Losses feel approximately twice as painful as equivalent gains feel good. This
asymmetry shapes decision-making in ways users are not consciously aware of.

**How to recognize it in research data:**
- Users are reluctant to delete, archive, or remove anything → Fear of losing
  something is stronger than desire to organize
- Users hesitate before destructive actions despite understanding they're reversible
- Users cite potential downside of a new feature as reason for not adopting, even
  when upside is larger
- "I might lose my work" is disproportionately weighted against "I might save time"

**How to cite:** "User reluctance to migrate to the new workflow aligns with loss
aversion — Kahneman & Tversky's research shows potential losses are weighted 2x
more heavily than equivalent gains. The migration framing is emphasizing what users
leave behind rather than what they gain."

---

### Status Quo Bias / Default Effect
**Source:** Samuelson & Zeckhauser (1988); Thaler & Sunstein, *Nudge* (2008)

**What it explains:**
Humans have a strong preference for the current state of affairs. Any change from
the default is perceived as a loss, even when the new state is objectively better.
Defaults have enormous power — they are chosen by a majority even when opting out
is trivially easy.

**How to recognize it in research data:**
- Users continue using a feature they describe as suboptimal → Status quo
- Users haven't changed a default setting despite knowing a better configuration exists
- Users who were never shown a feature and users who adopted it behave identically →
  The feature failed to displace the default behavior

**How to cite:** "The data shows status quo bias — users have never changed the
default notification settings despite expressing a preference for different behavior.
Thaler & Sunstein's nudge research shows the default is effectively a choice made
on behalf of the user. The design intervention is to change the default, not to
make the setting more discoverable."

---

### Sunk Cost Fallacy
**Source:** Arkes & Blumer (1985); Thaler (1980)

**What it explains:**
Humans irrationally factor in past costs (time, money, effort) when making
current decisions, even though past costs are unrecoverable and economically
irrelevant to future decisions.

**How to recognize it in research data:**
- User continues using a product they dislike because they've "already invested so
  much time setting it up"
- User won't switch to a competitor despite preferring it, because of existing data
  in current tool
- User describes sunk investment as a reason for loyalty more than current value

**Research implication:** Sunk costs are a switching cost signal. Users are not
loyal to your product — they're trapped by their past investment. These users are
vulnerable the moment a competitor provides a migration path.

**How to cite:** "Reported loyalty in this segment appears driven by sunk cost rather
than active preference. Three participants cited 'the time I've already put in' as
their primary retention driver. This is a warning signal, not a loyalty signal."

---

### Anchoring
**Source:** Tversky & Kahneman (1974), *Judgment Under Uncertainty*

**What it explains:**
The first piece of information encountered becomes a reference point (anchor)
that disproportionately influences all subsequent judgments, even when the
anchor is arbitrary or irrelevant.

**How to recognize it in research data:**
- Users compare your product to a specific competitor unprompted → That competitor
  is their anchor; your product will be evaluated relative to it, not on its own terms
- Users describe a feature as "expensive" or "cheap" relative to what they've seen
  before, not on absolute terms
- Users' mental model of "what this should cost" is anchored to a specific competitor's
  pricing

**How to cite:** "Participants are anchoring their evaluation of this feature to
[Competitor X]'s implementation. Tversky & Kahneman's anchoring effect means that
product decisions made in reference to this anchor will be consistently biased
toward that comparison — the design language and positioning need to consciously
break the anchor."

---

### Optimism Bias & Planning Fallacy
**Source:** Tversky & Kahneman (1974); Buehler, Griffin & Ross (1994)

**What it explains:**
Humans systematically overestimate future capabilities, underestimate future
obstacles, and underestimate how long things will take — even after repeated
experiences of being wrong.

**How to recognize it in research data:**
- Users predict much faster workflow with a new tool than current reality supports
- Users believe they'll engage with complex features once they "have time to learn it"
- Users consistently underestimate how long their current process actually takes
  when asked to reflect

**How to cite:** "User estimates of time-saving should be discounted — planning
fallacy is likely inflating predicted efficiency. Buehler's research shows people
underestimate task duration by 25–50% even for tasks they've done before."

---

### Social Proof
**Source:** Robert Cialdini, *Influence* (1984); Milgram (1961)

**What it explains:**
In uncertain situations, humans look to others' behavior as a signal of the
correct action. What others are doing functions as evidence of what is right,
safe, or normal.

**How to recognize it in research data:**
- Users cite "other teams in our company use it" as a key adoption signal
- Users are more willing to try features they've seen peers use
- Users describe adoption barriers in terms of "no one on my team is doing it yet"
- Trust in a product grows when users see usage evidence from similar users

**How to cite:** "Adoption is blocked by a social proof vacuum — early enterprise
users won't adopt without seeing evidence that peers in similar roles have already
done so. Cialdini's social proof principle suggests the go-to-market strategy needs
a visible reference customer in the user's own segment."

---

### The Endowment Effect
**Source:** Thaler (1980); Kahneman, Knetsch & Thaler (1990)

**What it explains:**
People value things more once they own them. The act of ownership — even
brief or psychological — increases perceived value significantly.

**How to recognize it in research data:**
- Users assign more value to features they've already set up vs. identical
  features they haven't tried
- Users reluctant to abandon a customization they've made, even when a better
  default exists
- Users who've done onboarding exhibit higher retention unrelated to actual value
  delivered → Onboarding created psychological ownership

**How to cite:** "The configuration step is creating endowment effect — users who
complete setup are more likely to attribute value to the product before experiencing
it. This is partly illusory but behaviorally real."

---

### Present Bias (Hyperbolic Discounting)
**Source:** Laibson (1997); O'Donoghue & Rabin (1999)

**What it explains:**
Humans heavily discount future rewards relative to immediate ones — far more
than rational economic models would predict. The gap between "I'll do it tomorrow"
and "I'm doing it now" is much larger than the gap between "day 30" and "day 31."

**How to recognize it in research data:**
- Users defer setup, configuration, or onboarding steps they describe as "not urgent"
  → Present bias; the future benefit isn't motivating enough
- Features designed for long-term value are adopted less than features with
  immediate feedback
- Users consistently put off tasks they agree are important

**How to cite:** "The deferred onboarding pattern reflects present bias — users
are discounting the future value of setup completion in favor of immediate usage,
even when they understand setup would improve the experience. The design intervention
is to make immediate value visible before or during setup."

---

## 4. Research-Specific Frameworks

### Jobs-to-be-Done (JTBD)
**Source:** Clayton Christensen, *The Innovator's Solution* (2003); Tony Ulwick,
*Jobs to be Done* (2016); Bob Moesta; Alan Klement, *When Coffee and Kale Compete* (2018)

**What it explains:**
Users don't buy products — they hire them to do a job. The "job" is the progress
the user is trying to make in a specific circumstance. Understanding the job (not
the feature) reveals what users actually need and who your real competition is.

**Job statement format:**
`When [situation], I want to [motivation], so I can [expected outcome].`

**Three job levels:**
- **Functional job** — the practical task (manage project timelines)
- **Emotional job** — how they want to feel doing it (in control, confident)
- **Social job** — how they want to be perceived (as the organized one, the leader)

**How to recognize it in research data:**
- User's workaround reveals the true functional job better than their stated need
- User compares product to something in a completely different category →
  That category is actually competing for the same job
- User's emotional language ("I just want to feel less stressed about this") reveals
  emotional job more than functional
- User switches products after a "push" (something that made the old way painful) and
  "pull" (something that made the new way attractive)

**Research interview technique:**
Ask "Tell me about the last time you hired a tool to help you with this."
Ask "What was happening in your work life that made you start looking for a solution?"
These surface the switch event — the moment of maximum insight.

**How to cite:** "The JTBD analysis reveals the functional job is 'maintain stakeholder
confidence during uncertain project phases' — not 'track tasks.' This reframes the
competitive set from task managers to status communication tools."

---

### Mental Model Mapping
**Source:** Indi Young, *Mental Models* (2008); *Practical Empathy* (2015)

**What it explains:**
A mental model map aligns what users are trying to accomplish (their mental space)
with what a product offers (the product space). Gaps between the two reveal design
opportunities; overlaps reveal where the product is well-matched.

**Research technique:**
1. Interview users about their behavior and reasoning (not about the product)
2. Extract behavioral units: small, discrete actions or decisions
3. Group behavioral units into mental spaces (user-defined categories)
4. Build the map: user mental spaces on top, product features below
5. Identify gaps (mental spaces with no product coverage) and mismatches

**How to cite:** "Young's mental model mapping applied to interview data reveals two
user mental spaces — 'understanding where the project stands' and 'communicating
status without losing work context' — that have no corresponding product support.
These are the white spaces."

---

### The Mom Test Principles
**Source:** Rob Fitzpatrick, *The Mom Test* (2013)

**What it explains:**
Most user research fails because people are naturally polite and will say what they
think you want to hear. The Mom Test reframes questions so they're impossible to
answer politely and falsely.

**Core rules:**
1. Talk about their life, not your idea
2. Ask about specifics in the past, not generics or hypotheticals about the future
3. Talk less, listen more

**Good question patterns:**
- "Tell me about the last time you had to deal with [problem]"
- "Walk me through what you did"
- "What else did you try before that?"
- "How are you handling it now?"
- "How much is that costing you?" (time, money, frustration)

**Bad question patterns (always reframe these):**
- "Would you use X?" → Ask: "How do you currently handle X?"
- "Do you think X is a good idea?" → Ask: "Have you ever paid for anything like X?"
- "How often would you use X?" → Ask: "How often do you currently do Y?"

**How to cite:** "Interview guides should follow Fitzpatrick's Mom Test protocol —
all questions must be anchored to past behavior to prevent social desirability bias
from contaminating the data."

---

## 5. Key Books & Researchers

These are the primary sources this skill draws from. Cite by author + work when
grounding insights.

| Author | Work | Core Contribution to UX Research |
|---|---|---|
| Daniel Kahneman | *Thinking, Fast and Slow* (2011) | Dual process theory, cognitive biases, prospect theory |
| Richard Thaler & Cass Sunstein | *Nudge* (2008) | Default effects, choice architecture, behavioral design |
| Dan Ariely | *Predictably Irrational* (2008) | Irrational but systematic human decision-making |
| Clayton Christensen | *The Innovator's Dilemma / Solution* | Jobs-to-be-Done framework |
| Robert Cialdini | *Influence* (1984) | Social proof, commitment, reciprocity, authority |
| Don Norman | *The Design of Everyday Things* (1988/2013) | Mental models, affordances, feedback, error |
| Indi Young | *Mental Models* (2008), *Practical Empathy* (2015) | Mental model mapping, empathy in research |
| Rob Fitzpatrick | *The Mom Test* (2013) | Interview methodology, eliminating false positives |
| Steve Krug | *Don't Make Me Think* (2000/2014) | Usability heuristics, simplicity, cognitive effort |
| Steve Portigal | *Interviewing Users* (2013) | Interview craft, probing techniques, building rapport |
| B.J. Fogg | *Tiny Habits* (2019) | Behavior change, habit formation, motivation + ability |
| Charles Duhigg | *The Power of Habit* (2012) | Habit loops, cue-routine-reward, organizational habits |
| Alan Klement | *When Coffee and Kale Compete* (2018) | JTBD applied to product strategy and switching |
| Erika Hall | *Just Enough Research* (2013) | Pragmatic research methods, organizational research culture |
