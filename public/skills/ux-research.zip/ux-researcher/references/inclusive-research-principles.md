# Inclusive Research Principles

Foundational framework for conducting research with participants who fall outside
the implicit default the field was built around: non-disabled adults aged 18–64,
comfortable with technology, native speakers of the research language.

Read this file before designing any study that involves non-default populations.
Then read the relevant specialist file:
- `neurodivergent-research.md` — ASD, ADHD, dyslexia, cognitive/intellectual disabilities,
  sensory/motor impairments, mental health conditions
- `age-specific-research.md` — children by age band, teenagers, older adults

---

## The Core Mindset Shift

Standard UX research was designed by and for a narrow slice of humanity. Most
methods assume: sustained attention for 60 minutes, comfort with screen share,
fluent verbal communication, ability to "think aloud" naturally, no anxiety about
being observed, and familiarity with research as a concept.

When these assumptions break down, researchers often diagnose the participant as
a poor fit — wrong segment, too nervous, not articulate enough. The correct
diagnosis is almost always: wrong method, wrong environment, wrong facilitation.

**Inclusive research is not research with lower standards. It is research with
higher craft.** The obligation is to design around the participant, not to filter
out participants who don't fit the design.

---

## Universal Accommodation Principles

These apply to every non-default population before you reach population-specific guidance.

### 1. Separate capability from behavior
Never confuse a participant's communication style, response time, or interaction
pattern with their ability to use a product or provide valid data. A participant
who takes 20 seconds to respond isn't confused — they may be processing carefully.
A participant who uses AAC (augmentative and alternative communication) isn't a
weaker research subject — they may be the most precise communicator in the room.

### 2. Accommodation is not special treatment — it is access
Accommodations don't change what you're researching. They change whether the
participant can actually participate. An accessible session and an inaccessible
session are not two versions of the same study — only one of them is a real study.

### 3. Ask, don't assume
The single most important thing you can do before a session with any non-default
participant: ask what they need. Not "do you need any special help?" (othering)
but "Is there anything about how we run the session that would help you do your
best work?" Most participants know exactly what they need and are rarely asked.

### 4. Match the method to the person, not the other way around
Think-aloud works well for some populations and is actively counterproductive for
others (ASD, high anxiety, certain cognitive profiles). The session format is a
variable — adjust it. The research question is not.

### 5. Design the environment before the session
- Lighting, background noise, screen contrast, font size, session length — these
  are research design decisions, not logistics.
- Remote sessions introduce different barriers (tech setup, caregiver presence,
  physical environment you can't control) and different affordances (participant
  is in their natural environment, no travel required).
- Always send a clear pre-session brief: what will happen, how long, what they'll
  see, who else is on the call, and how to tell you if they need a break.

---

## Consent Framework for Non-Default Populations

Standard informed consent assumes: reading comprehension, decision-making autonomy,
and understanding of abstract concepts like "data will be used for research."
These assumptions frequently don't hold.

### Layered consent model
Apply consent at multiple levels, appropriate to the population:

**Level 1 — Gatekeeper consent (when required)**
Parent/guardian for minors. Legal guardian for adults with cognitive/intellectual
disabilities where decision-making capacity is legally assigned. Institutional
approval for healthcare, government, or workplace settings.

**Level 2 — Participant assent**
Even when gatekeeper consent is required, the participant must actively agree to
participate. Assent is not the same as consent — it's a simplified, accessible
version. If a participant shows reluctance, distress, or withdrawal — even if the
gatekeeper consented — stop.

**Level 3 — Ongoing consent**
Consent is not a one-time event at the start of a session. Check in. Watch for
signs of discomfort. Make it easy and consequence-free to stop at any time — and
say this out loud, in plain language, more than once.

### Plain language consent
For any population where reading comprehension or cognitive processing may be
a factor, rewrite consent materials in plain language:
- Short sentences. One idea per sentence.
- No passive voice.
- Concrete over abstract: "We will record the video call" not "the session may
  be captured for research purposes."
- Offer audio or verbal consent as an alternative to written sign-off.

### Recording consent — treat separately, always
Recording is a higher-stakes consent item than participation. Many participants
who are comfortable being observed are not comfortable being recorded. Treat these
as separate decisions. Confirm recording consent immediately before recording starts,
not buried in pre-session paperwork.

---

## Recruitment Principles

### Don't recruit "representative" — recruit real
The goal is not a statistically representative sample of a disability or age group.
The goal is participants who reflect actual users of or potential users of the product.
Recruit for behavior and context first, population second.

### Work with community organizations, not just panels
Research panels systematically underrepresent non-default populations. Connect with:
- Disability organizations and advocacy groups
- Special education programs (for younger populations)
- Senior centers and age-related support organizations
- Neurodivergent community spaces (online and offline)
- Healthcare networks and patient communities

These channels produce better participants and build research relationships that
panels can't replicate.

### Compensation
Non-default participants often face higher time and effort costs to participate:
travel barriers, preparation time, caregiver coordination, energy cost of participation.
Compensate accordingly. Never ask non-default participants to participate for "exposure"
or "to help improve the product" without meaningful compensation.

### Screen for fit, not capability
Screeners for non-default populations should assess behavioral fit (do they use or
need the type of product you're studying?) not cognitive or physical ability. The
research method accommodates the participant — the screener doesn't filter out
anyone who needs an accommodation.

---

## Facilitation Principles

### Set pace by the participant
Remove all internal pressure to get through your guide. If a participant needs
more time, the guide shortens. Never rush. Silence is not a problem to solve.

### Avoid idiom, metaphor, and jargon
"Walk me through..." / "paint me a picture..." / "what's your gut feeling?" —
these are idiom-heavy. For participants who interpret language literally or for
whom the research language is not their first language, plain instruction is more
reliable. "Tell me what you did first" beats "walk me through what happened."

### Have a distress protocol ready
Know in advance what you will do if a participant shows distress. In most cases:
pause, acknowledge, offer a break or to stop entirely, do not probe the distress.
For healthcare, mental health, or crisis-adjacent products, have support resources
prepared to share if needed.

### Never correct behavior during a session
A participant using a product "incorrectly" is not making a mistake — they are
providing data. Do not guide them toward the intended path. Do not say "actually,
you'd want to click here." Observe and record what they do and why.

### Co-facilitation when possible
For populations where behavioral signals are dense or where the facilitation
workload is high (young children, complex accessibility needs), a second person
observing and note-taking frees the facilitator to focus entirely on the participant.

---

## Analysis and Reporting

### Never pathologize the behavior
The participant is not the problem. The design is the problem. Frame findings in
terms of design gaps, not participant deficits. "The confirmation screen failed to
communicate finality to participants who process information non-linearly" is a
design finding. "Participants with ASD had trouble understanding the confirmation
screen" is a deficit framing that produces no actionable design direction.

### Segment findings by population where relevant
A usability finding from an autistic participant is not automatically a universal
finding — and it may reveal a gap that affects a much broader population than
the specific group it was observed in. Report the source population and consider
the broader implication separately.

### Anonymize more aggressively
Disability status, age, and neurodivergent identity are sensitive. Remove or
generalize these attributes in any finding that will be shared beyond the core
research team unless the participant has explicitly consented to identification.

### Watch for findings that reveal universal problems
Many accessibility findings reveal problems that affect everyone under stress,
in unfamiliar contexts, or under cognitive load. A navigation pattern that fails
for a user with a cognitive disability under controlled conditions will likely
fail for a non-disabled user under real-world stress. Report these as universal
risk signals, not edge cases.

---

## Reference File Index

| File | When to Read |
|---|---|
| `neurodivergent-research.md` | Research with ASD, ADHD, dyslexia, cognitive/intellectual disabilities, sensory/motor impairments, mental health conditions |
| `age-specific-research.md` | Research with children (by age band), teenagers, and older adults |
