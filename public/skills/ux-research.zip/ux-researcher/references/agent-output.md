# Agent Output Format Reference

Structured schema for outputs consumed by the Competitive Intel Digest agent.
When producing competitive research outputs intended for the agent pipeline,
always use this format exactly. Field names and structure must be consistent
for the agent to parse correctly.

---

## When to Use This Format

Switch to this output mode when:
- The request explicitly involves competitive research intended for the agent pipeline
- The user asks for "agent-ready" or "structured" competitive output
- Output Mode C is selected in the main SKILL.md

Do NOT use this format for:
- Internal synthesis (use Mode A)
- Stakeholder presentations (use Mode B)
- General research that happens to touch on competitors

---

## The Schema

Each competitive intelligence entry uses this structure. Every field is required
unless marked [optional].

```
---COMPETITIVE_INTEL_ENTRY---

competitor: [Exact product name]
date: [YYYY-MM-DD — date the signal was observed or review was posted]
source: [one of: app_store_ios | app_store_android | g2 | capterra | reddit |
         linkedin | changelog | blog | twitter | forum | other]
source_url: [Direct URL to the source — required unless source is 'other']

signal_type: [one of: unmet_need | feature_gap | user_sentiment_negative |
              user_sentiment_positive | strategic_shift | pricing_signal |
              adoption_barrier | competitive_comparison]

user_segment: [Who this signal is from — be specific if identifiable.
               Examples: "enterprise PM at 200+ person company",
               "solo freelancer", "team lead in construction",
               "unknown" if not determinable]

raw_finding: [Verbatim quote or precise behavioral description — no interpretation.
              If from a review, use the exact quote. If from product usage
              observation, describe the behavior precisely.]

behavioral_framework: [Name of the framework from behavioral-frameworks.md that
                       explains why this signal matters.
                       Examples: "Status quo bias", "JTBD — functional job gap",
                       "Intention-action gap", "Social proof vacuum",
                       "Sunk cost — switching barrier"]

user_need_revealed: [One sentence: what job or need does this signal reveal,
                     in user language not feature language]

implication_for_product: [One sentence: what this means specifically for product
                          positioning, design, or strategy — must be concrete]

confidence: [high | medium | low]
            high = verbatim user quote, behavioral observation, or 5+ similar signals
            medium = inferred from indirect evidence, 2–4 similar signals
            low = single source, stated not observed, or speculative

priority: [urgent | monitor | archive]
          urgent = directly relevant to current product decisions or positioning
          monitor = relevant trend worth tracking over time
          archive = weak signal or low relevance to current strategy

---END_ENTRY---
```

---

## Multi-Entry Batches

When producing multiple entries from a single competitive research session,
output them sequentially. Each entry must be complete and self-contained.
Do not reference other entries within a single entry.

**Batch header (include once at the top):**
```
---COMPETITIVE_INTEL_BATCH---
session_date: [YYYY-MM-DD]
researcher: [ux-researcher skill — competitive mode]
competitors_covered: [list]
sources_used: [list]
total_entries: [n]
session_notes: [Any important context about this batch — methodology,
                time period covered, limitations]
---BATCH_HEADER_END---
```

---

## Example Entry (Completed)

```
---COMPETITIVE_INTEL_ENTRY---

competitor: Linear
date: 2026-02-14
source: reddit
source_url: https://reddit.com/r/projectmanagement/comments/[id]

signal_type: user_sentiment_negative

user_segment: engineering team lead at mid-size startup (inferred from post context)

raw_finding: "Linear's AI prioritization is great in theory but I end up overriding
it 80% of the time. I don't trust that it understands what's actually blocking us
vs what just looks blocked on paper."

behavioral_framework: Intention-action gap + low AI trust / transparency deficit

user_need_revealed: Users need to understand the reasoning behind AI-generated
priorities before they'll act on them — not just see the output

implication_for_product: Transparency of AI reasoning is a differentiator, not
a nice-to-have. Users who see why a priority was set adopt it; users who don't
override it. Buildrooms' design should surface reasoning inline, not on demand.

confidence: medium
priority: urgent

---END_ENTRY---
```

---

## Agent Consumption Notes

The Competitive Intel Digest agent will:
1. Ingest all entries from a batch
2. Group entries by `signal_type` and `competitor`
3. Identify cross-competitor patterns in `user_need_revealed`
4. Escalate `urgent` entries to a weekly brief
5. Archive `monitor` entries to a running signal log
6. Synthesize `behavioral_framework` patterns to identify systemic gaps

**For agent parsing to work correctly:**
- Field names must be exact — do not paraphrase or rename
- Signal types must use the exact values listed — do not invent new ones
- `raw_finding` must not contain interpretation — save that for `implication_for_product`
- All entries must open with `---COMPETITIVE_INTEL_ENTRY---` and close with `---END_ENTRY---`

---

## Signal Type Guide

| signal_type | When to use |
|---|---|
| `unmet_need` | Users are trying to do something the product doesn't support |
| `feature_gap` | A specific capability is missing or significantly weaker than alternatives |
| `user_sentiment_negative` | Strong frustration or disappointment expressed by users |
| `user_sentiment_positive` | Strong delight or preference expressed by users (also useful) |
| `strategic_shift` | A competitor is moving into a new market, segment, or positioning |
| `pricing_signal` | A competitor has changed pricing structure, triggering user reaction |
| `adoption_barrier` | Users who want to adopt the product are blocked from doing so |
| `competitive_comparison` | A user explicitly compares two products in a meaningful way |

---

## Confidence Calibration Guide

**High confidence:**
- Verbatim user quote expressing the finding directly
- Observed behavior (not stated preference)
- 5 or more independent sources expressing the same finding
- Quantified evidence (e.g. "over 40 reviews mention...")

**Medium confidence:**
- Inferred from indirect evidence (e.g. a workaround implies a gap)
- 2–4 independent sources expressing the same finding
- Single high-quality source (e.g. a detailed power-user post)

**Low confidence:**
- Single source, not independently verified
- Stated preference rather than observed behavior
- Speculation or extrapolation beyond the data
- Old source (12+ months) in a fast-moving space
