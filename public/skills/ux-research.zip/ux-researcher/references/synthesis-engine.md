# Synthesis Engine Reference

Structured worksheets and techniques for working through complex synthesis.
Read when you have raw research data and need to move it through to insight
and opportunity — especially with large amounts of data or contradictory findings.

---

## Table of Contents

1. The Four-Phase Synthesis Model
2. Affinity Mapping (the clustering process)
3. Insight Laddering (behavior → need → value)
4. Opportunity Framing (How Might We)
5. Opportunity Scoring & Prioritization
6. The Research → Decision Bridge
7. Handling Contradictory Data
8. Synthesis at Scale (10+ sessions)

---

## 1. The Four-Phase Synthesis Model

Synthesis is not a single step — it's four phases that must run in sequence.
Collapsing them produces the most common research failure: premature insight.

```
Phase 1: OBSERVATIONS    Raw data → Concrete facts
         ↓
Phase 2: PATTERNS        Concrete → Grouped meaning
         ↓
Phase 3: INSIGHTS        Grouped meaning → Non-obvious truth + why
         ↓
Phase 4: OPPORTUNITIES   Truth → Direction for design
```

**The cardinal rule:** Do not name a pattern until you have at least 3 observations
that support it. Do not write an insight until you have a pattern. Do not write an
opportunity until you have an insight.

---

## 2. Affinity Mapping

### Phase 1: Observations (Raw → Concrete)

Extract discrete, observable facts from session notes. One observation per note.
No interpretation at this stage — only what was said or done.

**Observation format:**
```
[Participant ID] | [Behavior or verbatim quote]
```

**Examples of good observations:**
- `P2 | Screenshots the dashboard and pastes into Slack because she can't share a filtered view`
- `P4 | Said "I just assumed that was broken" about the export button — had never tried it`
- `P1 | Opened a new browser tab and Googled the answer rather than using the in-app help`

**Examples of bad observations (too interpreted):**
- `P2 | Was confused by the sharing feature` ← interpretation, not observation
- `P4 | Doesn't trust the product` ← leap; show the behavior that suggests this

**What to extract from sessions:**
- Direct quotes (mark these with quotation marks)
- Behaviors observed (what they did, not what you think it means)
- Emotional moments: frustration, delight, confusion, resignation
- Workarounds: how they compensated for what the product couldn't do
- Comparisons: other tools they mentioned
- Moments of surprise: what they expected vs. what they got

---

### Phase 2: Patterns (Concrete → Grouped)

Cluster observations that share an underlying structure. This is the hardest step
because the temptation is to cluster by topic rather than by what the behavior reveals.

**Bad cluster names (by topic):**
- "Sharing problems"
- "Help feature"
- "Navigation issues"

**Good cluster names (by what behavior reveals):**
- "Users route around the product when collaboration is needed"
- "Users exhaust external resources before trying in-product help"
- "Users build their own mental map through trial and error"

**Clustering rules:**
- Name the cluster *after* you've grouped the observations, not before
- Aim for 4–8 patterns from 5–8 sessions
- More than 8 patterns usually means you haven't synthesized enough yet
- A cluster with only 1 observation is a signal, not a pattern — label it separately
- Some observations belong in more than one cluster — that's fine; note it

**Cluster validation check:**
For each cluster, ask: "If someone only read the cluster name and none of the
observations, would they understand the user behavior?" If no, rename the cluster.

---

### Phase 3: Insights (Patterns → Meaning)

An insight is a non-obvious truth about user behavior that has a "so what."
It explains *why* the pattern exists, not just that it exists.

**Insight format:**
```
[Users] [do/believe/feel X] because [underlying reason grounded in a behavioral framework].
This means [implication for the product or strategy].
```

**Good insight example:**
"Users build workarounds in tools they already trust rather than adopting new
collaboration features, because the cost of switching context exceeds the benefit of
a better tool (status quo bias + habit loop). This means the path to adoption runs
through integration with existing tools, not feature parity."

**Bad insight example:**
"Users have trouble with the sharing feature." ← This is a pattern, not an insight.
It doesn't explain why, and it has no behavioral grounding or implication.

**Insight quality checklist:**
- [ ] Is it non-obvious? (If anyone on the team could have said this without research, it's too thin)
- [ ] Is it grounded in a behavioral framework from `behavioral-frameworks.md`?
- [ ] Does it explain *why*, not just *what*?
- [ ] Does it have a clear implication for design or strategy?
- [ ] Is it specific enough to be actionable?

**Behavioral framework mapping:**
For every insight, explicitly name the framework. See the quick mapping table in
SKILL.md Step 3, or read `behavioral-frameworks.md` for the full library.

---

## 3. Insight Laddering

Laddering is a technique for moving from a surface observation to the underlying
need and value. It's especially useful when observations feel thin or generic.

### The Laddering Process

**Step 1: Start with the behavior**
"What does the user do?"
Example: "User exports data to Excel to share with their manager"

**Step 2: Ask "Why?" (functional)**
"Why do they do this? What functional job does it serve?"
Example: "Because the product doesn't have a shareable view their manager can see
without a login"

**Step 3: Ask "Why?" again (emotional)**
"Why does that matter? What's the emotional job?"
Example: "Because they need to demonstrate progress and stay trusted by their manager"

**Step 4: Ask "Why?" once more (social/identity)**
"Why does that matter? What's the social or identity job?"
Example: "Because being seen as organized and in control is part of their professional identity"

**Step 5: Name the core need**
"The underlying need is: [X]"
Example: "The underlying need is: maintaining stakeholder confidence without requiring
them to adopt new tools"

**The ladder:**
```
Behavior:   Exports to Excel to share with manager
Functional: Can't create a shareable view within the product
Emotional:  Needs to demonstrate progress and stay trusted
Social:     Professional identity requires being seen as organized
Core need:  Maintain stakeholder confidence without requiring tool adoption
```

**When to use laddering:**
- When insights feel obvious or surface-level
- When you're not sure if you've found the real need
- When the team keeps jumping to feature solutions before understanding the why

---

## 4. Opportunity Framing (How Might We)

An opportunity is not a feature. It's a design direction that keeps multiple
solutions possible.

### How Might We Format

```
How might we [verb] [user] [goal] without [constraint]?
```

**Good HMW examples:**
- "How might we let a project lead share a live view of their work with a stakeholder
  without requiring the stakeholder to create an account?"
- "How might we help a first-time user feel confident they've set up correctly without
  requiring them to read documentation?"
- "How might we surface the most important task for a user without requiring them to
  decide what's important first?"

**Bad HMW examples:**
- "How might we add a sharing feature?" ← Too specific; already contains the solution
- "How might we improve the user experience?" ← Too vague; not actionable
- "How might we get users to use the help center?" ← Product-centric, not user-centric

### HMW Quality Criteria

| Criterion | Question to ask |
|---|---|
| User-centered | Does it describe what the user needs, not what the product should do? |
| Open | Does it allow for multiple very different solutions? |
| Specific enough | Is it narrow enough to be actionable? |
| Constraint-aware | Does it acknowledge the real tension or constraint? |
| Insight-connected | Can you trace it directly back to a research insight? |

**One insight = one or more HMW statements.** If an insight produces only one
possible HMW, the insight may still be too narrow.

---

## 5. Opportunity Scoring & Prioritization

When you have multiple opportunity areas and need to prioritize them, use one of
these two frameworks depending on what data you have.

### Framework A: Importance vs. Satisfaction Matrix (Ulwick)

**For each opportunity area, score:**
- **Importance:** How important is this job/outcome to users? (1–10)
- **Satisfaction:** How satisfied are users with current solutions? (1–10)

**Opportunity Score formula:**
`Importance + max(Importance − Satisfaction, 0)`

**Reading the scores:**
- High importance + low satisfaction = **Underserved** — highest priority
- High importance + high satisfaction = **Table stakes** — don't differentiate here
- Low importance = **Don't prioritize** regardless of satisfaction

**Build the matrix:**
```
                    LOW SATISFACTION        HIGH SATISFACTION
HIGH IMPORTANCE  |  UNDERSERVED (build)  |  TABLE STAKES (maintain)
LOW IMPORTANCE   |  IGNORE               |  OVERSERVED (simplify or cut)
```

### Framework B: Research Confidence × Business Relevance

When you have limited data and need to be transparent about uncertainty:

| Opportunity | Research Confidence | Business Relevance | Priority |
|---|---|---|---|
| [Opportunity A] | High (3+ sessions, triangulated) | High | Act now |
| [Opportunity B] | Medium (2 sessions, one source) | High | Validate before building |
| [Opportunity C] | High (3+ sessions) | Low | Monitor |
| [Opportunity D] | Low (1 session, stated not observed) | High | Run more research |

---

## 6. The Research → Decision Bridge

The most common failure in research delivery is the gap between "here's what we
found" and "here's what we should do." This is where research gets shelved.

### The Bridge Structure

Every research output should travel this path:

```
WHAT WE FOUND (insight + evidence)
    ↓
WHY IT MATTERS (behavioral framework + implication)
    ↓
WHAT IT MEANS FOR THE PRODUCT (opportunity statement)
    ↓
WHAT WE RECOMMEND (one specific, bounded next step)
    ↓
WHAT WE STILL DON'T KNOW (open questions + how to close them)
```

### Writing Recommendations Well

**A weak recommendation:**
"We should improve the sharing experience."

**A strong recommendation:**
"Prioritize removing the login requirement from shared views in Q2. Three of five
participants routed around the product specifically because their stakeholders wouldn't
create an account. This is a retention risk disguised as a feature gap — it's causing
churn at the collaboration stage, not the adoption stage."

**Recommendation format:**
```
RECOMMEND: [Specific action, bounded in scope]
BECAUSE: [Insight it addresses — one sentence]
EVIDENCE: [User quote or behavioral data]
EXPECTED IMPACT: [What changes if this is addressed]
CONFIDENCE: [High / Medium / Low — and why]
```

### Framing Uncertainty Without Losing Credibility

Research always contains uncertainty. Pretending it doesn't undermines trust when
reality contradicts the report. Be explicit:

**Instead of:** "Users want X"
**Say:** "4 of 5 participants expressed this need; our confidence is high that it's
real, but we haven't yet validated whether it's the primary driver of churn"

**Instead of:** "This will increase conversion"
**Say:** "Based on the insight, we'd expect addressing this to reduce friction at
the collaboration handoff — worth testing with a quick experiment before full build"

---

## 7. Handling Contradictory Data

Contradictory data is not a research failure — it's a signal worth investigating.
The three most common sources:

### Type 1: Stated vs. Observed Contradiction
User says "I always check the dashboard first thing" but you observed them open
email first and navigate from a notification.

**Resolution:** Observed behavior wins. The stated behavior is social desirability
or projection bias at work. Note both, explain the gap using the behavioral framework.

### Type 2: Between-Participant Contradiction
P1 says "I want more automation"; P3 says "I don't trust automation."

**Resolution:** Don't average. Segment. These are likely different user types or
contexts. The contradiction is the finding — map it to its segment.

```
SEGMENT A (high trust, time-constrained): Wants more automation
SEGMENT B (high stakes, accountability-driven): Wants transparency and control
```

### Type 3: Same Participant Contradiction
P2 says "I find this easy" but took 4 minutes and 3 wrong paths on the task.

**Resolution:** Dual process theory. Their System 2 self-assessment doesn't match
their System 1 experience. Use the behavioral data (4 minutes, 3 wrong paths) as
primary evidence. The self-assessment tells you they've normalized the friction —
which is often more alarming than the friction itself.

---

## 8. Synthesis at Scale (10+ Sessions)

When you have a large dataset (10+ participants, multiple methods), the standard
affinity mapping process becomes unwieldy. Use this adapted approach.

### Step 1: Pre-cluster by session
Before synthesizing across sessions, extract the 3–5 most important observations
from each session individually. This forces you to do per-session synthesis first
and prevents any single session from dominating the affinity map.

### Step 2: Saturation tracking
Track when themes stop adding new information:

```
THEME: "Users build workarounds for sharing"
Session 1: First mention ✓
Session 3: Second mention ✓
Session 5: Third mention ✓ [Pattern confirmed]
Session 7: New angle — they're using Loom, not just screenshots [Still adding]
Session 9: Same Loom pattern [No new information — saturation approaching]
Session 11: Confirmation only [Saturated]
```

When a theme is saturated, stop adding to it. Spend remaining sessions looking for
new themes or deep-diving unsaturated ones.

### Step 3: Hierarchy management
Large datasets produce many patterns. Organize into a two-level hierarchy:

```
THEME (top level): "Users struggle to maintain stakeholder visibility"
  Sub-pattern 1: "Users route around the product for sharing (workarounds)"
  Sub-pattern 2: "Users lose context when switching between async and sync comms"
  Sub-pattern 3: "Users can't tell what stakeholders have actually seen"
```

Insights and opportunities live at the theme level, not the sub-pattern level.

### Step 4: Multi-method triangulation table

| Finding | Interview data | Usability data | Analytics data | Reviews/secondary | Confidence |
|---|---|---|---|---|---|
| [Finding A] | 6/8 participants | 4/5 sessions | Drop-off +40% at step | Multiple G2 mentions | Very High |
| [Finding B] | 3/8 participants | — | — | — | Low — investigate further |
