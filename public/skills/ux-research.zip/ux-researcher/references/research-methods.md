# Research Methods Reference

Deep methodology guides for all research types. Read when designing a study —
selecting methods, structuring guides, recruiting participants, or running sessions.

---

## Table of Contents

1. Generative Methods
   - User Interviews
   - Contextual Inquiry
   - Diary Studies
   - Card Sorting & Tree Testing
   - JTBD Switch Interviews
2. Evaluative Methods
   - Moderated Usability Testing
   - Unmoderated Usability Testing
   - Heuristic Evaluation
   - First-Click Testing
3. Competitive Research
   - Three-Layer Teardown
   - Review Mining Protocol
   - Feature Map vs. Job Map
4. Quantitative Methods
   - Survey Design
   - Analytics Interpretation
   - NPS / CSAT / CES Reading
5. Mixed Methods
6. Participant Screener Templates

---

## 1. Generative Methods

### User Interviews

**When to use:** You don't yet know what the problem is. You're mapping behavior,
mental models, workarounds, emotional context. Not validating a hypothesis.

**Session structure (60 minutes)**
```
0:00–0:05  Framing & rapport
           — "We're not testing you, we're learning from you"
           — Confirm recording consent
           — "There are no wrong answers — the most useful thing is to think out loud"

0:05–0:15  Context warm-up
           — "Tell me about your role and what a typical week looks like"
           — "What's the most frustrating part of [domain] in your work?"
           — Goal: activate relevant memory, build comfort

0:15–0:35  Behavioral exploration (core)
           — "Walk me through the last time you had to [core task]"
           — Follow: "And then what happened?" / "Why did you do it that way?"
           — "What were you thinking at that point?"
           — "What did you try before that?"
           — Do NOT introduce your product or concept here

0:35–0:50  Pain & workaround deep-dive
           — "Where does this process break down for you?"
           — "What do you do when [known friction point] happens?"
           — "Show me" — ask them to share screen and walk through it live
           — "How much time does this cost you in a typical week?"
           — "What's the cost when this goes wrong?"

0:50–0:58  Mental model probe
           — "If you were designing an ideal version, what would it look like?"
           — "How would you explain [concept] to a new colleague?"
           — "What tool would you compare this to, even if it's a different category?"

0:58–1:00  Close
           — "Anything I haven't asked that you think is important?"
           — "Who else on your team deals with this differently? Could I talk to them?"
```

**Probing technique hierarchy (use in order)**
1. **Echo** — Repeat last few words as a question: "You said it felt 'risky'?"
2. **Expand** — "Tell me more about that"
3. **Example** — "Can you give me a specific example?"
4. **Incident** — "Walk me through the last time that happened"
5. **Clarify** — "When you say [X], what do you mean exactly?"

**Common facilitation failures**

| Failure | What it looks like | Fix |
|---|---|---|
| Leading | "Did you find that frustrating?" | "How did that feel?" |
| Filling silence | Jumping in before 3 seconds | Wait — silence = thinking |
| Wrong summary | "So you're saying you don't like X?" | "Let me make sure I understand..." |
| Opinion mining | "What do you think of this feature?" | "How have you handled this in the past?" |
| Pivoting too early | Moving on before topic is exhausted | "Before we move on — anything else about that?" |

**Note-taking protocol**
Two columns — never mix these:
- **Observation** (left): Exact quotes, behaviors, hesitation timestamps
- **Interpretation** (right): Your hypothesis — clearly labeled as such

---

### Contextual Inquiry

**When to use:** Self-report is insufficient. You need to see behavior in its
natural environment, with real interruptions, workarounds, and context.

**Core principle:** You are an apprentice, not an evaluator. You're there to learn
how they do the work, not to judge whether they're doing it correctly.

**Session structure**
1. **Intro** (5 min) — explain you're there to watch and learn, not evaluate
2. **Observation** (30–45 min) — they do actual work, thinking aloud
3. **Inquiry** (15 min) — ask about observed moments: "I noticed you did X — what
   were you thinking there?" / "Why that tool instead of Y?"
4. **Retrospective** (10 min) — review artifacts: "Tell me about this spreadsheet"

**What to look for:**
- Workarounds: tools used outside the intended workflow
- Interruptions and how they're managed
- Physical artifacts: printouts, sticky notes, second screens
- Error recovery: what do they do when something breaks?
- Social coordination: who gets called, why, and how

---

### Diary Studies

**When to use:** You need longitudinal behavior data — things that happen over
days or weeks. Best for habit formation, infrequent events, or context variation.

**Design rules:**
- Duration: 1–2 weeks max before dropout degrades data
- Entry frequency: Daily is the ceiling; every 2–3 days is more sustainable
- Entry format: Short and structured — 3 specific prompts + one open field
- Incentive: Split — partial at enrollment, remainder at completion

**Entry prompt template:**
```
Today's entry (~3 minutes):
1. Did you [target behavior] today? [Yes / No / Tried but didn't finish]
2. If yes: What triggered it? What tool did you use?
3. What was the hardest part of [task domain] today?
4. Anything else worth capturing? [Optional]
```

Always run a 20-minute debrief interview after the diary period. The diary
gives you *what* — the interview gives you *why*.

---

### Card Sorting & Tree Testing

**Card Sorting — when to use:** Designing or evaluating information architecture.
Understanding how users naturally group and label concepts.

**Two types:**
- **Open sort:** Participants sort and name their own groups. Use for: discovering
  user mental models, early IA design
- **Closed sort:** Participants sort into pre-defined categories. Use for: validating
  whether your proposed IA matches expectations

**Card creation rules:**
- Each card = one concept, one label. No compound concepts.
- 30–40 cards maximum before fatigue degrades data
- Use language from user interviews, not internal product language

**Tree Testing — when to use:** You have a proposed IA and want to test
findability without visual design as a confound.

**Reading tree test results:**
- First click accuracy is the strongest signal
- High indirect success = findable but not intuitive
- High failure on a specific task = label or location mismatch

---

### JTBD Switch Interviews

**When to use:** Understanding what caused a user to change behavior — adopt a
new product, abandon an old one, or change how they do a job.

**The Four Forces framework (Bob Moesta):**

| Force | Direction | Example |
|---|---|---|
| Push (old situation) | Away from old | "The old tool was getting slower every week" |
| Pull (new situation) | Toward new | "I saw a colleague using it and it looked effortless" |
| Anxiety (new situation) | Away from new | "I was worried about migrating all my data" |
| Habit (old situation) | Toward old | "I'd been doing it this way for three years" |

Adoption happens when Push + Pull > Anxiety + Habit.

**Switch interview question sequence:**
1. "Tell me about the first time you thought about changing how you do [X]"
2. "What made you start looking for alternatives?"
3. "How did you discover [new solution]?"
4. "What almost stopped you from switching?"
5. "Walk me through your first week using it"

---

## 2. Evaluative Methods

### Moderated Usability Testing

**When to use:** You have an existing design (prototype or live) and need to
understand where and why users fail specific tasks.

**Task design rules:**
- Scenario-based, not feature-based: "Your manager asked you to give Alex editor
  access to the project" — not "Use the sharing feature"
- Define success criteria before running: completed = reached confirmation? Within
  3 minutes? Without help?
- Design for failure — if every participant succeeds every task, you've learned nothing
- 5–7 tasks per 60-minute session. More than this produces fatigue data.
- Pilot with one internal participant before real sessions.

**Observation protocol — note in real time:**
- Hesitation timestamps: "0:14:32 — paused 8 seconds before clicking"
- Verbatim quotes, not paraphrase
- Error recovery paths: what did they try before finding the right thing?
- Emotional expressions: frustration, surprise, delight (timestamp)
- What they don't notice: elements they pass over that you expected them to see

**Think-aloud protocol:**
- Instruct at start: "As you work, please say what you're thinking and looking for"
- If silent for 5+ seconds: "What are you thinking right now?"
- Never say "you're doing great" — this is feedback and corrupts behavior
- Never help, even if they're struggling — struggling IS the data

**Sample size:** 5 participants reveals ~85% of major usability issues (Nielsen).
Run in rounds of 5: fix, then test again. Don't run 15 at once.

---

### Unmoderated Usability Testing

**When to use:** Faster, cheaper data at moderate fidelity. Good for validating
a specific interaction or supplementing moderated sessions at scale.

**Tools:** UserTesting, Maze, Lyssna, Lookback (async mode)

**Key differences from moderated:**
- Instructions must be completely unambiguous — no facilitator to clarify
- Include a warm-up task to acclimate participants to think-aloud
- Add comprehension checks: "In your own words, what were you trying to do?"
- Build in exit questions: "What confused you most?"

**What unmoderated cannot tell you:** Why. You can ask, but answers are thin
without probing. Always pair with at least a few moderated sessions for the "why."

---

### Heuristic Evaluation

**When to use:** Fast, expert-based audit before user research (to generate
hypotheses) or after (to validate findings).

**Nielsen's 10 Heuristics:**

| # | Heuristic | What to look for |
|---|---|---|
| 1 | Visibility of system status | Always telling users what's happening — loading, saving, errors |
| 2 | Match with real world | Language matches user vocabulary (surfaced via interviews) |
| 3 | User control & freedom | Mistakes are recoverable; undo is available |
| 4 | Consistency & standards | Similar actions look and behave the same way |
| 5 | Error prevention | Design prevents errors before they happen |
| 6 | Recognition over recall | Users see options rather than remembering them |
| 7 | Flexibility & efficiency | Shortcuts exist for power users |
| 8 | Aesthetic & minimalist | Every element is earning its place |
| 9 | Error recovery | Error messages are specific, human, constructive |
| 10 | Help & documentation | Help is available at the moment of need |

**Severity scale:** 0 = not an issue / 1 = cosmetic / 2 = minor / 3 = major / 4 = catastrophe

**Process:** Two evaluators work independently, then combine and resolve. One
evaluator finds ~35% of issues; two find ~60%; three find ~75%.

---

### First-Click Testing

**When to use:** You have a specific IA or navigation decision and want behavioral
data on where users go first.

**Why first click matters:** If users click correctly first, they succeed 87% of
the time. If they click wrong first, success drops to 46%.

**Setup:** Show a static screenshot. Ask "Where would you click to [task]?"
Run with 20–50 participants — large n compensates for the single data point per participant.

**Reading results:**
- High concentration in correct area = strong IA signal
- Scattered clicks = label or placement problem
- Concentration in wrong area = follow up: "What did you expect to find there?"

---

## 3. Competitive Research

### Three-Layer Teardown

Do not spend equal time on each layer. Ratio: 10% / 40% / 50%.

**Layer 1 — Surface (10%): What exists?**
Feature inventory, navigation structure, pricing, positioning language.
This is commodity information. Do not build strategy from it.

**Layer 2 — Experience (40%): What jobs does it serve, and where does it break?**
- Sign up and complete the core workflow yourself
- Document where you hesitate, fail, or are delighted
- Map each feature to a user job: what is this actually helping accomplish?
- Identify where experience degrades: handoff moments, edge cases, half-built flows

**Layer 3 — Signal (50%): What does user behavior reveal?**
This is where real intelligence lives. See Review Mining Protocol below.

---

### Review Mining Protocol

**Source hierarchy (highest to lowest signal quality):**

1. **App store reviews** (iOS + Google Play)
   - 1–2 star: raw frustration, specific failures
   - 4 star: "good but..." reveals unmet needs alongside satisfaction
   - 5 star: what users value most — JTBD signal

2. **G2 / Capterra**
   - Filter by "what do you dislike?" — this is gold
   - Filter by company size to segment by your target market
   - "What problems are you solving?" = JTBD signal

3. **Reddit / community forums**
   - "[Product] alternative" = what's broken enough to make users leave
   - "[Product] vs [competitor]" = how users frame the decision
   - "[Product] help" = where users get stuck

4. **LinkedIn posts from power users**
   - Advanced use cases and workflow integrations
   - Complaints reveal ceiling effects: where expert users outgrow the product

5. **Changelog and release notes**
   - Bug fixes reveal what was broken before
   - Feature additions reveal what was missing before
   - Release frequency in an area = current strategic focus

**Review mining output format:**
For each signal, capture: Source + date / Verbatim quote / Job it reveals / Emotional
intensity / Frequency signal (how many others mention the same thing?)

---

### Feature Map vs. Job Map

**Feature Map** (what most competitive analyses produce):
Lists features. Checks boxes. Tells you nothing about user behavior or unmet needs.

**Job Map** (what this skill produces):

```
JOB: [What users are trying to accomplish]
  User segment: [who has this job most acutely]
  How they do it today: [incumbent behavior]

  COMPETITOR A
  — Serves this job? [yes / partially / no]
  — How: [specific mechanism]
  — Where it breaks: [user evidence]
  — User sentiment: [verbatim from reviews]

  GAP: [What no competitor is doing well]
  OPPORTUNITY: [Direction, not feature]
```

---

## 4. Quantitative Methods

### Survey Design

**When surveys work:**
- Validating frequency of a known problem
- Sizing a behavioral pattern at scale
- Establishing a baseline before and after an intervention
- Prioritizing between known pain points

**When surveys fail:**
- Discovering unknown problems (users can't tell you what they don't know to say)
- Understanding why (surveys capture what, not why)

**Question design rules:**
- 5-point Likert scales; label both endpoints
- Behavioral over opinion: "When did you last use X?" not "How often do you use X?"
- One question per question — no doubles
- Order: behavioral first, attitudinal middle, open-ended last
- Length: 5 min = good completion; 10 min = acceptable with incentive; 15+ = dropout

**Common survey failure modes:**

| Failure | Example | Fix |
|---|---|---|
| Double-barreled | "How easy and useful was this?" | Split into two questions |
| Leading | "How much did you enjoy the new feature?" | "How would you describe your experience?" |
| Loaded assumption | "When did you stop having trouble with X?" | First confirm they had trouble |
| Acquiescence bias | Agree/disagree scales skew toward agreement | Use behavioral questions instead |

---

### Analytics Interpretation

**What analytics can tell you:** What users do, where they stop, how often, who does it.

**What analytics cannot tell you:** Why. Whether users were satisfied. What they
tried but couldn't do. What they don't do because they don't know it exists.

**Reading funnel data:**
Drop-off at step N reveals a problem exists there. It does not tell you whether the
problem is comprehension, motivation, or friction — or whether a previous step set
up the wrong mental model. Always pair with an evaluative session at the specific step.

**Segment before concluding:**
Always segment by new vs. returning users, role/tier, device, and acquisition source
before drawing conclusions. An undifferentiated 50% completion rate that's actually
30% for new users and 85% for returning users is a completely different problem.

---

### NPS / CSAT / CES Reading

**NPS:** % Promoters (9–10) minus % Detractors (0–6). Moves slowly — don't
read month-to-month as signal. NPS without open-text follow-up is nearly worthless
for design decisions. The why is in the comments, not the number.

**Reading NPS comments:**
- Detractor comments: specific friction, unmet expectations, competitive comparisons
- Passive (7–8): "good but..." — clearest signal of unmet needs
- Promoter: confirms what's working — reinforce, don't dilute

**CSAT:** Ask immediately after a specific interaction. Contextual CSAT is more
actionable than periodic. Pair with "What could we have done better?"

**CES (Customer Effort Score):** "How easy was it to [accomplish this task]?"
Strongest predictor of churn — high effort = high churn risk. More actionable than
CSAT because effort is directly designable.

---

## 5. Mixed Methods

**The core rule:** Use qualitative to discover and explain. Use quantitative to
size and validate. Never reverse this.

**Sequential designs:**

*Qual → Quant:* Run interviews first, then survey to validate frequency.
Use when: in discovery, want to know if patterns are widespread.

*Quant → Qual:* Run analytics or surveys first to identify anomalies, then
interview to explain them. Use when: you have unexplained behavioral data.

**Triangulation principle:**

| Finding appears in | Confidence | Action |
|---|---|---|
| Analytics only | Low | Add qualitative |
| Interviews only | Medium | Add behavioral observation |
| Analytics + interviews | High | Act on it |
| Analytics + interviews + reviews | Very high | Prioritize it |

---

## 6. Participant Screener Templates

### General Qualitative Screener

```
STUDY: [Name]
Format: [Moderated remote / In-person / Unmoderated]
Duration: [XX minutes] | Incentive: [$XX] | Sessions: [Dates]

QUALIFYING CRITERIA (must meet ALL):
[ ] [Specific role criterion]
[ ] [Behavior criterion — they must do the target behavior regularly]
[ ] [Context criterion — environment, team size, tool usage]
[ ] Has used [tool/platform] for at least [X months]

AUTO-DISQUALIFIERS:
[ ] Works in UX research, product design, or market research
[ ] Works for a direct competitor: [list]
[ ] Has participated in a [company] research session in the last 6 months

SCREENING QUESTIONS:
1. Current job title? [Open text]
2. How long in this role? [<6mo / 6–12mo / 1–3yr / 3+yr]
3. Company size? [Ranges]
4. How often do you [core behavior]? [Daily / Weekly / Monthly / Rarely / Never]
   → Qualify: Daily or Weekly
5. [Scenario question confirming they've experienced the target situation]
   → Qualify: Yes
6. Available for [XX]-min video call during: [list times]
```

### JTBD Switch Interview Screener

```
QUALIFYING CRITERIA:
[ ] Has switched from [old tool/behavior] to [new] within the last 6 months
[ ] Made the switch decision themselves (not mandated by employer)
[ ] Used the old solution for at least 3 months before switching

SCREENING QUESTIONS:
1. Have you changed how you [core job] in the last 6 months? → Qualify: Yes
2. Did you choose to make this change, or was it required by your employer?
   → Qualify: I chose to make this change
3. What were you using before? [Open text]
4. What are you using now? [Open text]
5. Approximately when did you switch? [Month / Year]
```
