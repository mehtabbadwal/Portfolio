# Age-Specific Research

Research protocols across the full age spectrum. Read `inclusive-research-principles.md`
first — foundational framework applies to all non-default populations.

**Default age range (18–64):** The main skill is written for this range. Brief notes
on edge cases within it appear at the end of this file. All other age groups require
the specialist guidance below.

---

## Table of Contents

1. Early Childhood (2–5)
2. Children (6–12)
3. Teenagers (13–17)
4. Adults 18–64 — Edge Case Notes
5. Older Adults — Young Old (65–75)
6. Older Adults — Technology-Unfamiliar (75+)

---

## 1. Early Childhood (2–5)

This age group sits at the edge of what standard research methods can reach. The
primary research output is behavioral observation — not interview, not think-aloud,
not self-report. Children this age cannot reliably explain why they did something,
what they prefer, or what confused them. What they can do is show you, if you
create the right conditions.

### What You're Actually Researching

For products designed for this age group, you're almost always researching two things
simultaneously:
- The child's experience of the product
- The parent/caregiver's experience of setting up, managing, and observing the product

These are separate research subjects. Don't conflate them in a single session.

### Consent & Ethics

- Parental/guardian consent is required without exception. This must be written,
  explicit, and obtained well before the session.
- The child's assent — expressed as enthusiasm and willingness to engage — must be
  present at the start of the session and monitored throughout. If the child is
  reluctant, upset, or trying to leave: stop. No exceptions.
- Recording consent (video and audio) must be specific and separate from participation
  consent. Footage of children requires extra protection — store securely, limit access
  strictly, and retain only as long as necessary.
- IRB or equivalent ethics review is strongly recommended for any research with children.

### Session Design

**Duration:** 15–20 minutes maximum. Attention and willingness to engage deteriorates
quickly. It is better to run two 15-minute sessions than one 30-minute session.

**Location:** The child's natural environment (home) is almost always better than a
lab or office. Familiarity reduces anxiety and produces more natural behavior. Remote
observation (parent-conducted with researcher observing via video call) is a viable
format that removes travel burden and keeps the child in their own space.

**Format:** Free play or guided play with the product. Never sit a young child at a
desk and give them formal tasks. Structure the session around the activities and
behaviors you want to observe — not around research questions you want answered.

**Parent role:** Define this clearly before the session and hold to it. Parents often
intervene ("no, like this — show the lady how you use it") which contaminates the
observation. Brief parents in advance: "Your job today is to be available for comfort
but to let [child] explore on their own as much as possible."

**Observer role:** Stay warm, low-key, and slightly in the background. Direct engagement
should be minimal and playful — not clinical.

### What to Observe

- Touch behavior: how do they approach the interface? Swipe, tap, press, drag?
  Where does the motor behavior break down?
- Attention span per feature: how long before they move on? What pulls them back?
- Frustration signals: pushing the device away, looking to the parent, going quiet,
  starting to fuss.
- Delight signals: leaning in, repeating an action, vocalizing, showing the parent.
- What they ignore entirely — often as informative as what they engage with.

### Methods That Work

- Observation (primary method)
- Parent-reported diary: "What did [child] do with the product this week?" with
  simple structured prompts
- Video review: parent records usage at home and shares clips

### Methods That Don't Work

- Interview (children this age cannot reliably self-report)
- Think-aloud
- Preference tasks ("which one do you like better?") — too abstract
- Any session format that requires sustained attention for more than 15–20 minutes

---

## 2. Children (6–12)

This age group has a much wider range of capability than the label suggests.
A 6-year-old and a 12-year-old are different research subjects. Calibrate method
and facilitation to the specific age band you're working with, not the group as a whole.

### Consent & Ethics

- Parental/guardian written consent required.
- Child assent required — explain the session in language appropriate to their age:
  "We're going to see how kids use this app. You can't do anything wrong — we just
  want to watch you try it. And if you want to stop, just say so."
- For 10–12 year olds, a simplified written assent form can work alongside parent consent.
- Never put a child in a position where they feel they must perform or succeed.
  Normalizing not knowing and making errors is essential.

### Session Design

**Duration:**
- 6–8 year olds: 20–30 minutes maximum
- 9–12 year olds: 30–45 minutes

**Format:** Scenario-based tasks work reasonably well for 8+ if scenarios are
concretely framed. Avoid abstract scenarios. Use characters and stories: "Imagine
you're helping your friend find their favourite game. Let's try to find it together."

**Parent presence:** For younger children in this range (6–8), a parent in the room
provides comfort. For older children (10–12), parent presence can inhibit behavior —
children may perform for the parent rather than behave naturally. Offer options and
let the child decide.

**Think-aloud:** Retrospective think-aloud works better than concurrent for most
of this age range. After each task: "Tell me what you were thinking while you were
doing that." Simple, direct, specific.

**Facilitation tone:** Warm and collaborative. Match their register. Don't be
overly clinical or formal — it increases performance anxiety. Position yourself
as a learner: "You know this better than I do — show me how it works."

### What to Observe

- Comprehension of UI language: do children understand the words used in labels,
  instructions, and feedback? Many interfaces are written for adult reading levels.
- Icon comprehension: universal for adults often means nothing to children. Test
  every icon.
- Error recovery: can they get back on track without help? How?
- Self-efficacy responses: do they try again, ask for help, or give up?
- Social performance: are they doing what they actually do, or what they think you
  want to see? Watch for looks to the facilitator for approval.

### Behavioral Frameworks

- **Cognitive load:** children have smaller working memory capacity than adults.
  Multi-step flows that adults handle comfortably may be beyond the working memory
  budget of an 8-year-old.
- **Concrete operational thinking (Piaget):** children 7–11 reason from concrete
  experience, not abstract principle. UI that requires inferring meaning from abstract
  cues will fail more consistently in this age group.
- **Self-efficacy (Bandura):** failure experiences accumulate quickly. One failed
  task can shut down engagement for the rest of the session.

---

## 3. Teenagers (13–17)

Teenagers are often treated as either large children or small adults in research.
Neither is accurate. They have full adult cognitive capacity in many domains but
are in a distinct social and developmental context that shapes how they behave in
research settings in ways that require specific facilitation design.

### Consent & Ethics

- Parental/guardian consent required (varies by jurisdiction — verify local rules).
- Participant assent required — and for this age group, assent is meaningful and
  must be genuine. Teenagers who don't want to be there produce useless data.
- Some teenagers may be reluctant to participate if they don't understand or trust
  the research purpose. Explain it directly, honestly, and without condescension.
- Be aware of mandatory reporting obligations if research surfaces disclosures of
  harm. Know your responsibilities before the session starts.

### The Core Facilitation Challenge

Teenagers are acutely aware of being observed and judged. This produces two
competing dynamics in sessions:
- **Performance behavior:** doing what they think the researcher wants to see
- **Impression management:** avoiding looking stupid, naïve, or uncool

Both contaminate data. The solution is not a technique — it's a facilitation
relationship. The faster you establish that you genuinely don't care how they
perform and that you're interested in them specifically, the faster the performance
drops and the real behavior emerges.

**What works:**
- Peer-level language (without forced slang — that's worse)
- Genuine curiosity about their actual behavior, not the "correct" behavior
- Not reacting with surprise or judgment to anything they do or say
- Positioning them as the expert: "You use this way more than most people I talk to"

**What makes it worse:**
- Formal lab settings
- Parental presence (usually)
- Asking about things they should know how to do ("why couldn't you find that?")
- Adult authority framing ("I need you to...")

### Session Design

**Format:** Diary studies are particularly valuable for this age group because they
capture authentic behavior in natural contexts without the observation effect of
a session. Screenshot diaries, TikTok-style video logs, or WhatsApp/text message
check-ins work better than structured written entries.

**Think-aloud:** Works reasonably well if the facilitation relationship is strong.
Falls apart if the participant is self-conscious about narrating their behavior in
front of a researcher.

**Group sessions (peer pairs):** Pairs of friends can produce more natural behavior
than individual sessions because the social dynamic shifts from "performing for a
researcher" to "doing this with a friend." Use with care — peer influence also
suppresses individual behavior that might differ from the group norm.

**Duration:** 45–60 minutes depending on engagement. Teenagers who are genuinely
interested will run over time willingly. Teenagers who aren't will be disengaged
by 20 minutes.

### What to Watch For

- The gap between stated behavior and actual behavior is wide in this group.
  Stated: "I never do that." Observed: they do it constantly.
- Platform switching is seamless and fast — they move between apps and contexts
  in ways that adult users don't. Note the switching patterns.
- Social features get disproportionate attention — sharing, reacting, showing
  others. These moments often reveal the primary use case more than solo tasks do.
- Security and privacy: teenagers are often more privacy-aware than they appear
  and more concerned about data than adult users in many categories. But their
  behavior doesn't match their stated concern (intention-action gap). Research both.

---

## 4. Adults 18–64 — Edge Case Notes

The main skill is written for this range. No specialist protocol is needed. Two
sub-segments are worth flagging:

### 18–25 (Young Adults)

**Social desirability bias runs high.** Young adults in research sessions often
want to appear competent, technologically literate, and quick. This produces
faster task behavior than is natural, reluctance to admit confusion, and a
tendency to provide socially desirable opinions rather than honest responses.

Mitigation: establish explicitly that confusion is the most useful thing you can
observe. "The harder things are to figure out, the more we learn. There's nothing
to perform here."

**Peer influence and social context matter.** Many young adult behaviors are
inherently social — shaped by what their peer group does, what is considered
cool or embarrassing, what they would do if observed by friends vs. alone.
Ask about context when relevant: "Do you use this alone or with other people around?"

### 45–64 (Pre-Older Adult Transition Zone)

**Tech fluency varies significantly.** Some participants in this range are fully
comfortable with contemporary UI patterns. Others are closer to the 65+ profile
in terms of unfamiliarity with gesture-based interaction, expectation of desktop
affordances on mobile, and preference for explicit labels over icons.

Mitigation: include a brief tech comfort screen in recruitment. Two or three
questions about how they use their phone, how often they download new apps, and
whether they use online banking gives you a reliable proxy for tech fluency.
Adapt your session format based on the answer — don't assume.

---

## 5. Older Adults — Young Old (65–75)

This group is dramatically underresearched relative to their market presence and
purchasing power. Most "older adult" research is actually conducted with people
in their 50s. The assumptions below apply to genuinely older participants —
people who came of age before personal computing was ubiquitous.

### What Changes With Age (Relevant to Research Design)

These are statistical tendencies, not individual profiles. Confirm with the
specific participant through observation, not assumption.

**Processing speed:** Cognitive processing is slower on average. Tasks take longer.
This is not confusion — it is pace. Do not prompt or help.

**Working memory:** Shorter working memory span affects multi-step tasks.
Instructions given at the start of a session may not be retained through a
30-minute task. Provide written reference cards for complex tasks.

**Vision:** Reduced contrast sensitivity, smaller comfortable font size range,
and sensitivity to glare are common. Test at the participant's actual settings,
not default settings.

**Fine motor control:** Precision of touch and mouse interaction decreases with age.
Small tap targets, hover states, and drag interactions are higher-effort.

**Hearing:** If conducting sessions with audio components, confirm comfortable
hearing range. Closed captions for any video content in the product.

### Session Design

**Duration:** 45–60 minutes is usually achievable. Build in one scheduled break.

**Pacing:** Slower than standard. Do not interpret slow pace as confusion.
Do not rush. The quality of observation is directly proportional to the patience
of the facilitator.

**Think-aloud:** Works well — older adults are often comfortable narrating their
experience once the research context is clear. Less performance anxiety than
younger groups.

**Remote vs. in-person:** In-person is often more comfortable for participants
unfamiliar with video call technology. If remote, budget time at the start to
troubleshoot technology setup — and design the tech setup instructions for
maximum simplicity.

**Instructions:** Written and verbal. Don't rely on verbal-only instructions for
complex tasks. A simple printed or on-screen reference card with the task summary
is more reliable than restating instructions mid-task.

### Facilitation

- Do not speak slowly or loudly unless asked. Don't condescend.
- Do not over-explain how technology works as preamble — focus on the task.
- Do not fill silences. Older adults often process before responding. Wait.
- If they ask for help: resist. "What would you try next?" is better than helping.
  They will often find their own path — and that path is the data.

### What to Watch For

- **Mental model anchoring:** older adults often have strong expectations based
  on prior tool experience (desktop software, physical equivalents). When the
  product violates those expectations, the violation is precise and articulable.
  These are high-quality mental model signals.
- **Trust thresholds:** older adults often have explicit and considered criteria
  for trusting a product with their data. Surface these — they often reflect the
  threshold that younger users have implicitly and never verbalize.
- **Workarounds:** older adults are often creative and persistent problem-solvers.
  Their workarounds reveal functional gaps with high precision.

---

## 6. Older Adults — Technology-Unfamiliar (75+)

This sub-group requires the most significant research design adjustment of any
population in this file. The gap is not cognitive decline (which varies enormously
individually) — it is a fundamental difference in technological frame of reference.
Many participants in this group did not use computers during their working lives
and have learned digital products late in life, often under reluctant circumstances.

### The Frame of Reference Problem

Standard UX assumes a user who has internalized the conventions of digital
interfaces through years of use: that icons represent actions, that a hamburger
menu contains navigation, that you can swipe to go back, that tapping the logo
goes home. These conventions don't exist in this participant's frame of reference.

This is not a barrier to research — it is one of the most valuable research
perspectives available. Participants without internalized conventions reveal
the assumptions your interface makes that you never knew it was making.

### Recruitment

Recruiting this population through standard digital channels (online panels,
email invitations) systematically misses the least digitally connected participants.
Recruit through:
- Senior centers and day programs
- GP surgeries and healthcare waiting rooms
- Libraries
- Religious organizations
- Age-focused charities and community organizations
- Word of mouth through family networks (with care — family recruitment introduces
  bias toward participants who are "showcased" as doing well with technology)

### Consent

Plain language. No jargon. Verbal consent supplemented by written, with a relative
or support person available if desired. Do not rush the consent process.

### Session Design

**Duration:** 30 minutes maximum. Error recovery, reading, and processing all take
longer — task count should be very low (2–3 tasks).

**Environment:** In the participant's home or a familiar community space. A lab or
clinical environment increases anxiety and produces unrepresentative behavior.

**Technology setup:** Arrive with all tech pre-configured. Do not troubleshoot in
front of the participant — it sets an anxiety-producing tone before research begins.
Confirm text size, contrast, and volume settings match the participant's preferences.

**Task design:** Only tasks with direct, immediate relevance to the participant's
actual life. Abstract tasks ("imagine you need to book a flight") may not map to
lived experience. Concrete tasks ("let's try to find [a specific thing they
mentioned using]") produce better engagement and more useful data.

### Facilitation

- Ground everything in analogy to familiar physical experiences: "This is like a
  filing cabinet for your photos." Familiar anchors build the bridge between
  physical and digital mental models.
- Narrate what's happening clearly when the participant is observing: "The screen
  is loading — it just needs a moment."
- Never express frustration, impatience, or surprise at any behavior.
- If the participant says "I'm not good at this" — and they will — acknowledge it
  directly without dismissing it: "You're doing exactly what we need. We're learning
  from what's hard, not what's easy."

### What You'll Find

This group reveals the deepest assumptions your interface makes. When a participant
asks "where did it go?" after completing a step, or taps something multiple times
because no feedback appeared, or closes the entire browser when they meant to go back —
each of these is a precise design finding about invisible conventions your interface
relies on without earning.

These findings are not edge cases. They are the most honest signal you will ever
get about the legibility of your product.
