# Neurodivergent & Disability Research

Specialist research protocols for participants with neurodivergent profiles,
cognitive/intellectual disabilities, sensory/motor impairments, and mental health
conditions. Read `inclusive-research-principles.md` first — the foundational
framework applies to every population in this file.

---

## Table of Contents

1. Autism Spectrum (ASD)
2. ADHD
3. Dyslexia & Reading Disabilities
4. Cognitive & Intellectual Disabilities
5. Blind & Low Vision
6. Deaf & Hard of Hearing
7. Motor Impairments
8. Mental Health Conditions

---

## 1. Autism Spectrum (ASD)

Autism is a spectrum — communication style, sensory sensitivity, social processing,
and cognitive strengths vary enormously across participants. The most important thing
to know before a session: there is no "typical" autistic participant. Treat what
follows as a checklist of considerations, not a profile to project onto individuals.

### Recruitment & Screening

Screen for the behavior and context you're studying, not for autism as a qualifier.
Many autistic participants do not self-identify in screeners unless directly asked —
and many prefer not to disclose. If accommodation needs are the reason for asking,
frame it that way: "Is there anything about how we run sessions that would help you
participate comfortably?"

For products designed specifically for autistic users, recruit through autism advocacy
organizations, adult autistic community spaces (not parent groups — autistic adults
can speak for themselves), and online communities where autistic users self-organize.

### Consent & Pre-Session

- Send the session agenda, questions (or sample questions), and all instructions
  in writing before the session. Knowing what to expect reduces anxiety significantly.
- Use plain, literal language. Avoid idiom, sarcasm, or indirect phrasing.
- Give explicit permission to say "I don't know," "I need a break," or "I want to stop"
  — and confirm they understand these are real options with no consequences.
- If the participant uses AAC or prefers written communication during the session,
  confirm this in advance and accommodate it fully.

### Session Design

**Think-aloud:** Do not default to concurrent think-aloud. For many autistic participants,
narrating behavior while performing a task is genuinely cognitively conflicting — not
a warm-up issue that resolves with prompting. Use retrospective think-aloud instead:
let them complete the task, then ask what they were thinking. Or use a task journal:
they write notes during/after each task rather than speaking continuously.

**Session length:** 45 minutes max for most participants. Sensory and social processing
load accumulates — performance in the second half of a 60-minute session may not
reflect actual capability.

**Breaks:** Offer explicitly and at regular intervals. "We've been at this for 20 minutes —
would you like a short break before we continue?" Don't wait for visible distress.

**Environment (remote):** Remote sessions reduce sensory load for many autistic
participants significantly. Allow participants to keep their camera off if they prefer.
Screen-sharing may be more comfortable than face-to-face video. Confirm in advance
whether they want to see your face or just hear your voice.

**Environment (in-person):** Minimize background noise, unexpected sounds, and strong
smells. Florescent lighting is a common sensory stressor. Natural light or warm
artificial light is preferable. Give a full tour of the space before starting.

### Facilitation

- Do not interpret silence as confusion or disengagement. Wait. Autistic participants
  often process more deeply before responding — interrupting the silence degrades data.
- Take direct answers at face value. If an autistic participant says "this is fine,"
  probe before assuming it means something different: "Can you tell me more about what
  makes it feel fine?" Don't assume subtext.
- Avoid leading probes: "Was that frustrating?" invites agreement bias. Use open probes:
  "What was that like for you?"
- If the participant fixates on a detail that seems off-topic, follow it — it often
  reveals the most precise and accurate behavioral data in the session.
- Avoid changing topics abruptly without a clear verbal transition: "I'm going to move
  us to a different part of the session now. Is that okay?"

### Behavioral Signals to Watch For

- Masking: appearing to understand or manage fine while experiencing significant
  internal effort. Assess performance, not affect.
- Literal interpretation: "click anywhere to continue" taken literally as permission
  to click outside the intended area. This is a design finding, not a user error.
- Hyperfocus on specific elements: may reveal the most salient features of the design,
  not distraction.
- Unexpected emotional responses to small things: often peak-end rule at work, or a
  sensory/cognitive stressor that isn't visible from the outside.

### Insight Framing

Never frame autistic behavior as a deviation from correct usage. "The participant
repeatedly returned to the settings page before completing the task because the
interface provided no persistent confirmation of their selected state" is a finding.
"The autistic participant exhibited perseveration" is not.

---

## 2. ADHD

ADHD involves differences in sustained attention, working memory, impulse control,
and executive function — but also often involves hyperfocus, high associative thinking,
and strong pattern recognition. Research sessions that work with these dynamics produce
far better data than sessions designed around the assumption of deficit.

### Session Design

**Length:** 30–45 minutes is the practical ceiling. A 60-minute session will produce
valid data for the first 30 and degraded data after. If the research requires more
time, split into two shorter sessions.

**Structure:** More structure is better. Open-ended, unanchored sessions ("just explore
freely") generate drift. Give clear task boundaries: "For this task, I'd like you to
try to [specific goal]. You'll have about 5 minutes." Clear start and end points help
executive function.

**Transition warnings:** "We're about to move to a new task" gives working memory time
to close out the current cognitive thread. Abrupt transitions produce more errors and
less reliable verbal data.

**Think-aloud:** Works well for many ADHD participants because externalizing thought
is a natural cognitive strategy. Be prepared for rich, associative verbal data —
follow threads rather than redirecting to the guide. The tangents are often the data.

**Remote sessions:** Higher distraction risk. Ask about their environment before starting.
"Is this a good space for a focused 30-minute session, or would a different location
work better?" Don't assume home = comfortable.

### Facilitation

- Match energy. Flat, slow facilitation creates drift. Active, engaged facilitation
  helps sustain attention.
- Use the participant's own words and references to re-anchor when drift occurs.
  Not: "Let's get back on track." Rather: "You mentioned earlier that [X] — I want
  to make sure we explore that fully. Tell me more."
- If a participant completes a task very quickly and moves on, don't assume they're
  done. Ask: "Before we move on — was there anything you noticed while doing that?"
- Don't penalize time. ADHD participants often perform differently on timed tasks
  than they do under naturalistic conditions. If timing tasks for research purposes,
  run untimed first, timed second, and report both.

### What You'll Often Find

- High sensitivity to friction — small UX problems that neurotypical users tolerate
  are often immediate session-enders for ADHD users. This is a signal, not noise.
- Strong intuitive responses to visual hierarchy and information density. Trust these.
- Workarounds that reveal elegant shortcuts the design didn't intend. Document them.
- Inconsistent performance across identical tasks — this is not user error, it is
  an attention and working memory dynamic. Do not average it out; it's part of the finding.

---

## 3. Dyslexia & Reading Disabilities

Dyslexia affects reading fluency, decoding, and spelling — not intelligence or
reasoning ability. Many dyslexic users are highly skilled at compensating in ways
that mask the reading difficulty from standard usability testing. This means standard
sessions systematically underreport reading-related friction.

### What Standard Testing Misses

Most usability tasks are delivered in writing. Participants read the scenario, read
the UI, read error messages, and read the task again when they get stuck. A dyslexic
participant doing all of this in a session is under significantly more cognitive load
than the session appears to measure. Their performance is valid data — but it's data
about the reading burden of the interface as much as the task flow.

### Session Design

- Deliver all task scenarios verbally, not just in writing. Read them aloud. Let
  participants listen rather than read.
- If the product itself is text-heavy, acknowledge this explicitly: "This part has
  a lot of text — take whatever time you need."
- Allow extra time for all tasks. Don't time-cap tasks tightly.
- Offer the session guide in advance so participants can pre-read at their own pace.

### What to Observe

- How participants interact with text-heavy UI — do they skip it, approximate it,
  or avoid it entirely?
- Error message handling — are they reading and acting on error text, or ignoring it?
- Navigation patterns — do they rely on visual cues and icons over text labels?
- Search vs. browse — search shifts the reading burden; preference for search over
  navigation may indicate a text-processing load, not a nav failure.

### Insight Framing

Text-related friction that disproportionately affects dyslexic users usually
reveals problems that affect all users under cognitive load, time pressure, or
in low-literacy contexts. Report these as universal risk signals.

---

## 4. Cognitive & Intellectual Disabilities

This is a broad category covering a wide range of cognitive profiles — including
Down syndrome, acquired brain injury, intellectual disability, and others. The most
important principle: every person in this group is an individual. Do not import
assumptions from a diagnostic category.

### Consent & Ethics (Heightened Importance)

This population requires the most rigorous consent process of any group in this file.

- Legal guardianship does not automatically mean the person cannot provide meaningful
  assent. Always attempt to get direct assent from the participant.
- Use Easy Read or Plain English consent materials — short sentences, simple vocabulary,
  real photographs instead of abstract icons, and clear "yes / no" language.
- Watch for acquiescence bias: people in this group have often been trained — explicitly
  or implicitly — to agree with authority figures. A "yes" in consent may reflect
  compliance, not genuine agreement. Build in multiple, separated consent checks.
- If a participant shows any sign of withdrawal, distress, or reluctance — stop.
  Gatekeeper consent does not override participant distress.

### Session Design

- Sessions should be short: 20–30 minutes maximum.
- Use one task at a time. Do not explain multiple steps in advance.
- Use concrete, literal language. Avoid abstractions.
- Include familiar warm-up activities before research tasks to build comfort and rapport.
- A trusted support person may attend if the participant requests — agree in advance
  on the support person's role (observer only, or active support) and hold to it.

### Methods That Work

- Observation over interview. Watching participants use a product is more reliable
  than asking them to describe their experience.
- Closed-question probes: "Did that feel easy or hard?" after a task — not open-ended
  probes that require sustained verbal construction.
- Photo and object-based methods: showing images or objects as stimuli can work better
  than purely verbal or screen-based tasks.
- Sorting tasks with physical cards rather than digital interfaces reduce the technical
  barrier and let cognitive participation be the focus.

### What to Watch For

- Emotional responses to design are often more visible and immediate than with other
  populations — these are high-quality data.
- Repetitive behavior patterns may reveal which elements of the design have become
  anchors (positive) or obstacles (negative).
- Social desirability bias is high. Never accept a positive response at face value —
  triangulate with observed behavior.

---

## 5. Blind & Low Vision

This group splits into two meaningfully different research subjects:
- **Totally blind:** primarily uses screen readers, braille displays, keyboard navigation
- **Low vision:** may use screen magnification, high contrast, or standard interfaces
  with visual adjustments

### Recruitment

Blind and low vision participants are dramatically underrepresented in standard
research panels. Recruit through blindness organizations, screen reader community
forums, and assistive technology communities. These participants are often highly
experienced advocates — treat them as expert users, not as edge cases.

### Session Design for Screen Reader Users

- Never ask a screen reader user to share their screen and then observe them navigate
  without understanding how screen readers work. Learn the basics before the session:
  what virtual cursor mode is, how headings are navigated, what ARIA roles sound like.
- Allow the participant to use their own assistive technology setup — do not ask them
  to use an unfamiliar setup for the session.
- Remote sessions work well. In-person, ensure any required tech is compatible.
- Think-aloud works differently with screen reader users — they are already listening
  to audio output while trying to narrate. Use task-by-task retrospective debrief
  instead of concurrent think-aloud.

### What to Observe

- Screen reader announcement accuracy: what does the participant's screen reader
  actually say when they land on key UI elements? This is the experience.
- Navigation patterns: do they use headings, landmarks, or tab order? Each reveals
  different things about IA and semantic structure.
- Where they stop and why: screen reader users often stop on elements that are
  technically present but acoustically meaningless ("button, button, button").
- Frustration responses to unlabeled images, missing alt text, or focus traps — these
  are complete task blockers, not minor friction.

### Low Vision Considerations

- Ask about their setup before the session: magnification level, contrast settings,
  font size. Do not assume what they use.
- Test at their actual magnification level — UI that works at 100% zoom may break
  completely at 400%.
- Watch for scanning behavior: low vision users often scan in constrained visual
  windows, missing elements that appear in peripheral or lower areas of the screen.

---

## 6. Deaf & Hard of Hearing

This is a culturally and linguistically diverse group. Deaf culture (capital D) is
a distinct cultural identity with its own language (signed languages are full natural
languages, not codes for spoken language). Hard of hearing participants may use
hearing aids, cochlear implants, lip reading, or a combination. Never assume.

### Session Design

- Confirm communication preference before the session: signed language interpreter,
  captioning, lip reading, written chat, or spoken language.
- If using an interpreter, speak to the participant, not the interpreter. Maintain
  eye contact with the participant.
- Remote sessions with live captioning (CART) work well. AI auto-captions are not
  sufficient for research sessions — caption accuracy matters.
- For signed language users: video quality and framing matter for communication.
  Ensure good lighting and camera positioning for both participant and interpreter.

### What to Observe

- Audio-dependent UI elements: sounds, alerts, audio feedback — how does the participant
  experience these? Are they completely absent from the experience?
- Caption and subtitle quality if the product includes video or audio content.
- Visual alert design: do visual alternatives to audio alerts actually work and
  appear in places where the user's visual attention is directed?

### Research Language & Signed Languages

If you are conducting research with participants whose primary language is a signed
language (ASL, BSL, Auslan, etc.), the research materials, tasks, and debrief should
be delivered in that language — not translated from a written English original.
A signed language interpreter is not the same as conducting research in the participant's
language. Where possible, use Deaf researchers or co-facilitators.

---

## 7. Motor Impairments

This group includes participants who use alternative input devices (switch access,
eye gaze, voice control, head tracking, adapted keyboards, sip-and-puff) as well as
participants with reduced fine motor control who use standard input devices with
greater difficulty.

### Session Design

- Always confirm the participant's input method before the session. Never assume
  mouse and keyboard.
- Allow significantly more time for all tasks. Time-on-task data means something
  fundamentally different for switch access users than for mouse users.
- Do not ask participants to "just use the mouse for this" or to switch input methods
  for the session. They use what they use.
- Voice control users (Dragon NaturallySpeaking, Apple Voice Control): test whether
  your product's interactive elements are actually voice-commandable. Many "clickable"
  elements have no accessible name that voice control can target.

### What to Observe

- Target size and spacing: small touch targets and densely packed elements are
  complete barriers for some motor profiles, significant friction for others.
- Keyboard trap: any interactive element a keyboard user cannot escape without a
  mouse is a session-ending block.
- Error recovery: how much motor effort does it take to recover from an error?
  Undo, back navigation, and form error correction are all high-cost interactions
  for motor-impaired users.
- Drag-and-drop: frequently assumed as the primary interaction for reordering,
  sorting, or file management. For most alternative input users, drag-and-drop
  is inaccessible. Note every time it appears.

---

## 8. Mental Health Conditions

This covers a wide range of conditions — anxiety disorders, depression, bipolar
disorder, PTSD, OCD, eating disorders, psychosis, and others. Mental health is
relevant both when recruiting participants with mental health conditions and when
researching products used in mental health contexts (therapy platforms, crisis
support tools, medication management, peer support communities).

### Two Distinct Research Contexts

**Context A — Recruiting participants who happen to have mental health conditions**
The mental health condition may affect session dynamics without being the research
subject. Design for this without pathologizing.

**Context B — Researching mental health products**
The product and the research topic both carry emotional weight. Heightened ethical
obligations apply.

### Session Design (Context A)

- Disclosure is voluntary. Do not probe for mental health status unless directly
  relevant to the research and disclosed by the participant.
- Anxiety is extremely common in research sessions — the observation dynamic, the
  perceived performance pressure, the unfamiliarity of the format. Reduce these
  wherever possible: pre-session brief, framing it as learning not evaluation,
  normalizing breaks and stopping.
- Participants experiencing depression may have lower energy, slower verbal output,
  and less spontaneous elaboration. Do not interpret this as disengagement or
  insufficient data — adapt pacing and use more direct (but non-leading) probes.
- OCD and anxiety can produce highly detailed, precise behavioral data — these
  participants often notice things others miss. This is a research asset.

### Session Design (Context B — Mental Health Products)

- The research itself may surface distressing content. Have a distress protocol ready
  before starting: know what you'll say, know what resources you'll share.
- Do not research active crisis experiences in a standard session format. If a
  participant is currently in crisis, the session stops. Provide resources. Do not
  attempt to conduct research.
- Do not ask participants to relive traumatic experiences in detail to get research
  data. The insight is not worth the cost.
- Share resources at the end of every session, regardless of whether distress appeared:
  "Before we close, I want to make sure you have [resource] in case anything we
  discussed brings up difficult feelings later."
- For eating disorder-related products: take additional care around weight, food,
  and body language. Consult with clinical advisors before designing research involving
  eating disorder populations.

### Distress Protocol

If a participant shows signs of acute distress during a session:
1. Stop the research activity immediately.
2. Acknowledge without probing: "I want to pause here — are you okay to continue, or
   would you like to take a break?"
3. If distress continues: "It's completely fine to stop for today. Would it be helpful
   if I shared some support resources?"
4. Do not diagnose, counsel, or attempt to resolve the distress yourself.
5. Document the session notes with care — protect participant confidentiality
   particularly rigorously in these cases.
