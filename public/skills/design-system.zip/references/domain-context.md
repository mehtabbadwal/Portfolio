# Domain Context Reference

When a product has a specific commerce model, platform target, or industry domain,
apply the lens below BEFORE making component or pattern decisions. These are NOT
overrides of the core system — they are **modifiers** that layer on top.

---

## Commerce Model Lenses

Apply the correct lens based on how value flows between parties.

### B2B — Business to Business
Products sold by one company to another (e.g. Salesforce, Notion for Teams, Jira, Asana, HPE).

**Design priorities:**
- Density over whitespace — information-dense layouts, compact components (sm/md sizes primary)
- Role-based UI — same screen may show different controls per user role (admin vs. member vs. viewer)
- Bulk operations — multi-select patterns, batch actions, confirmation dialogs for destructive ops
- Data tables over cards — row-dense information display with sortable columns
- Empty states must explain business value, not just absence of data
- Onboarding is collaborative — team setup flows, invite patterns, permission handoffs
- Error messages must be specific enough for IT/admin to act on
- Status visibility — workflow stages, approval queues, audit trails
- Export and integration surfaces — CSV, API key management, webhook configs

**Component emphasis:** DataTable, StatusBadge, RoleTag, BulkActionBar, PermissionGate, AuditLog, InviteFlow

---

### B2C — Business to Consumer
Products sold directly to individual end users (Spotify, Airbnb, Instagram, Duolingo).

**Design priorities:**
- Emotion and delight over density — generous whitespace, illustrations, micro-animations
- Progressive disclosure — don't overwhelm first-time users
- Social proof — ratings, reviews, follower counts prominently placed
- Personalisation hooks — "For you", "Recommended", "Based on your history"
- Frictionless onboarding — reduce fields, allow guest access, defer registration
- Mobile-first — most B2C traffic is mobile; xl/lg sizes primary
- Notifications and re-engagement — push prompts, badge counts, streak indicators
- Trust signals — security badges, money-back guarantees, verified marks

**Component emphasis:** HeroCard, RatingStars, ReviewList, SocialShare, WishlistButton, StreakBadge, RecommendedRow

---

### C2C — Consumer to Consumer
Platforms where users transact with each other (Etsy, eBay, Airbnb host side, Depop).

**Design priorities:**
- Trust architecture — seller ratings, verification badges, transaction history, dispute flows
- Dual-sided UI — same product serves buyers AND sellers; the active role determines what renders
- Safety and reporting — every user-generated content surface needs Report/Flag
- Communication layer — in-product messaging between parties (not just notifications)
- Listing creation UX — guided multi-step flows with photo upload, pricing, category selection
- Review symmetry — both parties rate each other post-transaction
- Geographic context — local pickup, shipping calculator, currency display

**Component emphasis:** SellerCard, TrustBadge, ListingForm, ChatThread, ReportButton, BidInput, ShippingCalculator

---

### D2C — Direct to Consumer
Brand sells directly to consumers, bypassing retail (Warby Parker, Dollar Shave Club, Casper).

**Design priorities:**
- Brand immersion — every component reflects brand personality, not generic UI
- Conversion optimisation — minimal friction checkout, persistent cart, upsell moments
- Subscription and loyalty — recurring billing UI, tier status, reward points
- Product storytelling — rich media (video, 360°, zoom), comparison tables, feature callouts
- Post-purchase experience — order tracking, returns, reorder, referral
- Social proof integrated inline — not a separate reviews page; embedded in PDPs

**Component emphasis:** ProductCard, VariantSelector, QuantityInput, CartSummary, SubscriptionToggle, LoyaltyBadge, OrderTracker

---

### B2G / B2A — Business to Government / Business to Administration
Products sold to government agencies, public institutions, municipalities.

**Design priorities:**
- Accessibility is non-negotiable — WCAG 2.1 AA minimum, often AAA required; Section 508 (US), EN 301 549 (EU)
- Auditability — every action must be logged, attributable, reversible or documented
- Form-heavy workflows — long multi-step procurement forms, approval chains
- Print-ready outputs — reports, certificates, invoices designed for physical printing
- No dark patterns — government contracts prohibit manipulative UX
- Conservative visual design — neutral, institutional; never playful
- Offline/low-bandwidth consideration — field workers, rural offices
- Multilingual from day one — government software often requires multiple official languages

**Component emphasis:** AuditTrail, ApprovalChain, PrintableForm, AccessibilityChecker, OfficialSeal, ComplianceBadge

---

### C2G / C2A — Citizen to Government / Consumer to Administration
Platforms where individuals interact with government services (tax filing, permit applications, benefit claims).

**Design priorities:**
- Cognitive load reduction — users are stressed, unfamiliar; plain language always
- Error recovery at every step — save progress, resume later, never lose filled data
- Accessibility as baseline — users include elderly, disabled, low-literacy populations
- Trust and legitimacy signals — official logos, secure connection indicators, clear authority
- Multilingual and reading level — plain language guidelines, grade 6–8 reading level
- Mobile access — many citizens access via smartphone only
- Clear deadlines and consequences — always surface what happens if they don't act

**Component emphasis:** ProgressSaver, PlainLanguageAlert, DeadlineBanner, SecureFormField, LanguageSwitcher, HelpEscalation

---

### Social Commerce
Shopping embedded in social/content platforms (TikTok Shop, Instagram Shopping, Pinterest).

**Design priorities:**
- Content-first — product discovery through content, not search; video and creator content primary
- Impulse buy optimisation — 1-tap purchase from content, minimal checkout steps
- Creator attribution — commission tracking, affiliate links, creator storefronts
- Social validation — live reaction counts, comment-to-buy, viewer counts
- Ephemeral urgency — live shopping countdowns, limited drops, flash sales
- Discovery over search — algorithmic feed, trending, curated collections
- Community — shared wishlists, group buys, friend activity feeds

**Component emphasis:** LiveBadge, CreatorCard, QuickBuyOverlay, SocialReaction, CountdownTimer, AffiliateTag, DropAlert

---

## Platform Guidelines

### Apple HIG — Human Interface Guidelines
Apply when designing for iOS, iPadOS, macOS, watchOS.

**Key rules for component decisions:**
- Touch target minimum: **44×44pt** (non-negotiable on iOS)
- Navigation: tab bar (5 items max) on iOS; sidebar on iPadOS/macOS
- Typography: SF Pro system font; do not substitute unless brand explicitly overrides
- Modals: use sheet presentations (bottom-attached), not centred dialogs on mobile
- Destructive actions: always red, always at trailing position in menus
- Haptic feedback: pair visual state changes with haptic (document in spec)
- Safe areas: respect notch, home indicator, Dynamic Island; never place interactive elements in safe area zones
- Dark mode: fully supported in iOS; design tokens must include dark aliases
- SF Symbols: prefer system icons on Apple platforms for consistency
- Back navigation: always swipe-right gesture; never remove native back button

**Size reference for iOS:**
| Control | Minimum touch target | Visual size |
|---------|---------------------|-------------|
| Button (xl) | 44pt | 44pt |
| Button (lg) | 44pt | 44pt |
| Nav item | 44pt | 56pt bar |
| Tab bar | 44pt per item | 49pt bar |

---

### Material Design 3 (Material You)
Apply when designing for Android, or Google ecosystem products.

**Key rules:**
- Touch target minimum: **48×48dp** (stricter than Apple)
- Dynamic colour: Material You adapts to wallpaper; design tokens should use role-based naming (primary, secondary, tertiary, surface, background)
- Typography: Roboto or Google Sans; type scale is fixed (Display/Headline/Title/Body/Label)
- Navigation: navigation bar (bottom, 3–5 items) replaces nav drawer for primary destinations
- FAB: primary creation action, always lower-right, elevation via shadow
- Shape: uses rounded corners with a consistent shape scale; default = medium (16dp)
- State layers: hover/pressed/focused use semi-transparent overlays (not fill swaps) — document as opacity layer over base fill
- Elevation: 5 levels (0–5), each carries a tonal surface fill (not just shadow)
- Motion: standard easing (FastOutSlowIn), emphasised easing for entrances, linear for continuous

**M3 elevation → tonal surface fill:**
| Level | dp | Use |
|-------|----|-----|
| 0 | 0 | Background |
| 1 | 1 | Surface variant |
| 2 | 3 | Cards, dialogs |
| 3 | 6 | FAB, chip |
| 4 | 8 | Navigation drawer |
| 5 | 12 | Modal |

---

### Fluent 2 — Microsoft Design System
Apply when designing for Microsoft 365 ecosystem, Teams apps, Azure portal, Windows apps.

**Key rules:**
- Density: information-dense by default (enterprise context); compact variants primary
- Typography: Segoe UI Variable (Windows); fallback to system-ui
- Corner radius: Fluent 2 uses 4px (sm), 8px (md), 16px (lg) — matches system but uses 4px aggressively for smaller elements
- Acrylic / Mica: blur-behind materials for sidebars and panels — document as a surface variant
- Colour roles: Fluent uses semantic roles (Brand, Neutral, Status); never raw hex in components
- Compound components: Fluent favours composite "compound button" patterns (icon + title + subtitle stacked)
- Persona: avatar + name + status indicator treated as a first-class component
- Adaptive layout: Teams apps must work in sidebar (small), tab (medium), and full-screen (large) contexts
- Accessibility: keyboard navigation is primary for enterprise — every component must have full keyboard support documented

---

## Domain Guidelines

### Fintech — Financial Technology
Banking, payments, trading, insurance, crypto.

**Non-negotiable requirements:**
- Amount display: always show currency symbol, use locale-aware number formatting (1,234.56 not 1234.56)
- Colour for money: use semantic tokens only — green = gain, red = loss; NEVER use only colour (add +/- prefix)
- Confirmation gates: destructive financial actions (transfers, payments) require explicit confirmation modals — never single-tap
- Session timeouts: display countdown before auto-logout; never surprise-logout
- Loading states: financial data loads async; always show skeleton or spinner — never show stale data without indicator
- Error specificity: "Payment declined" is not enough — provide reason code and next step
- Audit trail: every transaction must be viewable, downloadable, printable
- Accessibility for numbers: screen readers must read amounts correctly — use aria-label with spelled-out currency

**Pattern watch:**
- Never use red for promotional prices (conflicts with loss indicator)
- Never animate balance numbers in a way that implies real-time trading if not real-time
- Truncation rules for long amounts: 1.2M not 1,234,567

---

### Healthcare
Clinical tools, patient portals, medical records, telehealth.

**Non-negotiable requirements:**
- WCAG AAA where possible — patients include elderly, visually impaired
- No dark patterns — patients must be able to exit flows freely, find help easily
- Emergency escalation always visible — crisis resources, emergency contacts
- Plain language — medical jargon must include plain-language tooltips or explanations
- Consent flows — explicit, unambiguous, timestamped; no pre-checked boxes
- Error gravity — distinguish between "please fill this field" and "this medication interaction is dangerous"
- PHI handling — never log, cache, or display Protected Health Information in non-secure contexts
- Session security — always require re-authentication before sensitive actions

**Pattern watch:**
- Red should ONLY indicate clinical urgency — never use for standard error states in clinical contexts (use amber/orange for non-critical errors to preserve red for genuine alerts)
- Confirmation dialogs for any action that affects clinical data

---

### SaaS — Software as a Service
Productivity tools, project management, CRMs, analytics platforms.

**Design priorities:**
- Workspace concept — users work inside persistent "spaces" (rooms, projects, workspaces)
- Collaboration indicators — who else is in the document, live cursors, presence avatars
- Data density — compact tables, filterable lists, sortable columns
- Customisation — users rearrange, rename, and configure their workspace
- Keyboard-first — power users drive via shortcuts; every action needs a keyboard path
- Integration surface — connect to Slack, GitHub, Jira, Google; webhook and API key management
- Offline graceful degradation — indicate connectivity state, queue actions when offline
- Onboarding telescopes — reveal features progressively; don't show advanced options on first use

**Component emphasis:** WorkspaceCard, MemberPresence, FilterBar, ColumnPicker, IntegrationCard, KeyboardShortcutBadge, ConnectionStatus

---

### eCommerce
Retail, marketplaces, product catalogues.

**Design priorities:**
- Product card is the atomic unit — image, title, price, rating, CTA in one scannable block
- Price hierarchy — current price largest, original price struck-through, discount % or amount highlighted
- Inventory signals — "Only 3 left", "Ships in 2 days", out-of-stock states block add-to-cart
- Cart persistence — cart survives session, login, and device (sync to account)
- Checkout funnel — every additional step loses ~20% of users; minimise steps aggressively
- Guest checkout — always offer; don't require account creation before purchase
- Trust signals inline — security badges at payment, return policy near price, reviews near CTA
- Mobile checkout — large tap targets, autofill-compatible fields, Apple Pay / Google Pay support

**Pattern watch:**
- Never disable the CTA until you've explained why (out of stock, select size first)
- Filters and sorting are primary navigation — not secondary toolbars

---

### Enterprise
Large organisation internal tools, admin dashboards, ERP, HRIS.

**Design priorities:**
- Role-based access visible in UI — clearly indicate when a user can't do something and why
- Bulk operations essential — select all, bulk edit, bulk export, bulk delete with confirmation
- Data tables are primary — sortable, filterable, with column picker; pagination or virtual scroll for 1000+ rows
- Approval chains — multi-step, multi-person workflows with clear state visibility
- Audit and compliance — who did what, when, from where
- System status — real-time indicators for integrations, sync status, background jobs
- Help and documentation inline — contextual help, not just a link to external docs
- Dense information architecture — sidebar nav, breadcrumbs, multiple panes common

**Pattern watch:**
- Do not hide navigation — enterprise users need to orient themselves at all times
- Error messages must include error codes for IT support tickets

---

### AI / ML Products
Products powered by or exposing AI capabilities (e.g. Copilot, Claude, Midjourney, Notion AI, Cursor).

**Design priorities:**
- Transparency about AI — always make clear when content is AI-generated; never pass AI output as human
- Confidence indicators — show when the AI is uncertain; don't present all outputs as equally reliable
- Editable AI output — users must always be able to correct, override, or dismiss AI suggestions
- Loading states for generation — AI responses take time; skeletons, streaming text, or progress indicators required
- Prompt/input surface — clear affordance for how to give instructions; examples help
- Error recovery — AI failures should degrade gracefully ("I couldn't generate this — try rephrasing")
- Feedback mechanisms — thumbs up/down, correction flows feed the model; make them easy
- Privacy signals — be explicit about what data is sent to the model and how it's used
- Hallucination handling — surfaces that display AI-generated facts should link to sources or include confidence scores

**Component emphasis:** AIGeneratingIndicator, ConfidenceBadge, EditableAIOutput, PromptInput, FeedbackRow, SourceCitation, StreamingText

---

### Developer Tools
IDEs, CLIs, API dashboards, documentation platforms, observability tools.

**Design priorities:**
- Code is content — monospace fonts, syntax highlighting, line numbers, copy-to-clipboard on all code blocks
- Dark mode as default — developers expect dark; light mode is the opt-in
- Keyboard-first — every action needs keyboard access; command palette expected
- Information density — developers tolerate and expect dense UIs; whitespace is wasteful
- Terminal aesthetic — monospace, muted colours, clear signal/noise separation
- API explorer — try-it-now surfaces, request/response panels, cURL snippet generation
- Error specificity — stack traces, line numbers, request IDs, copy-to-clipboard on errors
- Docs-as-product — documentation is a first-class UI surface, not an afterthought

**Component emphasis:** CodeBlock, CopyButton, SyntaxHighlighter, RequestPanel, ResponsePanel, TerminalOutput, StatusIndicator, CommandPalette

---

### Biotech / Life Sciences
Lab tools, clinical trial platforms, genomics dashboards, lab information management (LIMS).

**Design priorities:**
- Data integrity first — any action that modifies experiment data must have confirmation and audit trail
- Scientific notation and units — display values with correct units, significant figures, and notation
- Protocol-driven flows — users follow rigid procedures; UI should enforce sequence, not allow skipping
- Version control for data — experiments and results must be versioned and diff-able
- Collaboration with traceability — who made which change, when, to which dataset
- Regulatory compliance — FDA 21 CFR Part 11, GxP requirements for electronic records
- Accessibility in lab context — consider glove-friendly touch targets, high-contrast for lab lighting
- Export and reporting — raw data export (CSV, JSON), PDF reports formatted for submission

**Component emphasis:** ProtocolStep, AuditEntry, VersionDiff, UnitDisplay, ConfidenceInterval, SubmissionStatus, GloveTarget (min 48px)

---

## Applying Domain Context in Practice

When starting a component build for a domain-specific product:

1. **Identify the commerce model** — this determines the primary user relationship and trust patterns
2. **Identify the platform** — this sets the non-negotiable touch targets, nav patterns, and OS conventions
3. **Identify the domain** — this adds the industry-specific non-negotiables (compliance, error gravity, data display rules)
4. **Layer on top of the base system** — never discard the core token/sizing system; domain context modifies decisions, it doesn't replace them

### Quick Decision Matrix

| If the product is... | Then prioritise... |
|---------------------|-------------------|
| B2B SaaS | Density, roles, keyboard shortcuts, bulk ops |
| B2C mobile | Delight, progressive disclosure, social proof |
| C2C marketplace | Trust, dual-sided UI, reporting, messaging |
| D2C eComm | Conversion, brand, subscription, post-purchase |
| B2G/B2A | Accessibility AAA, auditability, print-ready |
| Healthcare | Plain language, consent, emergency escalation |
| Fintech | Amount formatting, confirmation gates, audit trail |
| AI product | Transparency, editability, loading states, feedback |
| Developer tool | Code blocks, keyboard, dark mode, command palette |
| Biotech | Protocols, audit, regulatory, version control |
