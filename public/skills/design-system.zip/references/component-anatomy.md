# Component Anatomy Reference

## Auto-Layout Sizing Contract

The universal rule for every component frame. Apply exactly — never guess.

### Default Rule
```
Height:  HUG  — always content-driven by default
Width:   FILL — inherits from parent container by default
```

### Width Exceptions — When to Use HUG
```
Component / situation                     Why
─────────────────────────────────────────────────────────────────
Buttons (standalone showcase)             No parent to fill — use 320px fixed
Icon-only button (showLabel=false)        Square: paddingH = paddingV
Tags, Badges, Chips                       Content-sized by design — don't fill
Tooltips, Popovers                        Fixed max-width (240px / 320px)
Breadcrumb/Item                           Content-sized — avoid stretching
Avatar (all sizes)                        Always square — fixed H = fixed W
```

### Width Fixed — When to Use FIXED
```
Component / situation                     Why
─────────────────────────────────────────────────────────────────
Icon containers (Icon component)          Always square — fixed H = fixed W = size
Tab/Bar                                   56px mobile, 40px desktop
Nav/BottomBar                             56px
Avatar                                    Fixed per size (48/40/32/24/16px)
```

### ✅ CRITICAL: Padding-Driven Height for ALL Interactive Controls

**NEVER use fixed height on buttons, inputs, dropdowns, toggles, or any
interactive component.** Always use HUG height + vertical padding to achieve
the target height.

**How to calculate paddingV:**
Target height = paddingTop + tallest child (icon or text) + paddingBottom

```
size=xl  target 48px  → icon=16px  → paddingV = (48 - 16) / 2 = 16px each side
size=lg  target 44px  → icon=16px  → paddingV = (44 - 16) / 2 = 14px each side
size=md  target 40px  → icon=16px  → paddingV = (40 - 16) / 2 = 12px each side
size=sm  target 32px  → icon=12px  → paddingV = (32 - 12) / 2 = 10px each side
```

Always state this explicitly in prompts:
```
height: HUG  ← DO NOT set a fixed height
paddingTop: 16px, paddingBottom: 16px  ← this gives the xl=48px height
```

**Exception:** when a component must fill a fixed-height container (Tab/Bar,
Nav/BottomBar) — use height: FILL inside the parent.

### Label Node Sizing Inside Buttons

The **Label text node** inside every horizontal auto-layout button must be
`width: fill` so it expands the component frame. Failure produces icon-only-width
buttons even when a label is present.

### Focus Ring Clip Warning — CRITICAL

The focus ring shadow extends 3px **outside** the component frame.
**Never set `clip content: true` on any interactive component frame** — this
silently hides the focus ring. Clip content is only appropriate on inner frames
(e.g. image containers inside cards). The component's outermost frame must
always have clip content **off**.

---

## ⚠️ Programmatic Build Sizing Rules (use_figma / MCP direct)

When building components directly via `figma.use_figma` or the Figma MCP plugin
API (not via Claude Code prompts), the sizing mode API values are different from
Figma's UI labels. Always use these exact API values:

```
Figma UI label   →   API property value
──────────────────────────────────────────────────────────
Hug contents     →   node.primaryAxisSizingMode = 'AUTO'
                     node.counterAxisSizingMode = 'AUTO'
Fill container   →   node.primaryAxisSizingMode = 'FIXED' with width = parent
Fixed            →   node.primaryAxisSizingMode = 'FIXED'
                     node.counterAxisSizingMode = 'FIXED'
```

### Sizing rules by layer type

```
Layer                     primaryAxisSizingMode   counterAxisSizingMode
──────────────────────────────────────────────────────────────────────
Component (outer frame)   FIXED (set width)       AUTO (height hugs)
  ↳ Exception: icon component   FIXED             FIXED (always square)
Inner frame (e.g. LabelGroup)   AUTO              AUTO (hug both)
Text node                 textAutoResize = 'WIDTH_AND_HEIGHT'
Instance (Control inside Item)  do NOT change — inherits from master
```

### Mandatory post-build check for every component

After building any component programmatically, verify these before finishing:

```javascript
// Check sizing — paste into a verification script
function verifySizing(node, depth = 0) {
  if (node.type === 'TEXT' && node.textAutoResize !== 'WIDTH_AND_HEIGHT') {
    console.error(`TEXT node "${node.name}" is NOT auto-resizing — set textAutoResize = 'WIDTH_AND_HEIGHT'`);
  }
  if (node.layoutMode && node.counterAxisSizingMode === 'FIXED' && node.type !== 'COMPONENT') {
    console.warn(`Frame "${node.name}" has FIXED counter axis — should be AUTO unless intentional`);
  }
  if (node.clipsContent && node.type === 'COMPONENT') {
    console.error(`Component "${node.name}" has clipsContent=true — focus rings will be clipped`);
  }
  node.children?.forEach(c => verifySizing(c, depth + 1));
}
```

### The three most common programmatic sizing bugs

1. **Text nodes not auto-resizing** — always set `node.textAutoResize = 'WIDTH_AND_HEIGHT'`
   on every text node. Figma defaults to `'NONE'` (fixed width AND height) on
   programmatically created text nodes.

2. **Inner frames fixed instead of hug** — when creating frames inside components
   (LabelGroup, ContentGroup, etc.), always set both:
   `frame.primaryAxisSizingMode = 'AUTO'`
   `frame.counterAxisSizingMode = 'AUTO'`
   Figma defaults new frames to `FIXED`.

3. **Component counter axis fixed** — the component outer frame height should hug
   its children. Always set `comp.counterAxisSizingMode = 'AUTO'` unless the
   component is a fixed-size control (Icon, Avatar, etc.).

---

## How to Think About Any New Component

Before writing a prompt for any component, work through these questions:

### 1. What Category Is This Component?

| Category | Examples | Key concerns |
|----------|----------|--------------|
| **Interactive control** | Button, Toggle, Checkbox, Radio, Slider | States, touch targets, keyboard nav |
| **Input / form** | Text input, Textarea, Dropdown, Date picker | States, label, hint, char count |
| **Display / content** | Card, Banner, Badge, Tag, Avatar, Chip | Size scale, content slots, optional elements |
| **Navigation** | Tabs, Breadcrumb, Pagination, Stepper | Active/inactive states, overflow behavior |
| **Overlay** | Modal, Drawer, Tooltip, Popover, Toast | Position/anchor, dismiss behavior, backdrop |
| **Layout / structural** | Divider, Spacer, Section header, Empty state | Orientation variants, slot flexibility |

### 2. What Are the Genuine States?

| State | Ask |
|-------|-----|
| disabled | Can it be unavailable? (most interactive: yes) |
| error | Can it have invalid state? (inputs, form controls: yes; buttons: no) |
| loading | Is it async-triggered? (CTAs: yes; toggles/links: no) |
| empty | Does it hold content that might be absent? (lists, feeds: yes) |
| selected/active | Can it be chosen? (tabs, toggles, nav items: yes) |
| hover | Only if cursor exists — not on pure mobile |

### 3. What Are the Genuine Variants?

A variant represents a **meaningfully different visual treatment** a designer
consciously chooses between in a layout. If it's just showing/hiding an element,
use a `show[X]` boolean prop instead — not a variant.

### 4. What Content Slots Does It Have?

For any optional internal element, apply the `show[X]` boolean rule.

### 5. Does It Need a Size Scale?

Use the standard 4-size platform system (xl/lg/md/sm) for components that appear
across all platform contexts. For single-context components, spec only relevant sizes.

---

## Core Component Philosophy

### ⚠️ Icon Container Frames — ALWAYS Auto-Layout

Every frame used as an icon slot or icon wrapper MUST have auto-layout.
**Never use a plain frame (layoutMode=NONE) for icon containers.**

This applies to ALL of these named slots:
```
IconContainer, IconSlot, IconWrapper, Icon, ButtonIcon,
LeadingIcon, TrailingIcon, NavIcon, IconPlaceholder, CloseButton
```

**Required settings for every icon container frame:**
```javascript
node.layoutMode              = 'HORIZONTAL'
node.primaryAxisAlignItems   = 'CENTER'
node.counterAxisAlignItems   = 'CENTER'
node.primaryAxisSizingMode   = 'FIXED'   // fixed square — never AUTO
node.counterAxisSizingMode   = 'FIXED'   // fixed square — never AUTO
node.paddingLeft = node.paddingRight = node.paddingTop = node.paddingBottom = 0
node.clipsContent            = false
```

Why this matters: a plain NONE-layout frame doesn't respond to content changes or
constrain children correctly. Icon instances placed inside NONE frames can drift,
clip at edges, or lose centering when the icon size changes.

---

### ⚠️ Divider Lines — ALWAYS Auto-Layout

Every frame used as a divider or separator MUST have auto-layout.
**Never use a plain frame (layoutMode=NONE) for dividers.**

This applies to ALL of these:
```
Divider, HeaderDivider, FooterDivider, TopBorder, RightBorder,
SectionDivider, Separator, NavDivider* (any NavDivider prefix)
```

**Required settings for horizontal dividers (h=1px):**
```javascript
node.layoutMode              = 'HORIZONTAL'
node.primaryAxisSizingMode   = 'FIXED'   // fixed width
node.counterAxisSizingMode   = 'FIXED'   // fixed 1px height
node.paddingLeft = node.paddingRight = node.paddingTop = node.paddingBottom = 0
node.clipsContent            = false
```

**Required settings for vertical dividers (w=1px):**
```javascript
node.layoutMode              = 'VERTICAL'
node.primaryAxisSizingMode   = 'FIXED'   // fixed height
node.counterAxisSizingMode   = 'FIXED'   // fixed 1px width
node.paddingLeft = node.paddingRight = node.paddingTop = node.paddingBottom = 0
node.clipsContent            = false
```

Orientation detection rule: if `height <= 2` → horizontal divider. If `width <= 2` → vertical divider.

---

### The `show[X]` Boolean Prop Rule — CRITICAL

**Never create a separate variant for "version without X."**
Instead, add a `show[ElementName]` boolean prop that hides/shows elements
within the same component.

Standard boolean props:
- `showLabel` — hides the text label (icon-only mode)
- `showLeadingIcon` / `showTrailingIcon` — hide icon slots

**Naming rule — always use Leading/Trailing, never Left/Right.**
Leading/Trailing is direction-agnostic and survives RTL layouts.

When `showLabel=false` on a pill/circular button → set `paddingH = paddingV`
so the button collapses into a perfect circle (equal padding on all sides).
An icon-only button **must** receive an `aria-label`.

---

## Size System

Four sizes, mapped to platforms. Heights are **exact and non-negotiable**.

| Key | Height | paddingV | paddingH | Icon  | Font | Gap | Platform |
|-----|--------|----------|----------|-------|------|-----|----------|
| xl  | 48px   | 16       | 22       | 16px  | 16px | 8   | Mobile hero CTAs |
| lg  | 44px   | 14       | 20       | 16px  | 16px | 8   | Mobile standard (Apple HIG 44pt) |
| md  | 40px   | 12       | 18       | 16px  | 14px | 6   | Tablet |
| sm  | 32px   | 10       | 14       | 12px  | 13px | 5   | Desktop |

**Always state heights with emphasis in prompts.** Say "(currently Xpx — must be Ypx)"
when correcting, and add "DO NOT alter this height" to prevent drift.

---

## Platform Best Practices

### Touch Targets (Mobile)

Apple HIG minimum: **44pt**. Google Material minimum: **48dp**.
Recommended standard: **48px mobile** (meets both).

**Rule:** Tappable frame must be at least 44px tall. The visual element can be
smaller — achieve the target via transparent padding on the frame.

### Height by Component Type

**Desktop heights:**
| Component type | Desktop height |
|---|---|
| Button (action) | 32px |
| Button (toolbar toggle) | 32px |
| Search input | 36px |
| Standard input / dropdown | 40px |
| Textarea | 120px min |

**Mobile heights:**
| Component type | Mobile height |
|---|---|
| Button (standard) | 44px |
| Button (hero CTA) | 48px |
| Search input | 48px |
| Standard input / dropdown | 48px |
| Textarea | 120px min |

**Key insight:** inputs are taller than buttons at the same platform level.
Desktop: inputs = 36–40px, buttons = 32px.
Mobile: both = 48px (inputs cannot go lower due to touch targets).

### State Trimming by Platform

Only include states physically possible on each platform.

| State | Mobile | Tablet | Desktop |
|---|---|---|---|
| default | ✅ | ✅ | ✅ |
| hover | ❌ | ✅ | ✅ |
| pressed | ❌ | ✅ | ✅ |
| focus | ❌ | ❌ | ✅ |
| disabled | ✅ | ✅ | ✅ |
| loading | ✅ | ✅ | ✅ |
| error | ✅ | ✅ | ✅ |
| selected | ✅ | ✅ | ✅ |
| visited | ✅ | ✅ | ✅ |

**Component exceptions:**
- ToolbarButton: no `pressed` or `loading` — instantaneous toggles
- TextLink: no `pressed` or `loading`, add `visited` on all platforms
- SearchBar / Inputs: no `pressed` — inputs don't have a pressed visual state

### Density — Desktop vs Mobile

| Property | Desktop (sm) | Mobile (xl) |
|---|---|---|
| Horizontal padding | 12–14px | 14–22px |
| Gap (icon + label) | 5–6px | 8px |
| Font size (body) | 13px | 16px |
| Icon size | 14–16px | 18–20px |
| Border radius (rect button) | 6–8px | 12px |

Note: 10px border radius is off the 4px grid — never use it.

### Disabled State Rule — CRITICAL

**NEVER use `opacity: 0.4` (or any opacity value) on any component frame.**
Always apply system tokens directly to each layer:
- Frame fill → `disabledBg`
- Text → `disabledText`
- Border → `disabledBorder`
- Icons → `disabledText`

### Focus Ring Standard — CRITICAL

Apply identically to ALL interactive components:
- **Border:** [primary color], **1.5px** (never 2px)
- **Ring shadow:** `0 0 0 3px rgba([onPrimary RGB], 0.5)` (never 0.4 opacity)

The focus border color is always **primary** — never a hover or visited color.

---

## Shadow Assignment by Component and State — CRITICAL

**Shadows are NOT optional decoration.** They communicate elevation, interactivity,
and focus. Every component prompt must include the correct shadow for every state.

Never omit a shadow because it "looks subtle." Never add a shadow not in this table.
Always bind via `setEffectStyleId` — never raw values.

### Complete Shadow Reference Table

| Component | State | Effect Style Token |
|-----------|-------|-------------------|
| **PillButton / RectButton** | | |
| primary | hover | `[Prefix]/Shadow/button-hover` |
| primary | pressed | none — remove shadow |
| primary | focus | `[Prefix]/Shadow/focus-ring` |
| primary | disabled | none |
| secondary | hover | none |
| secondary | focus | `[Prefix]/Shadow/focus-ring` |
| ghost | hover | none |
| ghost | focus | `[Prefix]/Shadow/focus-ring` |
| danger | hover | `[Prefix]/Shadow/button-hover` (use danger RGB) |
| danger | focus | `[Prefix]/Shadow/focus-error` |
| **ToolbarButton** | focus | `[Prefix]/Shadow/focus-ring` |
| **InputField / TextArea / Dropdown / SearchBar** | focused | `[Prefix]/Shadow/focus-ring` |
| | error | `[Prefix]/Shadow/focus-error` |
| | default/filled/disabled | none |
| **Card elevated** | default | `[Prefix]/Shadow/lg` |
| **Card elevated** | hover | `[Prefix]/Shadow/xl` |
| **Card default** | default | `[Prefix]/Shadow/sm` |
| **Card outlined / flat** | default | none |
| **Modal / Dialog** | visible | `[Prefix]/Shadow/lg` |
| **Drawer / Bottom Sheet** | visible | `[Prefix]/Shadow/xl` |
| **Dropdown / Popover / Menu** | open | `[Prefix]/Shadow/md` |
| **Tooltip** | visible | `[Prefix]/Shadow/md` |
| **Toast / Snackbar** | visible | `[Prefix]/Shadow/lg` |
| **Nav/BottomBar** | default | `[Prefix]/Shadow/nav` |
| **Nav/Sidebar** | default | `[Prefix]/Shadow/sidebar` |
| **FAB** | default | `[Prefix]/Shadow/xl` |
| **Toggle/Switch track** | pressed | `[Prefix]/Shadow/inner` |
| **Checkbox / Radio** | focus | `[Prefix]/Shadow/focus-ring` |

### Shadow Rules

```
1. HOVER LIFT — only on filled action buttons (primary, danger).
   Never on secondary, ghost, outline, or toolbar buttons.

2. FOCUS RING — on EVERY interactive component that can receive keyboard focus.
   No exceptions. Pair with 1.5px primary border.

3. ELEVATION — cards, modals, drawers, dropdowns, tooltips, toasts, FABs, nav bars.
   Never add elevation to flat components (tabs, inputs, buttons).

4. INNER SHADOW — pressed/active state for toggle tracks only.

5. PRESSED STATE always removes shadow (buttons).

6. DISABLED STATE never has shadows of any kind.
```

### Specifying Shadows in Prompts

```
hover state:
  Apply effect style [Prefix]/Shadow/button-hover
  (bind via setEffectStyleId — do not set raw rgba values)

focus state:
  Apply effect style [Prefix]/Shadow/focus-ring
  (bind via setEffectStyleId)
  Also set border: 1.5px solid [bind to [Prefix]/color/border/strong]

error focus state:
  Apply effect style [Prefix]/Shadow/focus-error
  (bind via setEffectStyleId)
  Also set border: 1.5px solid [bind to [Prefix]/color/semantic/errorBorder]

pressed state:
  Remove all shadows (setEffectStyleId to none / clear effects)

disabled state:
  Remove all shadows (setEffectStyleId to none / clear effects)
```
