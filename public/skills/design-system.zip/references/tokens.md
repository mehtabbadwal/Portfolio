# Tokens Reference

## Design Tokens

These are the only values to use in prompts. Never introduce new values.
Always include both the hex AND the variable path in prompts:

```
InputBox border: #______ ([prefix]/border/default)
```

**Variable reference format:**
```
─── BRAND ──────────────────────────────────────────────────────
color/brand/primary          [hex]
color/brand/primaryHover     [hex]
color/brand/primaryDeep      [hex]
color/brand/onPrimary        [hex]
color/brand/onPrimaryMuted   [hex]
color/brand/navBg            [hex]
color/brand/mutedText        [hex]

─── SURFACE ────────────────────────────────────────────────────
color/surface/default        [hex]   ← Figma variable: color/surface/default
color/surface/elevated       [hex]   ← Figma variable: color/surface/elevated
color/surface/overlay        rgba(0,0,0,0.48)

─── BORDER ─────────────────────────────────────────────────────
color/border/default         [hex]
color/border/strong          [primary hex]
color/border/error           #e53e3e

─── DISABLED ───────────────────────────────────────────────────
color/disabled/bg            [hex]
color/disabled/border        [hex]
color/disabled/text          [hex]

─── SEMANTIC ───────────────────────────────────────────────────
color/semantic/successBg     #e6f4ea
color/semantic/successBorder #a8d5b5
color/semantic/successText   #1e7e34
color/semantic/warningBg     #fef8be
color/semantic/warningBorder #f0d080
color/semantic/warningText   #7f420e
color/semantic/errorBg       #fde8e8
color/semantic/errorBorder   #f5aaaa
color/semantic/errorText     #e53e3e
color/semantic/infoBg        [surface]
color/semantic/infoBorder    [defaultBorder]
color/semantic/infoText      [primary]
```

---

## Figma Variable System

Every product uses 4 variable collections in Figma. Set these up before
building any components.

**[Prefix] / Color** — all color tokens (see Design Tokens above)

**[Prefix] / Spacing** — number variables
```
spacing/xs       4px
spacing/sm       8px
spacing/md       12px
spacing/lg       16px
spacing/20       20px   ← always include this step between 16 and 24
spacing/xl       24px
spacing/2xl      32px
spacing/3xl      48px
spacing/4xl      64px
```

**[Prefix] / Radius** — number variables
```
radius/sm    6px    ← desktop compact buttons
radius/md    8px    ← toolbar items, sidebar items
radius/lg    12px   ← inputs, dropdowns, textareas, mobile buttons
radius/xl    16px   ← cards, toasts, tags
radius/2xl   20px   ← modal panels
radius/pill  9999px ← all pill-shaped elements
```

Rule: all radius values must be on the 4px grid. 10px is off-grid — use 8 or 12.

**[Prefix] / Effects** — string variables (dev reference only — NOT what gets applied in Figma)

> ⚠️ **IMPORTANT DISTINCTION:** These are string Variable values for developer token reference.
> They are NOT the same as Figma Effect Styles. Effect Styles are what actually get applied
> to layers via `setEffectStyleId`. See Effect Styles Template below.

```
effect/shadow/none          "none"
effect/shadow/xs            "0px 1px 2px rgba(0,0,0,0.06)"
effect/shadow/sm            "0px 1px 3px rgba(0,0,0,0.08), 0px 1px 2px rgba(0,0,0,0.06)"
effect/shadow/md            "0px 4px 16px rgba(0,0,0,0.12)"
effect/shadow/lg            "0px 8px 32px rgba(0,0,0,0.14), 0px 2px 8px rgba(0,0,0,0.08)"
effect/shadow/xl            "0px 16px 48px rgba(0,0,0,0.14), 0px 4px 16px rgba(0,0,0,0.08)"
effect/shadow/nav           "0px -2px 4px rgba(0,0,0,0.08)"
effect/shadow/sidebar       "2px 0px 8px rgba(0,0,0,0.06)"
effect/shadow/inner         "inset 0px 1px 3px rgba(0,0,0,0.10)"
effect/shadow/button-hover  "0px 2px 8px rgba([primary RGB],0.24)"  ← brand-tinted
effect/focusRing            "0px 0px 0px 3px rgba([onPrimary RGB],0.50)"
effect/shadow/focus-error   "0px 0px 0px 3px rgba(229,62,62,0.25)"
```

### Effect Style Usage Guide

```
xs   → list item hover, avatar separation
sm   → cards, file rows, table rows
md   → dropdowns, tooltips, toasts, menus
lg   → modals, dialogs, bottom drawers
xl   → bottom sheets, featured panels
nav       → mobile bottom nav bar (upward shadow)
sidebar   → desktop sidebar (rightward shadow)
inner     → pressed buttons, toggle tracks
button-hover → primary button hover lift (brand-colored, not black)
focusRing    → ALL focused interactive elements
focus-error  → error-state input fields only
```

### Variable Naming Rule

When referring to a token in a component prompt, always use both the
hex value AND the variable path so developers can bind correctly:
```
InputBox border: #______ ([prefix]/border/default)
Button fill:     #______ ([prefix]/brand/primary)
```
Never reference a hex value alone — always pair it with its variable name.

---

## Figma Styles System

**CRITICAL DISTINCTION — Styles vs Variables:**

| | Variables | Styles |
|---|---|---|
| Where | Variables panel | Styles panel (4-grid icon) |
| Purpose | Dev tokens, number/string values | Designer-applied to layers |
| Shows in design panel | No | Yes — clickable in Inspector |
| How to create | Variable collections | Text Style / Effect Style APIs |

**Rule: always create BOTH for typography and effects.**
- Variables → dev reference
- Text Styles → applied to layers in Figma
- Effect Styles → applied to layer shadows

### Text Styles — Template

18 Text Styles grouped with "/" prefix. All use [Brand Font].

```
─── [Prefix]/Heading/ ──────────────────────────────────────────
[Prefix]/Heading/Bold 48    Bold 700, 48px,  auto lh  (doc hero)
[Prefix]/Heading/Bold 20    Bold 700, 20px,  auto lh  (page headings)
[Prefix]/Heading/SemiBold 18 SemiBold 600, 18px, auto lh (modals)
[Prefix]/Heading/Bold 16    Bold 700, 16px,  auto lh  (sections)
[Prefix]/Heading/Bold 12    Bold 700, 12px,  auto lh  (compact)

─── [Prefix]/Body/ ─────────────────────────────────────────────
[Prefix]/Body/Regular 16    Regular 400, 16px, lh 160%  (editorial)
[Prefix]/Body/Regular 14    Regular 400, 14px, lh 20px  (mobile body)
[Prefix]/Body/Regular 13    Regular 400, 13px, lh 18px  (desktop body)
[Prefix]/Body/Regular 12    Regular 400, 12px, lh 16px  (captions/helper)
[Prefix]/Body/Medium 14     Medium 500,  14px, auto lh  (button labels)
[Prefix]/Body/Medium 13     Medium 500,  13px, auto lh  (desktop buttons)
[Prefix]/Body/Medium 12     Medium 500,  12px, lh 16px  (small labels)

─── [Prefix]/Label/ ────────────────────────────────────────────
[Prefix]/Label/SemiBold 14  SemiBold 600, 14px, auto lh
[Prefix]/Label/SemiBold 13  SemiBold 600, 13px, auto lh
[Prefix]/Label/SemiBold 11  SemiBold 600, 11px, ls 15%, auto lh  ← UPPERCASE only
[Prefix]/Label/SemiBold 10  SemiBold 600, 10px, ls 15%, auto lh  ← UPPERCASE only
[Prefix]/Label/Medium 11    Medium 500,  11px, ls 13%, auto lh
[Prefix]/Label/Medium 10    Medium 500,  10px, auto lh
```

### Effect Styles — Template

```
[Prefix]/Shadow/xs through xl   — match the effect/shadow/ variable values above
[Prefix]/Shadow/Directional/Nav
[Prefix]/Shadow/Directional/Sidebar
[Prefix]/Shadow/Directional/Inner
[Prefix]/Shadow/Interactive/Button Hover
[Prefix]/Shadow/Interactive/Focus Ring
[Prefix]/Shadow/Interactive/Focus Error
```

### Shadow Values for Step 1 Token Foundation

```
[Prefix]/Shadow/sm
  Drop Shadow: rgba(0,0,0,0.06)  X:0  Y:1  Blur:2   Spread:0

[Prefix]/Shadow/md  (TWO layers)
  Layer 1: rgba(0,0,0,0.06)  X:0  Y:2  Blur:4   Spread:0
  Layer 2: rgba(0,0,0,0.04)  X:0  Y:1  Blur:2   Spread:0

[Prefix]/Shadow/lg  (TWO layers)
  Layer 1: rgba(0,0,0,0.08)  X:0  Y:4  Blur:8   Spread:0
  Layer 2: rgba(0,0,0,0.04)  X:0  Y:2  Blur:4   Spread:0

[Prefix]/Shadow/xl  (TWO layers)
  Layer 1: rgba(0,0,0,0.08)  X:0  Y:8  Blur:16  Spread:0
  Layer 2: rgba(0,0,0,0.04)  X:0  Y:4  Blur:8   Spread:0

[Prefix]/Shadow/nav
  Drop Shadow: rgba(0,0,0,0.08)  X:0  Y:-2  Blur:4  Spread:0

[Prefix]/Shadow/sidebar
  Drop Shadow: rgba(0,0,0,0.06)  X:2  Y:0   Blur:8  Spread:0

[Prefix]/Shadow/inner
  Inner Shadow: rgba(0,0,0,0.10)  X:0  Y:1  Blur:3  Spread:0

[Prefix]/Shadow/button-hover
  Drop Shadow: rgba([primary RGB], 0.30)  X:0  Y:4  Blur:12  Spread:0
  ← use actual brand primary RGB, not black

[Prefix]/Shadow/focus-ring
  Drop Shadow: rgba([primary RGB], 0.50)  X:0  Y:0  Blur:0  Spread:3
  ← focus ring is a spread shadow, not a border

[Prefix]/Shadow/focus-error
  Drop Shadow: rgba(229,62,62,0.25)  X:0  Y:0  Blur:0  Spread:3
```

### Line Height Rules — CRITICAL

| Category | Rule | Why |
|---|---|---|
| Headings | auto (~1.2) | Short, visual — padding does spacing |
| Labels | auto (~1.2) | Always single-line UI chrome |
| Body/Medium (buttons) | auto | Single-line, padding controls spacing |
| Body/Regular 16 | 160% | Editorial reading — spacious |
| Body/Regular 14 | 20px (143%) | Material 3 body-medium standard |
| Body/Regular 13 | 18px (138%) | Desktop body — 13×1.4 rounded even |
| Body/Regular 12 | 16px (133%) | Helper/caption — WCAG readable minimum |
| Body/Medium 12 | 16px (133%) | Consistent with Regular 12 |

**Calculation:** font size × 1.4, round to nearest even number.
Auto (~1.2) is only safe for single-line elements.

---

## Token Audit Standards

When auditing or creating tokens, check against:
- **Typography:** Browser default 16px. Material 3 / Apple HIG scales.
  15px is NOT a standard value — use 16px for reading contexts.
- **Spacing:** 4px base grid. Every value divisible by 4.
  Always include `spacing/20` (20px) between 16 and 24.
- **Border radius:** 4px grid (4, 8, 12, 16, 20...).
  10px is off-grid — use 8px or 12px. ToolbarButton = 8px.
- **Shadows:** opacity 0.06–0.08 for card elevation.
  Two-layer shadows for sm/lg/xl (tight penumbra + soft umbra).
  Brand-colored shadow on button hover (primary rgba, not black).
  `effect/shadow/md` at 0.12 is intentional for dropdown/tooltip elevation.
- **Line height:** Never auto for multi-line body text.
  Formula: size × 1.4, round to nearest even number.
- **Focus ring:** Always 3px spread. Brand onPrimary for default, red for error.
  Focus border color = primary. Never a hover or visited color.
- **Contrast:** Check Token Contrast Table before shipping.
  mutedText on white must pass AA at large text only. Never for 13px body copy.

---

## Token Reference Frame (Canvas Page)

After Step 1 Token Foundation runs, a **Token Reference** frame must be built on the canvas.
This is a designer-facing reference — not a component. It lives on the Design System page.

**Every token category must appear in this frame — including text styles and shadows.**
If the frame is missing any of the sections below, it is incomplete.

### Frame Settings
```
Name:         "[Prefix] / Token Reference"
fill:         #F7F9FA (or surface token)
padding:      64px all sides
auto-layout:  vertical, gap 64px
width:        1400px, height: hug
Placement:    x: 0, y: [above first component set — e.g. y: -1200]
```

### Required Sections (build all 6 — in this order)

---

**SECTION 1 — Colors**
```
Section label: "COLORS" — SemiBold 11px, mutedText, 15% letter-spacing, UPPERCASE
Layout: horizontal auto-layout, wrap, gap 16px

For each color token, one swatch chip:
  Chip frame: 160px wide, hug height, auto-layout vertical, gap 8px, no fill, no border
    Swatch: 160×64px rectangle, fill = token color, radius = radius/md
    Token path: "[Prefix]/color/[path]" — Regular 11px, mutedText
    Hex value:  "#______" — SemiBold 12px, primary color

Group by category with a 1px divider + category label between groups:
  — Brand, Surface, Border, Disabled, Semantic
```

---

**SECTION 2 — Spacing**
```
Section label: "SPACING" — same label style as above
Layout: horizontal auto-layout, gap 16px, align bottom

For each spacing token, one scale bar:
  Token name: "spacing/xs" etc. — Regular 11px, mutedText
  Bar: width = token value (e.g. 4px wide for xs), height = 24px, fill = primary, radius = 2
  Value label: "4px" — SemiBold 12px, primary
```

---

**SECTION 3 — Radius**
```
Section label: "RADIUS"
Layout: horizontal auto-layout, gap 24px

For each radius token, one radius chip:
  Square: 64×64px rectangle, fill = surface, stroke = 1px defaultBorder
    corner radius = token value (e.g. 6px for radius/sm)
  Token name: "radius/sm" — Regular 11px, mutedText
  Value: "6px" — SemiBold 12px, primary
```

---

**SECTION 4 — Text Styles** ← required, was previously missing
```
Section label: "TEXT STYLES"
Layout: vertical auto-layout, gap 4px

For each text style, one row:
  Row: horizontal auto-layout, gap 24px, paddingV 8px, fill white on alternating rows
    Column 1 (320px): Live text node with that exact text style applied
      Content = style name, e.g. "Heading Bold 48"
    Column 2 (200px): Style name path — Regular 11px, mutedText
      e.g. "[Prefix]/Heading/Bold 48"
    Column 3 (120px): Specs — Regular 11px, mutedText
      e.g. "700 · 48px · auto"

Group with sub-labels: "Heading", "Body", "Label"
Sub-label style: SemiBold 11px, mutedText, 15% letter-spacing, UPPERCASE

Include all 18 text styles from the Text Styles Template.
```

---

**SECTION 5 — Shadows / Effects** ← required, was previously missing
```
Section label: "SHADOWS & EFFECTS"
Layout: horizontal auto-layout, wrap, gap 24px

For each effect style, one shadow chip:
  Chip frame: 200px wide, hug height, auto-layout vertical, gap 12px
    Card: 200×80px frame, fill = surface/elevated, radius = radius/lg
      Apply the effect style to this card via setEffectStyleId
    Style name: "[Prefix]/Shadow/sm" — Regular 11px, mutedText
    Values: "Y:1 Blur:2 rgba(0,0,0,.06)" — Regular 10px, mutedText

Group: General (sm → xl), Directional (nav, sidebar, inner), Interactive (button-hover, focus-ring, focus-error)
Separators between groups: 1px divider + group sub-label

For Interactive group chips — use colored fills to show the effect clearly:
  focus-ring: card fill = primary
  focus-error: card fill = errorBg (#fde8e8)
  button-hover: card fill = primary at 20% opacity
```

---

**SECTION 6 — Token Index (quick-ref table)**
```
Section label: "TOKEN INDEX"
Single scrollable table frame: width fill, hug height
  Header row: "Token" | "Value" | "Type" | "Used in"
  One row per token — sorted by category
  Row height: 40px, font: Regular 12px, #525252
  Alternate row fill: #F7F9FA / white
  Column widths: 320 | 160 | 80 | fill
```

---

### Prompt Instruction to Include in Step 1

Add this block to the Step 1 Token Foundation prompt, after the effect styles section:

```
TOKEN REFERENCE FRAME
After creating all variable collections, text styles, and effect styles, build
a Token Reference frame on the Design System page:

Frame name: "[Prefix] / Token Reference"
Width: 1400px. Height: hug. Padding: 64px. Auto-layout vertical, gap 64px.
Fill: [surface token]. Placed at x:0, y:-1200 (above component area).

Build 6 sections in order:
  1. COLORS — swatch chips grouped by: Brand, Surface, Border, Disabled, Semantic
     Each chip: 160px wide. Swatch 160×64px. Token path + hex value below.
  2. SPACING — horizontal scale bars, width = token value, aligned bottom
  3. RADIUS — 64×64px squares with corner radius bound to each token
  4. TEXT STYLES — one row per style. Three columns: live text | style path | specs (weight · size · lh)
     Group under sub-labels: Heading / Body / Label. Apply actual text style to the live text node.
  5. SHADOWS & EFFECTS — 200×80px cards with effect style applied via setEffectStyleId
     Group: General / Directional / Interactive. Show style name + values below each card.
  6. TOKEN INDEX — full table of all tokens: Token | Value | Type | Used in

Bind all fills, text styles, and effect styles to variables/styles — no raw values.
```

---

## Dark Mode Token Structure

### Approach: Figma Variable Modes

Figma supports dark mode via **variable Modes** inside the same collection.
Do not create a separate "Dark" collection — add a second Mode to the existing
Color collection.

```
Collection: [Prefix] / Color
  Mode 1: Light   ← all values you've already defined
  Mode 2: Dark    ← dark equivalents for every semantic role
```

**Which tokens need dark alternatives:**

| Token | Light | Dark |
|-------|-------|------|
| color/surface/default | #F7F9FA | #111827 |
| color/surface/elevated | #FFFFFF | #1F2937 |
| color/brand/primary | [brand] | [lighter brand or same] |
| color/brand/onPrimary | #FFFFFF | #FFFFFF |
| color/brand/mutedText | #6B7280 | #9CA3AF |
| color/border/default | #E2E4EA | #374151 |
| color/disabled/bg | #EEF0F2 | #1F2937 |
| color/disabled/text | #9CA3AF | #6B7280 |

**Tokens that typically stay the same in dark mode:**
- Semantic colors (successBg, errorBg, etc.) — may need slight adjustment for legibility
- Focus ring colors — keep the same formula, let primary variable handle the shift
- Shadow opacities — may need to increase (shadows are less visible on dark surfaces)

**How to instruct Claude Code:**
```
Add Mode "Dark" to collection "[Prefix] / Color".
For each variable, set the Dark mode value as specified.
Components reference variables — they automatically switch when the
Figma file mode is toggled. No component edits needed.
```

**If dark mode is not in scope for v1:**
Add this line to every component prompt:
`"Do not create dark-mode token collections or dark-themed variants."`
And note the decision in your Brand Config block.
