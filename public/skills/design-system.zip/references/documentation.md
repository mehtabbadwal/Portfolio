# Documentation & Accessibility Reference

## Documentation Frame Standard

Every component must have a Docs frame placed on the canvas directly below
its Showcase frame. Build it as part of the same Claude Code prompt.

**Frame settings:**
```
Name:         "[ComponentName] / Docs"
fill:         #FFFFFF
padding:      64px
auto-layout:  vertical, gap 48px
width:        1400px, height: hug
Placed at:    x=0, y=[showcase frame bottom + 80px]
```

**Required sections:**

```
SECTION 1 — Component Header
  Name: Open Sans Bold 24px, #292929
  Description: Open Sans Regular 14px, #525252, line-height 20px, max-width 640px

SECTION 2 — Variants Table
  Header: "Variants" — Open Sans Bold 16px, #292929
  Table (auto-layout vertical, gap 0):
    Header row: fill #F5F5F5, border-bottom 1px #E0E0E0
      Columns: "Variant" | "Use when" | "Fill" | "Border"
    Data rows: fill white, border-bottom 1px #E0E0E0
    All rows: paddingV 12px, HUG height

SECTION 3 — Sizes Table
  Columns: "Size" | "Height" | "Padding H" | "Use when"

SECTION 4 — States
  What triggers each state, visual change, any code note.
  Font: Open Sans Regular 14px, #525252, line-height 20px

SECTION 5 — Usage Rules
  Bullet list: 8px circle fill [primary], + rule text
  Font: Open Sans Regular 14px, #525252, line-height 20px

SECTION 6 — Accessibility Notes
  Contrast ratios, touch target sizes, ARIA requirements, focus ring spec.
```

---

## Component Documentation Frame (Documentation Page)

Every built component must have a documentation frame on the **"Documentation" page**.
Documentation is part of the definition of done.

**Frame:** 1200px wide. Height: hug. Background: `#fafafa`.
Sections alternate between `#ffffff` and `#fafafa`.
Internal padding: 48px top/bottom, 80px left/right.
Section dividers: 1px child frame (fill width) — NOT Figma strokes.
Section labels: Medium 500, 11px, mutedText, 15% letter-spacing, UPPERCASE.

**9-Section Layout:**

**SECTION 1 — HERO HEADER** (primary fill)
- StatusBadge + ComponentName (48px Bold, onPrimary) + ComponentDescription (18px Regular, onPrimary 80%)
- MetaRow: Category | Figma Node ID | Sizes | Since version

**SECTION 2 — OVERVIEW**
- Left: purpose and design intent (2–3 paragraphs, 16px Regular)
- Right (320px fixed): QuickRefCard with key specs

**SECTION 3 — ANATOMY**
- Left (560px): component mock with numbered callout circles (16px, primary fill, onPrimary text)
- Right: one card per part — name, description, optional boolean that controls it

**SECTION 4 — VARIANTS**
- One card per variant. CardHeader: name + description + usage badge.
- CardBody: preview + "When to use" bullets + token chips.

**SECTION 5 — SIZES & PLATFORM**
- Table: Size | Height | Platform | Touch Target | Preview
- Mobile sizes: primary fill platform tag. Desktop: surface fill + primary border.

**SECTION 6 — STATES**
- Grid of 320px state cards
- Each: preview area + state name + description + platform dots
- Order: default → hover → pressed → focus → disabled → loading

**SECTION 7 — USAGE GUIDELINES**
- 3 rows of do/don't pairs
- DoCard: success border 1.5px, 4px green top bar, "DO" in successText
- DontCard: error border 1.5px, 4px red top bar, "DON'T" in errorText

**SECTION 8 — ACCESSIBILITY**
- Left: 4 checklist items — touch target | focus ring | disabled | label clarity
- Right (360px): ContrastCard — WCAG ratios per color pair

**SECTION 9 — RELATED COMPONENTS**
- 2 "use instead" alternatives + 2 "often used alongside" companions

### Documentation Prompt Template

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DOCUMENTATION FRAME — [ComponentName]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Page: "Documentation" (create if it doesn't exist)
Placement: x: 0, y: [below last doc frame]
Frame name: "[ComponentName] — Documentation"
Frame width: 1200px. Height: hug.

Build 9 sections in order using the standard documentation template.
All component previews inside the doc are standalone mocks —
do NOT use component instances from the Design System page.
All section dividers are 1px child frames (fill width), NOT Figma strokes.
```

### Documentation Color System

```
docBg:       #fafafa   ← page background, alternating sections
sectionBg:   #ffffff
heroBg:      [primary]
labelBg:     [surface]
doGreen:     #a8d5b5   ← Do card border
doText:      #1e7e34   ← Do label, checklist marks, AA badges
dontRed:     #f5aaaa   ← Don't card border
dontText:    #e53e3e   ← Don't label
sectionText: [mutedText]   ← 11px UPPER section labels
bodyText:    [primary]     ← headings and body text
```

---

## Accessibility & ARIA Standards

### ARIA Role Reference

| Component | role | Notes |
|-----------|------|-------|
| PillButton | `button` | Default `<button>` |
| ToolbarButton | `button` or `togglebutton` | `aria-pressed="true/false"` for selected |
| TextLink | `link` | Never `<button>` for navigation |
| InputField | `textbox` | Implicit on `<input type="text">` |
| Dropdown | `combobox` | With `aria-expanded`, `aria-haspopup="listbox"` |
| DropdownItem | `option` | Inside `role="listbox"` |
| Toast | `status` or `alert` | `status` = info/success, `alert` = error/warning |
| Modal | `dialog` | With `aria-modal="true"`, `aria-labelledby` |
| Checkbox | `checkbox` | `aria-checked="true/false/mixed"` |
| Radio | `radio` | Inside `role="radiogroup"` |
| Toggle/Control | `switch` | `aria-checked="true/false"` |
| Tab/Item | `tab` | Inside `role="tablist"`, with `aria-selected` |
| Tab/Bar | `tablist` | With `aria-label` |
| Nav/Sidebar | `navigation` | `aria-label="Main navigation"` |
| Nav/BottomBar | `navigation` | `aria-label="App navigation"` |
| Avatar | `img` | `alt` = user's name, or `alt=""` if decorative |
| ProgressBar | `progressbar` | With `aria-valuenow/min/max` |

### aria-label for Icon-Only Components — CRITICAL

When `showLabel=false`, the component has no visible text.
Every spec that supports `showLabel` must include:
```
When showLabel=false:
  → Component MUST receive aria-label prop in code
  → Prop name: ariaLabel (string, required when showLabel=false)
```

### aria-disabled vs disabled

| Attribute | Screen reader | Focusable |
|-----------|--------------|-----------|
| `disabled` | Skips element | No |
| `aria-disabled="true"` | Announces as disabled | **Yes** |

**Rule:** Use `aria-disabled="true"` on all disabled interactive components.
This keeps the element in focus order so keyboard users know it exists.

### aria-live for Dynamic Content

| Component | aria-live value |
|-----------|----------------|
| Toast/success, info | `polite` |
| Toast/error, warning | `assertive` |
| Loading states | `polite` |
| Error messages | `polite` |

### Focus Management

- **Modal open:** Move focus to first interactive element or close button
- **Modal close:** Return focus to the trigger element
- **Dropdown close:** Return focus to the trigger button
- **Error on submit:** Move focus to the first error field

### Keyboard Navigation Requirements

| Component | Required keyboard behavior |
|-----------|--------------------------|
| PillButton | Enter/Space to activate |
| ToolbarButton | Enter/Space to toggle. Arrow keys if grouped |
| TextLink | Enter to follow link |
| Dropdown | Enter/Space to open. Arrow keys to navigate. Escape to close |
| Modal | Escape to close. Tab/Shift+Tab focus trap |
| Tab/Bar | Arrow keys between tabs. Tab to exit |
| Toast | Escape to dismiss |
| Checkbox/Radio | Space to select. Arrow keys within group |

### Color-Only State Rule (WCAG 1.4.1)

Never rely on color alone to communicate state:

| State | Non-color indicator |
|-------|-------------------|
| Active tab | 2px bottom border indicator |
| Selected nav item | Fill change + bold weight or accent bar |
| Active bottom nav | Dot below icon |
| Error input | Error icon (TrailingIcon) + helper text |
| Focus | 3px ring shape |

---

## Motion & Animation Tokens

All motion from these tokens only. No ad-hoc durations or easings.

### Duration Tokens
```
duration/instant   0ms     — no transition
duration/fast      100ms   — checkbox, toggle snap, button press
duration/normal    200ms   — hover, focus ring, dropdown open
duration/slow      300ms   — modal enter, drawer slide
duration/slower    500ms   — empty state, onboarding reveals
```

### Easing Tokens
```
easing/linear        linear
easing/standard      cubic-bezier(0.2, 0, 0, 1)
easing/decelerate    cubic-bezier(0, 0, 0.2, 1)    — elements entering screen
easing/accelerate    cubic-bezier(0.4, 0, 1, 1)    — elements leaving screen
easing/spring        cubic-bezier(0.34, 1.56, 0.64, 1)  — playful bounces
```

### Component Motion Reference

| Component | Property | Duration | Easing |
|-----------|----------|----------|--------|
| PillButton | background, shadow | fast | standard |
| PillButton | scale (pressed) | fast | standard — 1.0 → 0.97 |
| ToolbarButton | background | fast | standard |
| InputField | border, shadow (focus) | normal | standard |
| Dropdown | opacity + translateY | normal | decelerate |
| Toast | opacity + translateY | normal | spring |
| Toast (exit) | opacity | fast | accelerate |
| Modal (overlay) | opacity | normal | standard |
| Modal (panel) | opacity + scale 0.96→1 | normal | decelerate |
| Nav/Sidebar | width (collapse) | slow | standard |
| Toggle/Control | thumb translateX | fast | spring |

### Reduced Motion — CRITICAL

Always respect `prefers-reduced-motion: reduce`:
```css
@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```

Mark motion-bearing components in specs as:
`[MOTION] — requires prefers-reduced-motion handling`
