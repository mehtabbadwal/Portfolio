# Component Node ID Ledger

> ⚠️ **Starting a new product?** Clear this entire ledger before you begin.
> Every node ID is Figma-file-specific. IDs from one product will silently be
> wrong in another file. Wipe all values back to `[node ID]`, update the
> Product and File Key fields below, then populate as you build.

```
Product:    [your product name — fill in fresh each session]
File key:   [fill in — from Figma URL]
Page:       [fill in — e.g. "Design System"]
```

---

**How to use:** After each component is built and confirmed, run
`get_metadata(fileKey, nodeId)` or `get_design_context` on the component set
to retrieve its node ID, then record it here.

**A populated ledger makes correction prompts faster — you won't need a
metadata lookup before every fix. Populate as you build.**

```
─── BUTTONS & LINKS ────────────────────────────────────────
PillButton:      [node ID]
ToolbarButton:   [node ID]
TextLink:        [node ID]

─── FORM COMPONENTS ────────────────────────────────────────
InputField:      [node ID]
TextArea:        [node ID]
Dropdown:        [node ID]
DropdownItem:    [node ID]
SearchBar:       [node ID]

─── NAVIGATION ─────────────────────────────────────────────
PageHeader:      [node ID]
Breadcrumb/Item: [node ID]
Breadcrumb:      [node ID]
Nav/Item:        [node ID]
Nav/BottomBar:   [node ID]
Nav/Sidebar/Item: [node ID]
Nav/Sidebar:     [node ID]

─── CONTENT & DISPLAY ──────────────────────────────────────
Card:            [node ID]
Tag:             [node ID]
Toast:           [node ID]
Avatar:          [node ID]
EmptyState:      [node ID]

─── OVERLAYS ───────────────────────────────────────────────
Modal/Panel:     [node ID]
Modal:           [node ID]

─── DATA INPUT ─────────────────────────────────────────────
Checkbox/Control: [node ID]
Checkbox/Item:    [node ID]
Radio/Control:    [node ID]
Radio/Item:       [node ID]
Toggle/Control:   [node ID]

─── PROGRESS & WORKFLOW ────────────────────────────────────
ProgressBar:      [node ID]
Stepper:          [node ID]

─── LAYOUT ─────────────────────────────────────────────────
Tab/Item:         [node ID]
Tab/Bar:          [node ID]
Toolbar:          [node ID]

─── ICONS ──────────────────────────────────────────────────
Icon component set: [node ID]
  Naming: name=bell, size=12 | name=bell, size=16 | name=bell, size=24
  Sizes: 12px | 16px | 24px
  Source: [icon library name — pick one and use exclusively]
```

---

## Placement Tracker

**Next new component:** x: [last x + 1500], y: 100

Track your current canvas position here as you build. Increment x by ~1500
per new component set to prevent overlap.

```
Last placed:   [component name]
Last x:        [value]
Next x:        [value + 1500]
```
