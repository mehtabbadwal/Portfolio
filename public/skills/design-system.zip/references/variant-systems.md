# Variant Systems Reference

---

## ⚠️ CRITICAL RULE — Variant vs Text Property vs Boolean Property

Before adding a new variant, ask: **what is actually different?**

```
IF the only difference is text content (title, label, description, placeholder)
→ Use a TEXT PROPERTY — not a variant

IF the only difference is whether an element is shown or hidden
→ Use a BOOLEAN PROPERTY — not a variant

IF there is a meaningfully different VISUAL TREATMENT (color, shape, shadow,
  layout, completely different structure)
→ Use a VARIANT
```

### The test

> "If I duplicated the default variant and just changed the copy/toggle,
> would it look exactly right?"

- YES → text property or boolean, not a variant
- NO  → variant

### Common mistakes caught by this rule

| Wrong — creates redundant variants | Right — uses properties |
|-------------------------------------|------------------------|
| EmptyState/no-results, EmptyState/no-tasks, EmptyState/first-use | EmptyState with `title` and `description` text props |
| Toast/error-message-1, Toast/error-message-2 | Toast with `message` text prop |
| Button/save, Button/submit, Button/add-item | Button with `label` text prop |
| Modal/confirm-delete, Modal/confirm-archive | Modal with `title`, `body`, `confirmLabel` text props |
| Card/with-title, Card/without-title | Card with `showTitle` boolean prop |
| Nav/item-active-home, Nav/item-active-tasks | Nav with `activeItem` variant + `label` text prop |

### When content-type differences ARE genuine variants

Some components have types that differ visually, not just textually:
- `Toast type=error` vs `type=success` → **variant** (different bg/border/icon colors)
- `EmptyState type=error` vs `type=default` → **variant** (error uses red tokens)
- `Tag type=status-success` vs `type=status-warning` → **variant** (different semantic colors)
- `Button variant=primary` vs `variant=danger` → **variant** (different fills)

The signal: if swapping types requires a token change anywhere in the component,
it's a variant. If it's purely copy, it's a text property.

### How to add text properties programmatically (use_figma / MCP)

```javascript
// After creating a component, add text properties via the API:
comp.componentPropertyDefinitions = {
  title: {
    type: 'TEXT',
    defaultValue: 'No results found',
  },
  description: {
    type: 'TEXT',
    defaultValue: 'Try adjusting your search or filters.',
  },
  primaryLabel: {
    type: 'TEXT',
    defaultValue: 'Clear filters',
  },
};

// Then bind text nodes to those properties:
titleTextNode.componentPropertyReferences = { characters: 'title#<id>' };
// Note: the property ID is returned when setting componentPropertyDefinitions
// Always read the returned definition IDs before binding nodes

// Correct pattern:
const defs = comp.addComponentProperty('title', 'TEXT', 'Default title');
// defs returns { title: 'title#<generatedId>' }
// Then bind: textNode.componentPropertyReferences = { characters: defs['title'] }
```

### Text property naming convention

```
title          → primary heading text
description    → secondary/body text
label          → button or control label (when single label)
primaryLabel   → primary CTA button label
secondaryLabel → secondary CTA button label
placeholder    → input placeholder text
helperText     → hint text below inputs
errorText      → error message text
```

### When to use INSTANCE_SWAP instead of variants

A third option beyond variant and text property. Use when:

> "The nested element changes type (colour, structure, or content), but
>  the PARENT component's own fill/border/shadow never changes."

**The test:**
- Variant → parent component tokens change (fill, border, shadow)
- Text prop → only copy changes inside the same visual treatment
- Instance swap → a nested element needs to be swapped for a different component variant

**Classic example — ActionInfoBar:**
```
WRONG:  type=default | type=warning | type=success | type=error | type=info
        (10 variants — only the StatusTag changes, parent component is identical)

RIGHT:  2 variants (state=collapsed | state=expanded)
        + INSTANCE_SWAP property: statusTag → default Tag component variant
        Designer swaps tag to status-neutral / status-warning / status-success etc.
```

**How to add programmatically:**
```javascript
// On the ComponentSet (not individual variants):
const swapKey = set.addComponentProperty(
  'statusTag',       // prop name
  'INSTANCE_SWAP',   // type
  defaultVariant.id  // default = ID of the default component variant
);

// Bind to the instance inside each variant:
instance.componentPropertyReferences = { mainComponent: swapKey };
```

**Naming convention for swap props:**
```
statusTag      → for status/type indicator swaps
leadingIcon    → for leading icon instance swaps
trailingIcon   → for trailing icon instance swaps
avatar         → for avatar swaps
illustration   → for illustration/icon swaps in empty states
```

---

### How to structure components for text-property-first design

1. Build ONE base variant per visual treatment
2. Expose ALL variable copy as text properties
3. Use boolean properties for optional elements (showDescription, showCTA, showIcon)
4. Only create additional variants when visual tokens actually change

Example: EmptyState
```
Variants:    size=md/lg × type=default/error  →  4 variants total
Text props:  title, description, primaryLabel, secondaryLabel
Boolean props: showPrimaryCTA, showSecondaryCTA, showIcon
```

NOT:
```
Variants:   type=no-content/no-results/no-tasks/first-use/error  →  10 variants
(wrong — the first 4 only differ in copy)
```

---

## Action Buttons (PillButton / RectButton)

**⚠️ ALWAYS ASK before building any button component:**
> "What shape do you want for the button corners?"

Options:
- **Pill** — fully rounded ends (radius: 9999px)
- **Rounded** — radius/lg = 12px
- **Soft square** — radius/md = 8px
- **Square** — 0px (hardcoded — no token)

Variants: `primary` | `secondary` | `ghost` | `danger`

| Variant | Fill | Border | Text |
|---------|------|--------|------|
| primary | primary | none | onPrimary |
| secondary | none | primary 1.5px | primary |
| ghost | none | none | primary |
| danger | errorText | none | onPrimary |

**Hover:** primary → primaryHover + `[Prefix]/Shadow/button-hover`
**Danger hover:** darken 8% + `[Prefix]/Shadow/button-hover` (danger RGB)
**Pressed:** primary → primaryDeep, remove all shadows
**Focus (desktop/sm only):** border 1.5px primary + `[Prefix]/Shadow/focus-ring`
**Danger focus:** border 1.5px errorBorder + `[Prefix]/Shadow/focus-error`
**Disabled:** all variants → disabled tokens, remove all shadows
**Loading:** same fill as default, remove hover shadow if present

**Figma Component Properties — PillButton:**
```
variant          → Variant property     ["primary", "secondary", "ghost", "danger"]
size             → Variant property     ["xl", "lg", "md", "sm"]
state            → Variant property     ["default", "hover", "pressed", "focus", "disabled", "loading"]
showLeadingIcon  → Boolean property     default: true   — instance swap slot: Icon
showTrailingIcon → Boolean property     default: false  — instance swap slot: Icon
showLabel        → Boolean property     default: true
label            → Text property        default: "Label"
```

---

## Toggle/Toolbar Controls (ToolbarButton)

Variants: `filled` | `outline` | `ghost`
Border radius: 8px (radius/md) — NOT 10px. 10px is off the 4px grid.

| State | filled | outline | ghost |
|-------|--------|---------|-------|
| default | surface fill | no fill, defaultBorder | no fill, mutedText |
| hover | surface tinted | surface fill, primary border | surface fill |
| selected | primary fill, onPrimary text | primary fill, onPrimary text | surface fill + 2px primary left accent bar |
| focus | surface fill, primary border + focusRing | primary border + focusRing | surface fill, primary border + focusRing |
| disabled | disabledBg | disabledBorder, disabledText | disabledText |

Ghost selected uses a **2px primary left accent bar** (full height, left edge) — no fill.

**Figma Component Properties — ToolbarButton:**
```
variant          → Variant property     ["filled", "outline", "ghost"]
size             → Variant property     ["xl", "lg", "md", "sm"]
state            → Variant property     ["default", "hover", "selected", "focus", "disabled"]
showLeadingIcon  → Boolean property     default: true
showLabel        → Boolean property     default: true
label            → Text property        default: "Label"
```

---

## Navigation (TextLink)

Variants: `primary` | `subtle` | `inverse`
No fill on the component frame ever. Underline hidden by default, visible on hover.

| Variant | default text | hover | visited | disabled |
|---------|-------------|-------|---------|----------|
| primary | primary | primary + underline | mutedText | disabledText |
| subtle | mutedText | primary + underline | disabledText (lighter) | disabledText |
| inverse | onPrimary | onPrimary + underline | onPrimaryMuted | disabledText |

**Frame heights for touch target:**
- lg (16px font): frameHeight 44px, paddingV 10
- md (14px font): frameHeight 36px, paddingV 8
- sm (12px font): frameHeight 28px, paddingV 5

**Figma Component Properties — TextLink:**
```
variant          → Variant property     ["primary", "subtle", "inverse"]
size             → Variant property     ["lg", "md", "sm"]
state            → Variant property     ["default", "hover", "visited", "focus", "disabled"]
showLeadingIcon  → Boolean property     default: false
showTrailingIcon → Boolean property     default: false
label            → Text property        default: "Link text"
```

---

## Inputs / Form Fields

Structure:
```
1. LabelText         — optional, show[Label] boolean
2. Input frame       — horizontal auto-layout, height per size system
   a. LeadingIcon    — optional, show[LeadingIcon] boolean
   b. InputText      — placeholder or value text, width: fill
   c. TrailingIcon   — optional, show[TrailingIcon] boolean (clear, show/hide pw)
3. HintText          — optional, show[HintText] boolean
   — default: mutedText; error state: errorText token
```

Border treatment:
- default/empty: defaultBorder 1px
- focused: primary 1.5px + focusRing shadow
- error: errorBorder 1.5px + focusRingError shadow
- disabled: disabledBorder, disabledBg fill, disabledText

---

## SelectDropdown / ComboBox

The SelectDropdown is a two-part component: a **trigger** (looks like an InputField) and a
**menu panel** (list of DropdownItems that appears on click).

### Trigger frame
Identical structure to InputField except:
- TrailingIcon is always a **chevron-down icon** (required, not optional)
- `showTrailingIcon` is always true and locked (not a boolean prop)
- Clicking the trigger opens the menu — no text entry in basic Select
- For ComboBox (searchable): allow text entry in the trigger, add clear-X trailing icon

### States on trigger
`default` | `open` | `filled` | `error` | `disabled`
- `open` state: border = primary 1.5px + focusRing shadow (same as focused input)
- Chevron rotates 180° in open state (CSS transform — note in spec, implement in code)

### Menu panel (DropdownMenu)
Separate component, overlaid below trigger:

```
Frame: vertical auto-layout
  width: match trigger width (min-width: 200px)
  max-height: 320px (scrollable beyond this)
  fill: color/surface/elevated
  border: 1px color/border/default
  radius: radius/lg (12px)
  shadow: apply effect style [Prefix]/Shadow/md
  padding: spacing/sm (8px) top and bottom, 0 horizontal
Contents: one DropdownItem per option
```

### DropdownItem (atom component)
```
Frame: horizontal auto-layout, height HUG
  paddingV: spacing/sm (8px)
  paddingH: spacing/lg (16px)
  gap: spacing/sm (8px)
  width: fill
  radius: radius/md (8px) — applied inside the menu's padded container

States: default | hover | selected | disabled
  default:  fill none, text: color/brand/primary
  hover:    fill color/surface/default, text: color/brand/primary
  selected: fill color/brand/primary (8% tint), text: color/brand/primary
            + checkmark TrailingIcon in primary color
  disabled: fill none, text: color/disabled/text — no opacity

Children: LeadingIcon (optional, showLeadingIcon boolean) | Label (fill width) | TrailingIcon (checkmark when selected)
```

### Figma Component Properties — SelectDropdown trigger
```
state          → Variant property   ["default", "open", "filled", "error", "disabled"]
size           → Variant property   ["xl", "lg", "md", "sm"]
showLabel      → Boolean property   default: true
showHintText   → Boolean property   default: false
label          → Text property      default: "Label"
placeholder    → Text property      default: "Select an option"
selectedValue  → Text property      default: "" (shown when state=filled)
hintText       → Text property      default: "Hint text"
```

### Key prompt notes
- Build trigger and DropdownMenu as **separate component sets** — do not nest
- Trigger references DropdownMenu via overlay positioning in code (not in Figma)
- Shadow on menu panel: always `[Prefix]/Shadow/md` — never higher elevation
- Clip content: OFF on trigger frame (focus ring visibility)

---

## Tags / Badges / Chips

Sizes: md (24px height) and sm (20px height).
States: `default` | `hover` (if interactive) | `selected` | `disabled`
Semantic variants: `default` | `success` | `warning` | `error` | `info`
Visual weight: `filled` | `outline` | `subtle`

Apply `show[X]` booleans for: leading icon, trailing dismiss icon, count badge.

**Note:** Semantic meaning and visual weight are two separate props, not nested variants.
```
semantic  → Variant property  ["default", "success", "warning", "error", "info"]
visual    → Variant property  ["filled", "outline", "subtle"]
```

**Hover state visual treatment (interactive tags only):**
- `filled` hover: darken background by 8%, stay within the semantic color family
- `outline` hover: apply a light semantic fill behind the existing border
- `subtle` hover: slightly increase background opacity
- If the tag is purely display-only (no click/dismiss action): omit hover state

---

## Cards

- Variants: `default` | `elevated` | `outlined` | `flat`
- States: `default` | `hover` (if clickable) | `selected` | `disabled`
- Props: `showHeader` | `showFooter` | `showMedia` | `showDivider`
- Width: fixed in context. Height: hug (content-driven).

---

## Avatars

Sizes: xl (48px) | lg (40px) | md (32px) | sm (24px) | xs (16px)
Variants: `image` | `initials` | `icon` | `placeholder`
Shapes: `circle` (default) | `rounded` (for workspace/org avatars)

---

## Modals / Drawers

Structure:
```
1. Overlay backdrop  — semi-transparent fill, full-bleed
2. Modal frame       — vertical auto-layout, fixed width, hug height
   a. Header         — title + optional close button
   b. Content slot   — flexible
   c. Footer         — optional, show[Footer] boolean
```
Sizes: `sm` (400px) | `md` (560px) | `lg` (720px) | `fullscreen`
Drawers: `right` | `left` | `bottom`; widths 360px / 480px / 640px

---

## Tooltips / Popovers

- Tooltip: text-only, no interaction, on hover. 8 position variants.
- Popover: interactive content, on click. Same 8 positions.
- Include an `anchor` arrow/caret pointing to trigger.
- Max-width: 240px tooltip, 320px popover.

---

## Navigation / Tabs

States per item: `default` | `hover` | `active` | `disabled`
Active indicator: 2px bottom border (horizontal tabs) or left border (vertical tabs).
`show[Icon]` and `show[Badge]` boolean props on each tab item.

---

## Empty States

Structure:
```
1. Illustration slot  — show[Illustration] boolean
2. Title             — [Prefix]/Heading/Bold 16
3. Description       — Regular 14px, mutedText
4. CTAButton         — show[CTA] boolean, links to PillButton component
```

---

## Navigation System

**Mobile:** Nav/Item atom + Nav/BottomBar composite
- Bottom tab pattern — 5 destinations max
- Active: primary icon + primary text + 4px primary dot (non-color indicator for WCAG 1.4.1)
- Inactive: mutedText icon + text
- Touch target: 48×32px minimum per item
- Background: navBg token

**Desktop:** Nav/Sidebar/Item atom + Nav/Sidebar composite
- Expanded: 240px | Collapsed: 64px (showLabel=false on all items)
- Active: primary fill row + onPrimary icon + onPrimary text
- Right border: 1px child frame (NOT Figma stroke)

---

## Naming Convention

```
ComponentName/size/variant/state

PillButton/xl/primary/default
PillButton/lg/secondary/disabled
PillButton/md/ghost/hover
PillButton/sm/primary/focus

ToolbarButton/xl/filled/default
ToolbarButton/md/outline/selected
ToolbarButton/sm/ghost/focus

TextLink/lg/primary/default
TextLink/md/subtle/hover
TextLink/sm/inverse/visited
```

---

## Layer Structure Template

Every button/link component follows this child order inside horizontal auto-layout:

```
1. LeadingIcon   — placeholder rectangle at icon size
                   Controlled by showLeadingIcon boolean
                   Instance swap slot: Icon component
                   In loading state: replace with Spinner
2. Label         — text node, [Brand Font], size per token
                   Width: FILL (pushes button wider — never hug)
                   Controlled by showLabel boolean
3. TrailingIcon  — placeholder rectangle at icon size
                   Controlled by showTrailingIcon boolean
                   Hidden in loading state
```

Auto-layout settings: horizontal, center-aligned, clip content **OFF**.
Gap and padding from size token table.
