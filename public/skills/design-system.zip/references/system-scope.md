# System Scope & Correction Reference

## System Scope & Roadmap

Explicit stances on out-of-scope features. Unstated scope creates ambiguity.

### Dark Mode
- Option A: "Not in v1. All tokens are light-mode. No dark aliases."
- Option B: "Supported. Use semantic token aliases."

If not supported, include in every prompt:
"Do not create dark-mode token collections or dark-themed variants."

### RTL Support
Use direction-agnostic naming now, even if RTL is not in v1:
- ✅ `showLeadingIcon` / `showTrailingIcon`
- ❌ `showLeftIcon` / `showRightIcon`

### Density Modes
Platform density is handled by the 4-size system. User-togglable density within one platform
requires a separate density token layer — only add when explicitly required.

### Skeleton / Loading States for Content Components
- Use disabledBg token as skeleton fill
- Animate: left→right shimmer, 1.5s loop, easing/linear
- `prefers-reduced-motion`: static fill, no animation
- Skeleton as separate component: `Card/skeleton`, `Avatar/skeleton`
- Never use real components at reduced opacity for skeletons

### Breakpoints (Reference)
```
mobile:    < 768px   → xl/lg sizes, 48px touch targets
tablet:    768–1024px → md sizes
desktop:   > 1024px  → sm sizes
```

### Column Grid (Reference)
| Breakpoint | Columns | Gutter | Margin |
|------------|---------|--------|--------|
| mobile | 4 | 16px | 16px |
| tablet | 8 | 24px | 24px |
| desktop | 12 | 24px | 32px |

---

## Icon System

**3 sizes only:**
- `size=12` — inline text, tags, compact components, badge icons
- `size=16` — standard UI: buttons, inputs, nav, section headers (80% of usage)
- `size=24` — mobile nav bar, empty state icons

**Choosing your icon library — pick one, use it exclusively:**

| Library | Style | Best for |
|---------|-------|----------|
| Lucide | Thin strokes, modern | SaaS, productivity, developer tools |
| Heroicons | Clean, balanced weight | General purpose, balanced UIs |
| Phosphor | Multiple weights available | Flexible — matches any brand density |
| Material Symbols | Variable weight | Enterprise, Google ecosystem |

Never mix icon libraries. Once chosen, record it in node-ids.md and use it for every icon.

**Figma component structure — Icon component set:**
```
Component set name: Icon
Component properties:
  name   → Variant property  [list all icon names: "bell", "search", "plus", "x", etc.]
  size   → Variant property  ["12", "16", "24"]

Per variant:
  Frame: square (size × size px), centered auto-layout
  Fill: color/brand/primary — bind via setBoundVariable
  Vector: optically scaled to fill frame (no baked-in padding)
```

**Naming rule:** `name=[iconName], size=[12|16|24]`

**Adding a new icon:**
1. Find icon in chosen library → copy SVG
2. Paste in Figma → arrives at source size (usually 24×24)
3. For `size=24`: use as-is, frame = 24×24
4. For `size=16`: resize frame to 16×16, scale vector to ~13-14px visual weight
5. For `size=12`: resize to 12×12, scale vector to ~10-11px visual weight
6. Set fill to `color/brand/primary` (bind via setBoundVariable)
7. Add to Icon component set, naming: `name=[iconName], size=[size]`
8. Record the Icon component set node ID in node-ids.md

**Instance swap in components:**
When a component has an icon slot, set it up in prompts as:
`"LeadingIcon: [size]px square placeholder, primary fill, instance swap → Icon component set"`

---

## Correction Prompts

### Correction vs. Re-run — Know Which to Use

**Use a correction prompt when:**
- A single property is wrong (wrong color, wrong padding value, wrong shadow)
- One state is broken but others look correct
- A binding is missing (raw hex instead of variable)
- Heights drifted on specific sizes

**Re-run the full component prompt when:**
- Layer structure is wrong (children in wrong order, missing layers)
- Auto-layout direction or alignment is wrong
- Component properties panel is missing or wired incorrectly
- Multiple interconnected things are broken — correction prompts stack faster than a re-run

**Rule of thumb:** if you need more than 3 correction prompts on the same component, re-run.

---

When the agent builds something wrong, write a **correction-only prompt** that:

1. **Look up the component's node ID** in `references/node-ids.md` before writing.
   If the ledger is empty for this component, run `get_metadata(fileKey, nodeId)` first.
2. Opens with: `"DO NOT create any new frames or components. Only fix what is specified below."`
3. References exact node IDs from Figma metadata
4. Specifies only the property to change
5. Ends with: `"Touch only the properties explicitly listed above. Do not move, resize, or recolor anything else."`

### Common Errors to Watch For

- **Heights shrink** — agents commonly reduce heights. Always verify:
  xl: 48px, lg: 44px, md: 40px, sm: 32px. Add "DO NOT alter this height."
- **Inverse fills** — agent may put primary fill ON the component frame
  instead of behind it (as a canvas swatch)
- **Font weight on links** — links default to Bold. Always assert Regular (400) explicitly.
- **Loading state** — agent may forget to hide TrailingIcon and replace LeadingIcon with spinner
- **Clip content ON** — clip content must be OFF on all interactive frames (hides focus ring)
- **Label width HUG** — label node inside button must be width: fill, not hug
- **Disabled color** — never switch to gray if the system uses brand-tinted disabled tokens.
  WCAG 1.4.3 exempts disabled controls.
- **Opacity for disabled** — NEVER. Always apply tokens directly to each layer.
- **Focus ring color wrong** — focus border = primary. Not a hover color, not a visited color.
- **Border radius 10px** — off the 4px grid. Use 8px (radius/md) or 12px (radius/lg).
- **showLeftIcon / showRightIcon naming** — always use showLeadingIcon / showTrailingIcon.
- **spacing/lg-plus** — deprecated. Replacement is `spacing/20` (20px). Always use `spacing/20`.
- **Dividers as Figma strokes** — always build dividers as 1px child frames (fill width).
  Figma does not support directional borders via strokes.
- **Variables without Styles** — typography and shadows need both a Variable (dev reference)
  AND a Figma Style (designer-applied in Inspector). Variables alone don't appear in the panel.
- **Line height "auto" on body text** — auto is only safe for single-line elements.
  Multi-line body text must use explicit line heights.
- **Shadow opacity too high** — card-level shadows use 0.06–0.08. Never 0.12 for cards.
