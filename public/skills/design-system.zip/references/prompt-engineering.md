# Prompt Engineering Reference

## Showcase Layout in Component Set

### Component Set — Variant Grid (x/y coordinates) — CRITICAL

Figma component sets do NOT support auto-layout. Every variant must be given
**explicit x/y coordinates** or all variants will stack at x:0, y:0.

**Grid pattern:**
- **Columns (x-axis)** = one per state: default → hover → pressed → disabled → loading
- **Rows (y-axis)** = one per size (xl → lg → md → sm) within each variant group
- **Column width** = 180px
- **Row gap** = 20px between sizes within a group
- **Group gap** = 60px between variant groups (primary / secondary / ghost / danger)

**y-position formula:**
```
Row 1 (xl):  y = groupStartY + 0
Row 2 (lg):  y = groupStartY + 68    (48px height + 20px gap)
Row 3 (md):  y = groupStartY + 132   (68 + 44px height + 20px gap)
Row 4 (sm):  y = groupStartY + 192   (132 + 40px height + 20px gap)

Group gaps:
primary   starts y=0
secondary starts y=284   (192 + 32px height + 60px gap)
ghost     starts y=568
danger    starts y=852
```

**Always resize the component set frame after positioning variants.**

**Include this block in every component prompt:**
```
COMPONENT SET GRID LAYOUT
After creating all variants, position each one with explicit x/y coordinates.
DO NOT rely on auto-layout inside the component set.
Columns = states (x: 0, 180, 360, 540, 720...)
Rows = sizes within each variant group
Variant groups separated by 60px vertical gap.
After positioning, resize the component set frame to tightly wrap all children.
```

---

## ⚠️ Programmatic Grid Distribution (use_figma / MCP direct)

When building component sets via `figma.use_figma`, Figma places ALL variants
at x:0, y:0 by default — they stack on top of each other and are invisible.

**ALWAYS assign explicit x/y to every variant before calling
`figma.combineAsVariants()`.**

If you call `combineAsVariants` first then move variants, the positions are
relative to the component set origin — use the formula below.

### Universal grid formula

```javascript
// Run this BEFORE combineAsVariants, while variants are still page-level nodes
const COL_W   = 200;  // width per column (adjust to widest component + 40px gap)
const ROW_H   = 60;   // height per row (adjust to tallest component + 20px gap)
const COL_GAP = 40;   // gap between columns
const ROW_GAP = 20;   // gap between rows
const GROUP_GAP = 60; // extra gap between variant groups

// Columns = states: default, hover, pressed, focus, disabled, loading
// Rows = sizes within a group: xl, lg, md, sm
// Groups = variants: primary, secondary, ghost, danger

const states  = ['default', 'hover', 'pressed', 'focus', 'disabled', 'loading'];
const sizes   = ['xl', 'lg', 'md', 'sm'];
const groups  = ['primary', 'secondary', 'ghost', 'danger'];

let groupY = 0;
for (const group of groups) {
  for (let si = 0; si < sizes.length; si++) {
    for (let sti = 0; sti < states.length; sti++) {
      const variant = findVariant(group, sizes[si], states[sti]); // your lookup fn
      if (!variant) continue;
      variant.x = sti * (COL_W + COL_GAP);
      variant.y = groupY + si * (ROW_H + ROW_GAP);
    }
  }
  groupY += sizes.length * (ROW_H + ROW_GAP) + GROUP_GAP;
}
```

### Simplified grid for 2-property component sets (type × state)

```javascript
// type = rows, state = columns
const types  = ['Goal', 'Actions', 'Collaborate']; // or your type list
const states = ['default', 'hover', 'selected', 'disabled'];
const COL_W  = 400;  // component width + 40px gap
const ROW_H  = 350;  // component height + 60px gap

for (const [ti, type] of types.entries()) {
  for (const [si, state] of states.entries()) {
    const variant = comps.find(c => c.name === `Type=${type}, state=${state}`);
    if (!variant) continue;
    variant.x = si * COL_W;
    variant.y = ti * ROW_H;
  }
}
```

### Grid for icon/atom sets (name × size)

```javascript
// Rows = icon names (A-Z), Columns = sizes (12, 16, 20, 24)
const SIZES   = [12, 16, 20, 24];
const CELL_W  = 48;   // cell width per column
const CELL_GAP= 16;   // gap between columns
const ROW_H   = 32;   // row height per icon name
const ROW_GAP = 0;    // gap between icon rows (0 = tight grid)
const CAT_GAP = 24;   // extra gap between category groups
const START_X = 20;
const START_Y = 20;

let currentY = START_Y;
for (const iconName of sortedIconNames) {
  for (let si = 0; si < SIZES.length; si++) {
    const variant = lookup[iconName]?.[SIZES[si]];
    if (!variant) continue;
    const iconSz  = SIZES[si];
    const colX    = START_X + si * (CELL_W + CELL_GAP);
    const offsetX = Math.floor((CELL_W - iconSz) / 2); // center in cell
    const offsetY = Math.floor((ROW_H  - iconSz) / 2);
    variant.x = colX + offsetX;
    variant.y = currentY + offsetY;
  }
  currentY += ROW_H + ROW_GAP;
}
```

### After positioning — always resize the set

```javascript
// After combineAsVariants, resize to fit content tightly
const maxX = Math.max(...set.children.map(c => c.x + c.width));
const maxY = Math.max(...set.children.map(c => c.y + c.height));
set.resize(maxX + 40, maxY + 40); // 40px padding on each trailing edge
```

### ⚠️ Component set position constraint

Figma component sets constrain variant positions to their bounding box. If you
set `variant.x = 460` but the set is only 455px wide, the position assignment
will be silently ignored and the set will keep all variants at x=0.

**Always resize the set to full target width BEFORE setting positions:**

```javascript
// 1. Resize FIRST to the full target dimensions
set.resize(typeOrder.length * COL_W + 80, sizeOrder.length * ROW_H + 80);

// 2. THEN set positions
for (const [ci, type] of typeOrder.entries()) {
  for (const [ri, size] of sizeOrder.entries()) {
    const v = lookup[size]?.[type];
    if (v) { v.x = ci * COL_W + 40; v.y = ri * ROW_H + 40; }
  }
}

// 3. Then resize again to fit actual content
const maxX = Math.max(...set.children.map(c => c.x + c.width));
const maxY = Math.max(...set.children.map(c => c.y + c.height));
set.resize(maxX + 40, maxY + 40);
```

**For purely vertical component sets** (single column, multiple rows), the
standard vertical stack is functionally correct — designers navigate via the
variant properties panel, not canvas position. Don't fight Figma's layout if
multi-column placement isn't working.

---

### Showcase Frame (canvas review)

Each component also gets a **Showcase** frame placed below the component set.
This is NOT a component — it's a canvas reference frame.

```
Frame name:   "[ComponentName] / Showcase"
fill:         #F5F5F5
padding:      64px all sides
auto-layout:  vertical, gap 64px
width:        1400px, height: hug
```

Inside, one **Variant Section** per variant (primary, secondary, etc.):
```
Section frame:
  name: "Section — [Variant]"
  auto-layout: vertical, gap 24px
  width: fill, height: hug, no fill/border

Contents:
  1. Section label: "[VARIANT]"
     Open Sans Bold 12px, color #525252, letter-spacing 0.8px, UPPERCASE

  2. Divider: 1px frame, width fill, fill #E0E0E0

  3. One Size Row per size (xl → lg → md → sm):
     Frame: horizontal auto-layout, gap 16px, align center, hug height, fill width
     5 instances: state=default | hover | pressed | disabled | loading

  4. State label row beneath each size row:
     5 text nodes: "Default" | "Hover" | "Pressed" | "Disabled" | "Loading"
     Open Sans Regular 11px, color #525252, gap 16px
```

---

## Variable & Style Binding — CRITICAL

**This is the most common failure mode in AI-generated Figma components.**

When Claude Code sets a color to `#1A6C7F`, Figma stores a raw hex value — not a
bound variable. Every color, text style, effect style, radius, and spacing value
set on any layer MUST be bound to its corresponding Figma variable or style.

### How to Instruct Binding

**For color fills:**
```
WRONG:  Set fill to #1A6C7F
RIGHT:  Set fill to variable [Prefix]/color/brand/primary
        (resolve variable ID from collection "[Prefix] / Color", bind via setBoundVariable)
```

**For text styles:**
```
WRONG:  Set font to Open Sans SemiBold 14px
RIGHT:  Apply text style [Prefix]/text/label/lg
        (resolve style ID, bind via setTextStyleId)
```

**For effect styles:**
```
WRONG:  Set shadow to 0 0 0 3px rgba(26,108,127,0.5)
RIGHT:  Apply effect style [Prefix]/Shadow/focus-ring
        (resolve style ID, bind via setEffectStyleId)
```

**For radius:**
```
WRONG:  Set corner radius to 12
RIGHT:  Set corner radius bound to variable [Prefix]/radius/lg
        (resolve variable ID, bind via setBoundVariable)
```

**For spacing:**
```
WRONG:  Set padding to 16
RIGHT:  Set padding bound to variable [Prefix]/spacing/lg
        (resolve variable ID, bind via setBoundVariable)
```

### Required Binding Block for Every Prompt

Include this block in EVERY component prompt after the design tokens section:

```
════════════════════════════════════════════════════════════
VARIABLE & STYLE BINDING RULES — NON-NEGOTIABLE
════════════════════════════════════════════════════════════
Every property listed below MUST be bound to a Figma variable or style.
Setting raw hex values, raw pixel numbers, or raw font sizes is NOT acceptable.

COLORS — use setBoundVariable with collection "[Prefix] / Color":
  All fills       → bind to [Prefix]/color/[path]
  All strokes     → bind to [Prefix]/color/[path]

TEXT — use setTextStyleId:
  All text nodes  → bind to [Prefix]/text/[scale]
  Never set font family, weight, size, or line-height manually

EFFECTS — use setEffectStyleId:
  All shadows     → bind to [Prefix]/Shadow/[tier]

RADIUS — use setBoundVariable with collection "[Prefix] / Radius":
  All corner radii → bind to [Prefix]/radius/[size]
  Exception: radius=0 (square) → set directly, no variable

SPACING — use setBoundVariable with collection "[Prefix] / Spacing":
  All padding and gap values → bind to [Prefix]/spacing/[size]

After building each variant, verify:
  - Fill Inspector shows "[Prefix]/color/..." not hex value
  - Text Inspector shows "[Prefix]/text/..." not raw font properties
  - Shadow Inspector shows "[Prefix]/Shadow/..." not raw values
  - Radius Inspector shows "[Prefix]/radius/..." not a raw number
════════════════════════════════════════════════════════════
```

### Binding Correction Prompt Template

When a component was built with raw values instead of bindings:

```
DO NOT create any new frames or components.

For every layer in [component name] (node ID: [id]), rebind all properties
to their corresponding Figma variables and styles:

FILLS — resolve from collection "[Prefix] / Color":
  [list each layer name → variable path]

TEXT STYLES — bind via setTextStyleId:
  [list each text node → style name]

EFFECT STYLES — bind via setEffectStyleId:
  [list each layer with shadow → style name]

RADIUS — resolve from collection "[Prefix] / Radius":
  [list each layer → variable path]

SPACING — resolve from collection "[Prefix] / Spacing":
  [list each layer → variable path]

Touch only the variable/style bindings.
Do not change any visual values, positions, sizes, or names.
```

---

## Prompt Structure

## Post-Build Validation Checklist

After Claude Code runs and the user shares a screenshot or description, work through
this list before calling the component done. Ask the user to verify each item.

```
AUTO-LAYOUT
[ ] Auto-layout direction correct (horizontal for buttons/inputs, vertical for forms)?
[ ] All children visible — no layers hidden accidentally?
[ ] Width: FILL on interactive component frames (not HUG)?
[ ] Width: FILL on Label text node inside buttons?
[ ] clip content: OFF on all interactive frames?

SIZING
[ ] Heights correct: xl=48px | lg=44px | md=40px | sm=32px?
    (inputs: xl=48 | lg=44 | md=40 | sm=36)
[ ] Heights are HUG-driven (padding-based), not fixed?
[ ] Padding values match size token table?

TOKENS & BINDING
[ ] Click any fill → Inspector shows "[Prefix]/color/..." not a hex value?
[ ] Click any text node → Inspector shows "[Prefix]/text/..." not raw font?
[ ] Click any shadow → Inspector shows "[Prefix]/Shadow/..." not raw rgba?
[ ] Click any corner radius → Inspector shows "[Prefix]/radius/..." not a number?

STATES
[ ] Hover state: filled buttons have button-hover shadow applied?
[ ] Focus state: 1.5px primary border + focus-ring shadow bound?
[ ] Disabled state: uses tokens directly — no opacity applied to frame?
[ ] Pressed state: shadows removed (not just set to 0)?

COMPONENT PROPERTIES
[ ] All variant properties present (variant, size, state)?
[ ] All boolean props present (showLeadingIcon, showTrailingIcon, showLabel)?
[ ] Text properties present (label, placeholder)?
[ ] Instance swap slots set up for Icon nodes?

COMPONENT SET
[ ] Variants positioned with explicit x/y — none stacked at 0,0?
[ ] Component set frame resized to wrap all children?
[ ] Naming follows convention: ComponentName/size/variant/state?
```

If anything fails → write a targeted correction prompt (see system-scope.md).

---

Every Claude Code + Figma MCP prompt follows this structure:

```
1. File key + page
2. SHARED DESIGN TOKENS block (full token list with hex + variable path)
3. VARIABLE & STYLE BINDING RULES block (always include — copy verbatim)
4. One ╔═══╗ section per component with:
   a. SIZES table (heights, paddingV, paddingH — specify height: HUG)
   b. State rationale (why each size gets its states)
   c. COMPONENT PROPS (variant, size, state, show[X] booleans, Figma property types)
   d. VARIANTS × STATES styles
      — Every color listed as: "bind to [Prefix]/color/[path]"
      — Every text listed as: "apply text style [Prefix]/text/[scale]"
      — Every shadow listed as: "apply effect style [Prefix]/Shadow/[tier]"
      — Every radius listed as: "bind to [Prefix]/radius/[size]"
   e. LAYER STRUCTURE (auto-layout direction, children in order, sizing modes)
   f. COMPONENT SET GRID LAYOUT (explicit x/y for every variant)
   g. SHOWCASE FRAME (canvas reference, named "[Component] / Showcase")
   h. DOCS FRAME (see documentation.md)
   i. NAMING CONVENTION examples
5. EXECUTION INSTRUCTIONS block (see below)
```

### Standard EXECUTION INSTRUCTIONS Block

Always include this at the end of every component prompt:

```
EXECUTION INSTRUCTIONS
- Build [Component A] fully before starting [Component B].
- Do not ask for clarification — build the full specification.
- If a step fails, log the error and continue with the next frame.
- Convert each set of frames into a Figma component set with
  component properties panel wired up as specified.
- clip content OFF on all interactive component frames.
- Label text node width: FILL inside all button auto-layouts.
- Height: HUG on all interactive component frames (never fixed height).
- After creating all variants, position each with explicit x/y coordinates.
- After positioning, resize the component set frame to wrap all children.
- BINDING: Every fill, stroke, radius, spacing, text style, and effect style
  MUST be bound to a Figma variable or style.
  Verify Inspector shows variable/style names, not hex codes.
- SHADOWS: Apply the correct effect style per the Shadow Assignment table.
    [ ] Hover state on filled buttons → [Prefix]/Shadow/button-hover bound
    [ ] Focus state on all interactive components → [Prefix]/Shadow/focus-ring bound
    [ ] Error focus state → [Prefix]/Shadow/focus-error bound
    [ ] Pressed state → shadows removed
    [ ] Disabled state → no shadows of any kind
    [ ] Cards, modals, dropdowns, toasts → correct elevation shadow bound
    [ ] Nav bars → directional shadow bound
- DOCS FRAME: After building the component and showcase, build the Documentation
  frame on the Documentation page. See documentation.md for the 9-section spec.
  Documentation is part of the definition of done — not optional.
```
