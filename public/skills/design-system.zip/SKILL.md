---
name: design-system
description: >
  Create, spec, audit, and generate Figma component prompts for any product design system.
  Use for any request involving UI components, design tokens, Figma variables, variant systems,
  component audits, UX pattern decisions, or design system consistency checks.
  Works with any product — provide a Figma link and brand config to activate.
  Covers all commerce models (B2B/B2C/C2C/D2C), platform guidelines (HIG/Material/Fluent),
  and domain contexts (Fintech/Healthcare/SaaS/Enterprise/AI/DevTools/Biotech/eComm).
  Always use this skill — do not attempt design system work without it.
---

# Design System Skill

## Triggers

Use this skill when the user says any of the following — or anything semantically similar:

**Component build/edit:** "create a component", "add a variant", "add a size", "build this component",
"fix the component", "rebuild this component", "the component looks wrong", "update the states"

**Figma operations:** "Figma prompt", "write a Claude Code prompt", "run this in Figma",
"update the design system", "add to Figma", "create a component set"

**Audit/review:** "review my component", "audit the system", "check this component",
"is this consistent", "what's wrong with", "why does this look off"

**UX decisions:** "should I use X or Y", "what's the right pattern for", "modal or drawer",
"tabs or accordion", "how should this flow", "what component fits here"

**Domain/platform:** "B2B design", "B2C pattern", "HIG", "Material Design", "Fluent",
"fintech UX", "healthcare design", "SaaS patterns", "AI product design",
"developer tools UX", "enterprise UX", "ecommerce patterns"

**Any UI element by name:** buttons, inputs, cards, modals, navigation, tags, avatars,
tooltips, forms, dropdowns, checkboxes, toggles, tables, popovers, drawers, toasts,
skeletons, pagination, banners, progress bars, steppers, tabs, breadcrumbs, icons

## Changelog

| Date | Change |
|------|--------|
| 2026-03-29 | Made skill fully product-agnostic — removed all Buildrooms assumptions, session-start now driven by Figma link, brand config always starts blank, added Product Agnosticism principle section |
| 2026-03-29 | Added domain-context.md — commerce models (B2B/B2C/C2C/D2C/B2G/C2G/Social Commerce), Platform guidelines (HIG/Material 3/Fluent 2), Domain guidelines (Fintech/Healthcare/SaaS/eComm/Enterprise/AI-ML/DevTools/Biotech) |
| 2026-03-29 | Added INSTANCE_SWAP pattern to variant-systems.md — when nested element type changes but parent tokens don't |
| 2026-03-29 | Added icon container AL rules to component-anatomy.md — all icon frames must be HORIZONTAL AL |
| 2026-03-29 | Added divider AL rules to component-anatomy.md — all divider frames must be HORIZONTAL/VERTICAL AL |
| 2026-03-29 | Added programmatic grid distribution rules to prompt-engineering.md including component set position constraint |
| 2026-03-29 | Added programmatic build sizing rules (AUTO=hug, FIXED=fixed) to component-anatomy.md |
| 2026-03-29 | Added critical variant vs text property vs instance swap rule at top of variant-systems.md |
| 2026-03-24 | Added session-start product context confirmation rule |
| 2026-03-24 | Added multi-product switching procedure |
| 2026-03-24 | Expanded UX Decision Support (form layout, nav architecture, empty/loading/skeleton states, icon strategy, FAB vs toolbar) |
| 2026-03-24 | Added MCP failure recovery paths to Workflow |
| 2026-03-24 | Strengthened frontmatter description to trigger on audit/review requests |

This skill guides creation of component specs and Claude Code + Figma MCP prompts for
any product's design system. Every component prompt you write will be run in Claude Code
with the Figma MCP.

**Reference files** — load these as needed during your work:
- `references/tokens.md` → design tokens, Figma variables, text/effect styles, line heights, token audit
- `references/component-anatomy.md` → auto-layout rules, sizing contract, icon containers, dividers, platform best practices, shadow assignment
- `references/variant-systems.md` → variant vs text prop vs instance swap decision, variant tables per component type, naming convention, layer structure
- `references/prompt-engineering.md` → showcase layout, programmatic grid distribution, variable binding, prompt structure, execution instructions
- `references/documentation.md` → docs frame spec, accessibility/ARIA, motion tokens
- `references/system-scope.md` → scope decisions, icon system, correction prompts + common errors
- `references/node-ids.md` → component node ID ledger and canvas placement tracker
- `references/domain-context.md` → commerce models (B2B/B2C/C2C/D2C/B2G/C2G/Social Commerce), platform guidelines (HIG/Material 3/Fluent 2), domain guidelines (Fintech/Healthcare/SaaS/eComm/Enterprise/AI-ML/DevTools/Biotech)

**When to load which file:**
- Filling in brand config → tokens.md
- Starting any new component → component-anatomy.md + variant-systems.md
- Writing a Claude Code prompt → prompt-engineering.md (required for every prompt)
- Writing docs or reviewing accessibility → documentation.md
- Writing a correction prompt → system-scope.md
- Looking up a node ID → node-ids.md
- Working on a specific product type or platform → domain-context.md (load BEFORE designing any component)

---

## Session-Start: Establish Product Context from Figma Link

**At the start of every new conversation, before doing anything else**, ask:

```
"Please share your Figma file link so I can set up the right context for this session.
I'll need:
  1. The Figma file URL (I'll extract the file key from it)
  2. The page name where the design system lives
  3. Your brand configuration values (I'll walk you through them)

If you're not working in Figma yet and just want design system advice,
tell me what product you're building and I'll help without the file link."
```

**Once the user provides the Figma link:**
1. Extract the file key from the URL (format: `figma.com/design/[FILE_KEY]/...`)
2. Confirm the page name with the user
3. Walk through the Brand Configuration block below — ask for each value
4. Record the file key and page in `references/node-ids.md`

**Do not assume continuity from a previous session.** File keys, token values,
node IDs, and canvas positions do not persist — confirm them fresh each time.

**Do not assume any product name, brand colours, or prefix.** Every session
starts blank. All values come from the user, not from memory or prior sessions.

---

## Multi-Product Switching

When switching from one product to another mid-session (e.g. "now let's work on the
client's system"), do the following before writing any prompt:

1. **Announce the switch:** "Switching active product context to [new product]."
2. **Clear the active brand config:** Explicitly reset all fields. Do not carry over
   any values — font, prefix, colours, or file key — from the previous product.
3. **Ask for the new Figma link:** Extract the new file key from it.
4. **Re-populate the Brand Configuration block** with the new product's values.
5. **Verify node IDs:** Check `references/node-ids.md` for the new product's section.
   Ask the user if it's missing or stale.

**⚠️ Never carry token values, file keys, or node IDs across products.** A wrong
file key means all writes go to the wrong file. A wrong token hex means the entire
system is built on incorrect brand values. Reset completely every time.

---

## ⚠️ Product Agnosticism — Core Principle

This skill carries **no product context between sessions.**

- It does not know which product you're building for unless you tell it.
- It does not remember your brand colours, file key, or token values from last time.
- It does not assume any particular design language, component names, or system structure.
- The Brand Configuration block is always blank until you fill it in for this session.

This is intentional. The skill works equally well for:
- Your own products across any project
- Client work
- New products with no existing system
- Products at any stage (greenfield, mature, redesign)

All it needs from you: the Figma link + your brand config values.

---

Before writing any prompt, confirm the following with the user if not already known:

```
File key:   [USER PROVIDES — Figma file key from URL]
Page:       [USER PROVIDES — e.g. "Design System", "Components"]
Section:    [USER PROVIDES — node ID of the components section frame]
```

**Placement coordinates** — ask the user for the starting x/y if not established.
Increment x by ~1500 per new component set. Track in `references/node-ids.md`.

---

## 🔴 Fill This In First — Brand Configuration

Before building any component, populate this block from the user's design system.
All prompts derive their values from here. Never hardcode values anywhere else.
Never guess or invent values. If a field is blank, stop and ask.

```
─── IDENTITY ───────────────────────────────────────────────────
Product name:      [your product name]
Brand font:        [your brand font — e.g. Inter, Geist, DM Sans]
Component prefix:  [your prefix — e.g. ACM/, NOV/ — used in variable/style names]
buttonRadius:      [pill | rounded | soft square | square — ALWAYS ask before buttons]

─── BRAND COLORS ───────────────────────────────────────────────
primary:           #______   ← primary fills, active borders, dark text
primaryHover:      #______   ← hover on primary buttons (5-10% lighter/darker)
primaryDeep:       #______   ← pressed state on primary buttons (darker)
onPrimary:         #______   ← text/icon ON primary fill (always paired)
onPrimaryMuted:    #______   ← visited links, secondary accents on primary
navBg:             #______   ← mobile nav bar background (if distinct from surface)
mutedText:         #______   ← secondary text, placeholder, inactive icons

─── SURFACE ────────────────────────────────────────────────────
surface:           #______   ← default input bg, tag bg, icon containers
surfaceElevated:   #______   ← focused inputs, cards, modal panels

─── BORDER ─────────────────────────────────────────────────────
defaultBorder:     #______   ← ALL default borders throughout the system

─── DISABLED ───────────────────────────────────────────────────
disabledBg:        #______   ← NEVER use frame opacity — always direct token
disabledText:      #______
disabledBorder:    #______

─── SEMANTIC (use standard values unless brand overrides) ───────
successBg:       #e6f4ea   successBorder: #a8d5b5   successText: #1e7e34
warningBg:       #fef8be   warningBorder: #f0d080   warningText: #7f420e
errorBg:         #fde8e8   errorBorder:   #f5aaaa   errorText:   #e53e3e
infoBg:          [surface]  infoBorder:    [defaultBorder] infoText: [primary]

─── FOCUS ──────────────────────────────────────────────────────
focusRing:        rgba([onPrimary RGB], 0.5)  ← 1.5px primary border + this shadow
focusRingError:   rgba(229, 62, 62, 0.25)     ← on error state inputs only

─── DARK MODE ──────────────────────────────────────────────────
darkMode:         [supported | not in v1]
                  If supported → see references/tokens.md Dark Mode section
                  If not in v1 → add to every prompt:
                  "Do not create dark-mode collections or dark-themed variants."
```

**⚠️ Brand Config Failsafe:** If any field above is blank or contains a placeholder,
**stop immediately and ask the user** before writing any component prompt.
Do not guess values. Do not use placeholder hex values. Do not carry over values
from any previous session or product.

**How to derive hover/pressed from primary:**
- Light brand colors: hover = darken 8%, pressed = darken 15%
- Dark brand colors: hover = lighten 8%, pressed = lighten 15%

---

## Token Contrast Table

**Complete this table for every product before building components.**

| Pair | Context | Ratio | AA | AAA |
|------|---------|-------|-----|-----|
| onPrimary on primary | Button text/icon | ? | ? | ? |
| primary on surface | Default body text | ? | ? | ? |
| primary on surfaceElevated | Cards, modals | ? | ? | ? |
| mutedText on surfaceElevated | Placeholder, hints | ? | ? | ? |
| mutedText on surface | Secondary text on tinted bg | ? | ? | ? |
| primary on navBg | Nav text/icon | ? | ? | ? |
| disabledText on disabledBg | Disabled controls | ? | ? | ? |
| errorText on white | Error messages | ? | ? | ? |
| successText on white | Success messages | ? | ? | ? |
| warningText on warningBg | Warning messages | ? | ? | ? |

**Key rules:**
- mutedText must pass AA at large text sizes only (18px+ regular, 14px+ bold).
- Disabled contrast failure is **exempted by WCAG 1.4.3** — document this, don't fix it.
- Never pair onPrimary text with anything except primary-family fills.

---

## Accessibility Issue Resolution (Required Before Any Prompt)

When the Token Contrast Table reveals a failing pair, **do not write the Claude Code prompt yet.**
Follow this sequence instead:

### Step 1 — Report the issue clearly
State exactly what failed and why:
> "⚠️ **Contrast issue:** `mutedText (#9CA3AF)` on `surface (#FFFFFF)` = **3.2:1** — fails WCAG AA
> for normal text (requires 4.5:1). Affects: placeholder text, input hints, secondary labels."

### Step 2 — Provide a concrete fix
Calculate and suggest a corrected value that passes. Show your work:
> "**Suggested fix:** Darken `mutedText` to `#6B7280` → contrast = **4.6:1** ✅ passes AA.
> This is a minimal adjustment — maintains the same visual intent (cool gray) with a slightly
> deeper shade."

Fix rules:
- Always suggest the **least disruptive change** (smallest delta from the original).
- If fixing one token breaks another pair, flag all cascading effects.
- If the WCAG exemption applies (disabled states), state it explicitly and skip the fix.
- If AAA is achievable with a small additional step, mention it as an optional upgrade.

### Step 3 — Ask the user how to proceed
Always pause here. Do not assume. Ask:

> "How would you like to handle this?
> **A)** Use my suggested fix (`#6B7280`) — I'll use this value in the prompt
> **B)** Keep the original (`#9CA3AF`) — I'll note the known issue and skip the fix
> **C)** I'll provide a different value — tell me the hex and I'll verify it before building"

Wait for the user's response before proceeding.

### Step 4 — Confirm, then build the prompt
Once the user chooses:
- **A)** Confirm: "Got it — using `#6B7280` for `mutedText`. Building the prompt now."
- **B)** Confirm: "Noted — keeping `#9CA3AF` and logging this as a known contrast issue. Building the prompt with the original value."
- **C)** Run the contrast check on their value, confirm it passes (or flag if it still fails), then proceed.

If there are **multiple failing pairs**, address all of them in one block before asking the user —
don't ping-pong back and forth for each issue individually.

---

## Workflow

1. **Fill in Brand Configuration block above** for the specific product.
2. **Fill in Token Contrast Table** — verify every color pair.
   - If any pair **fails**, follow the **Accessibility Issue Resolution** section above before continuing.
   - Do not proceed to Step 3 until all issues are resolved or explicitly accepted by the user.
3. **Load `references/tokens.md`** → write Step 1 Token Foundation prompt.

   ### Token Foundation Checklist (Step 1 — non-negotiable)
   ```
   [ ] Collection 1: [Prefix] / Color       — all color variables
   [ ] Collection 2: [Prefix] / Spacing     — 4px-grid number variables (xs to 4xl)
   [ ] Collection 3: [Prefix] / Radius      — radius number variables (sm to pill)
   [ ] Text Styles:  [Prefix]/text/...      — full type scale as Figma Text Styles
   [ ] Effect Styles: [Prefix]/Shadow/...   — ALL shadow tiers (sm, md, lg, xl,
                                               nav, sidebar, inner, button-hover,
                                               focus-ring, focus-error)
   [ ] buttonRadius confirmed with user     — pill | rounded | soft square | square
                                               (required before any button prompt)
   [ ] Dark mode stance confirmed           — supported | not in v1
   ```
   Shadow Effect Styles are NOT optional — they are referenced by every
   elevation-bearing component. Omitting them from Step 1 forces correction prompts later.
   Shadow values are in references/tokens.md.

4. **Load `references/component-anatomy.md`** → review sizing, platform rules, and shadow table.
5. **Load `references/variant-systems.md`** → check variant props and states for the component.
6. **Load `references/prompt-engineering.md`** → write the component prompt.
   - Always include the full VARIABLE & STYLE BINDING block
   - Always include EXECUTION INSTRUCTIONS
7. **After Claude Code runs** — ask the user to share a screenshot or describe what changed.
   Run the post-build validation checklist (in references/prompt-engineering.md).

   ### MCP Failure Recovery

   If Claude Code or the Figma MCP fails mid-execution, use this triage:

   | Symptom | Recovery path |
   |---------|--------------|
   | Timeout before any frames created | Re-run the full prompt. Add "Build one variant at a time and confirm each before proceeding" to EXECUTION INSTRUCTIONS. |
   | Timeout after partial build | Do NOT re-run the full prompt — you'll get duplicates. Write a scoped continuation prompt: "Starting from where you left off, build only: [remaining variants]." |
   | Node ID not found | Ask the user to re-check the node ID in Figma. Update `references/node-ids.md`. Then re-run with the corrected ID. |
   | Variable not found / binding fails | The token foundation may be missing or misnamed. Re-run the Token Foundation prompt (Step 3) before retrying the component. |
   | Component set created but variants stacked at 0,0 | Do NOT rebuild. Write a correction prompt that only repositions variants with explicit x/y coordinates — do not touch any other properties. |
   | Claude Code reports success but nothing appears in Figma | Ask the user to check a different page, or zoom to fit (Shift+1). If still missing, confirm the file key and page name, then re-run. |
   | MCP connection drops entirely | Ask the user to restart the Figma Desktop Bridge plugin and reconnect. No prompt changes needed. |

8. **Correction or re-run?** Use `references/system-scope.md` for the heuristic:
   - Single-property fix (wrong color, wrong padding, wrong shadow) → **correction prompt**
   - Structural problem (wrong layer order, missing layers, auto-layout broken) → **re-run full prompt**
9. **Record node IDs** in references/node-ids.md after each component is confirmed.
10. **Ask what to build next** — follow the Guided Build Sequence below.

---

## Guided Build Sequence

After each component is confirmed, always ask:

> "What would you like to build next?
> **Recommended:** [next item in sequence below]
> Or tell me a different component and I'll build that instead."

**Recommended sequence — follow this order unless the user directs otherwise:**

```
Phase 1 — Foundation (always first)
  [ ] Token Foundation (colors, spacing, radius, text styles, shadows)

Phase 2 — Core Interactive Controls
  [ ] PillButton (primary CTA — most referenced component)
  [ ] InputField
  [ ] Dropdown / SelectDropdown
  [ ] TextArea
  [ ] SearchBar

Phase 3 — Navigation Shell
  [ ] Nav/Sidebar (desktop) or Nav/BottomBar (mobile) — ask user which first
  [ ] Tab/Item + Tab/Bar
  [ ] PageHeader

Phase 4 — Selection Controls
  [ ] Checkbox/Control + Checkbox/Item
  [ ] Radio/Control + Radio/Item
  [ ] Toggle/Control
  [ ] ToolbarButton

Phase 5 — Content & Display
  [ ] Card
  [ ] Tag / Badge
  [ ] Avatar
  [ ] Toast
  [ ] EmptyState

Phase 6 — Overlays
  [ ] Modal / Dialog
  [ ] Tooltip
  [ ] TextLink

Phase 7 — Advanced
  [ ] ProgressBar
  [ ] Stepper
  [ ] Breadcrumb
  [ ] Icon component set
```

After completing the full system, offer:
"The core component library is complete. Would you like to:
A) Build a Documentation page for each component
B) Add dark mode variants (if not done)
C) Add a component I haven't spec'd yet"

---

## UX Decision Support

When asked "should I use X or Y for this?" or "what's the right pattern for Z?" — these
are UX decisions, not build tasks. Handle them before writing any prompt:

**Modal vs Drawer vs Bottom Sheet:**
- Modal → blocking decision, short form, confirmation (max 3 fields)
- Drawer → contextual detail panel, non-blocking, keep context visible
- Bottom Sheet (mobile) → action sheet or share sheet triggered by tap

**Tabs vs Accordion vs Stepper:**
- Tabs → parallel views, user switches freely, all content equally important
- Accordion → content hierarchy, one section active, progressive disclosure
- Stepper → sequential tasks with clear order and completion state

**Button variant guidance:**
- Primary → one per screen max, the main call to action
- Secondary → supporting action alongside primary
- Ghost → low-emphasis, inline with content
- Danger → destructive action only — always confirm before executing

**When to use a separate component vs a boolean prop:**
- If it's a meaningfully different visual treatment a designer consciously chooses → variant
- If it's just showing/hiding an element within the same layout → boolean prop (show[X])

**Form layout:**
- Single-column → always for mobile; preferred for desktop forms ≤ 4 fields
- Two-column → desktop only, for forms with logical field pairs (First / Last name, City / State)
- Never use more than 2 columns — it creates unclear tab order and breaks screen readers
- Field width should reflect expected input length: zip codes short, addresses long, free text full-width
- Group related fields with a section label + 16px top gap, not just whitespace alone
- Inline validation (on blur) > submit-time validation > real-time validation for most cases

**Navigation architecture:**
- Top nav bar → content-heavy apps, horizontal switching, desktop-first
- Left sidebar → tool-heavy apps, many nav items (5+), workspace-style layouts
- Bottom bar (mobile) → 3–5 primary destinations, thumb-reachable, no labels optional at 5 items
- Breadcrumbs → deep hierarchy (3+ levels), content sites, back-navigation needed
- Do not mix bottom bar + sidebar on the same breakpoint — pick one primary nav per viewport
- Max 5 items in any primary nav; use "More" overflow for additional destinations

**Empty state vs Skeleton vs Loading spinner:**
- Skeleton → use when content shape is known and load time > 300ms (list/card layouts)
- Spinner → use when content shape is unknown, or action is user-triggered (button tap, form submit)
- Empty state → use when there is genuinely no data (first use, filtered to zero, error cleared)
- Never show a skeleton and then an empty state — if you might have no data, go straight to spinner
- Empty states must always include: an icon or illustration, a headline, a sub-label, and a CTA

**Icon strategy:**
- Use a single icon library per product — never mix libraries
- Icon size should match text line-height: 16px icon with 16px line-height, 20px with 20px
- Always pair icons with a label for primary actions; icon-only acceptable for toolbar/secondary actions only if tooltips are present
- Use stroke icons (not filled) for inactive states, filled for active/selected states — do not mix
- When building the icon component set, import SVGs as Figma components with a consistent 24×24 frame and `iconContent` instance swap slot

**FAB vs Toolbar action:**
- FAB → single primary creation action, persistent across the screen, mobile-first
- Toolbar button → contextual action tied to selected content or current view
- Do not use a FAB when there are more than 1 primary actions — use a toolbar or split button
- FAB always floats above content on z-axis — build it last in the layer order so it renders correctly
- On mobile, FAB goes in the sticky zone (bottom 88px); never place it behind the bottom nav bar

If the user's UX question isn't covered above, answer from first principles and then ask:
"Want me to build this component now, or continue with the next item in the sequence?"
