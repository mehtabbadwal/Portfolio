# Domain Reference: Ecommerce

Load this file when the product involves browsing, purchasing, or managing
products or services online — retail, marketplace, subscription commerce,
or any transactional product flow. Apply these shifts across all design steps.

---

## Who the User Is

- **Browsing shopper:** Exploring without a specific intent. Easily distracted,
  influenced by visual presentation and social proof. Decisions are emotional.
- **Intent-driven shopper:** Knows what they want, optimizing for speed and
  confidence. Friction before checkout = abandonment.
- **Repeat purchaser:** Has built trust, wants efficiency. Reorder, saved
  addresses, and payment methods are their primary UX.
- **Seller / merchant (marketplace):** Needs control over listings, inventory,
  pricing, and order management. Efficiency over delight.

**Emotional state at time of use:** Shoppers oscillate between anticipation
(browsing) and anxiety (checkout). The moment money is exchanged is the highest
anxiety point in the flow. Design to sustain positive emotion through browsing
and eliminate anxiety at checkout.

---

## Key Psychological Shifts

**Decision confidence drives conversion.** Users don't abandon because they
don't want the product — they abandon because they're not confident enough
to commit. Every design decision in ecommerce should ask: does this increase
purchase confidence?

**Social proof is structural, not decorative.** Ratings, reviews, purchase
counts, and "X people are viewing this" aren't marketing add-ons — they are
primary UX that reduces decision anxiety. Integrate them close to the decision
point, not at the bottom of the page.

**Friction compounds at checkout.** Every additional step, form field, or
moment of confusion at checkout reduces conversion non-linearly. Checkout is
the one flow where ruthless simplification is always the right call.

**Scarcity and urgency are effective but risky.** "Only 3 left" and
"Sale ends in 2 hours" work because of loss aversion — but if users
discover these signals are false, trust collapses permanently. Only use
real scarcity and real urgency.

---

## Critical UI Patterns

**Product discovery:**
- Search must be fast, forgiving of typos, and return useful results even
  for partial queries. Null results must offer alternatives, never a dead end.
- Filters must update results in real-time or near-real-time — deferred
  filter application kills browsing momentum.
- Visual hierarchy on product listings: image first, price and name second,
  rating third, add-to-cart fourth. Deviate with strong reason only.

**Product detail:**
- Images are the product. High quality, multiple angles, zoom, and
  contextual use-case shots (lifestyle imagery) are UX requirements.
- Price, availability, and key variants (size, color) must be visible
  above the fold on mobile — these are the three decision-critical pieces
  of information.
- Shipping estimate and return policy reduce checkout anxiety — surface
  them on the product page, not only at checkout.

**Cart and checkout:**
- Guest checkout must always be an option. Forced account creation
  before purchase is one of the most reliably documented conversion killers.
- Cart persistence across sessions is mandatory — users abandon and return.
  A lost cart is lost intent.
- Progress indicators in multi-step checkout set expectations and reduce
  abandonment. Users want to know how much is left.
- Order summary must be visible throughout checkout — users need to confirm
  what they're buying as they fill in payment details.
- Error states in checkout must be specific and inline — "Invalid card number"
  next to the field, not a page-level error above the form.

**Post-purchase:**
- Confirmation email and on-screen confirmation are both required. Neither
  replaces the other.
- Order tracking is a primary ongoing use case — make it accessible without
  requiring login if possible.
- Return initiation must be easy to find. A difficult return flow is
  remembered more than the original purchase experience.

---

## What to Never Do

- **Never** require account creation before checkout.
- **Never** hide shipping costs until the last checkout step — it's the
  leading cause of cart abandonment.
- **Never** use fake scarcity or urgency signals — the trust cost is
  permanent when users catch it.
- **Never** make the return or refund policy hard to find — transparency
  here increases conversion, not decreases it.
- **Never** auto-add items to cart (insurance, warranties, subscriptions)
  without explicit opt-in — dark patterns in ecommerce erode brand trust.
- **Never** lose cart contents between sessions or devices.

---

## Commerce Model Interactions

- **B2C (Standard retail):** All of the above applies. Emotional design
  and conversion optimization are the primary levers.
- **D2C (Brand-direct):** Brand consistency across every touchpoint is a
  UX requirement. The product experience IS the brand relationship.
- **C2C (Marketplace):** Trust between strangers is the primary design
  challenge. Seller ratings, identity verification, and dispute resolution
  are core flows, not edge cases.
- **B2B (Wholesale / procurement):** Shift from emotional to efficiency.
  Bulk ordering, quote requests, net-30 payment terms, and purchase order
  workflows become primary use cases.
