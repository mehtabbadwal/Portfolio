# Domain Reference: Biotech

Load this file when the product serves life sciences workflows — lab
management, clinical trial software, bioinformatics, regulatory submission,
research data management, or any product operating in a regulated scientific
context. Apply these shifts across all design steps.

---

## Who the User Is

- **Research scientist:** Domain expert, data-intensive workflows, values
  precision and reproducibility above all. Comfortable with complexity but
  deeply intolerant of ambiguity in data or results.
- **Lab technician / operator:** Executes protocols and records results.
  Often working with physical samples simultaneously — UI interaction is
  interrupted, time-pressured, and sometimes done with gloves on.
- **Regulatory / QA specialist:** Reviews, approves, and audits data.
  Needs complete traceability and unambiguous audit trails. Error tolerance
  is near-zero.
- **Principal investigator / study lead:** Manages teams, monitors progress,
  reviews results at a high level. Needs dashboards and summary views,
  not raw data entry.
- **IT / system administrator:** Manages validation, access, and compliance.
  Not a scientific user — needs administrative control without requiring
  domain expertise.

**Emotional state at time of use:** Scientists are precise and skeptical —
they will question any result the software produces. Lab technicians are
task-saturated during active experiments. QA users are risk-averse and
audit-minded. Design for precision and trust, not speed.

---

## Key Psychological Shifts

**Data integrity is the primary UX contract.** Biotech users must be able
to trust that the software records exactly what they entered, when they
entered it, without modification. Any ambiguity about data provenance
destroys confidence in the entire dataset — and potentially in the research.

**Scientific skepticism extends to the UI.** Researchers will scrutinize
unexpected results. The interface must surface enough context (methodology,
parameters, timestamps) for users to evaluate results themselves, rather
than just accepting the software's output.

**Regulatory compliance is a workflow constraint, not an afterthought.**
21 CFR Part 11, GxP, HIPAA (for clinical studies), and equivalent frameworks
define how data must be captured, signed, and audited. Compliance is not a
feature layer — it is the foundation.

**Reproducibility is a core feature.** A scientist must be able to reproduce
any result: same parameters, same data, same output. The software must
preserve complete experimental context, not just the final result.

---

## Critical UI Patterns

**Data entry and capture:**
- Every data entry action must be timestamped and attributed to a specific
  user — this is both a UX best practice and a regulatory requirement.
- Required fields in scientific forms must be unambiguous — missing data
  in a protocol can invalidate an entire study.
- Units must always be explicit and consistent. A number without a unit
  in biotech is not just confusing — it is scientifically meaningless.
- Validation rules should fire inline and immediately — not on submit.
  A technician who completes 20 fields before seeing an error loses
  significant work and trust.

**Electronic signatures and approvals:**
- 21 CFR Part 11-compliant e-signatures require authentication at the
  point of signing, meaning of the signature, and date/time stamp.
  Design the signature flow to make all three explicit and visible.
- Approval workflows must show current state, who has approved, who is
  pending, and what the next step is — at all times, without requiring
  the user to navigate away.

**Audit trails:**
- Every record modification must log: who changed it, what was changed,
  when, and what the previous value was.
- Audit logs must be easily exportable in standard formats for regulatory
  review.
- Users should be able to view the full history of any record without
  leaving the context of that record.

**Protocol and workflow execution:**
- Step-by-step protocol execution interfaces must prevent skipping steps —
  or make deviation logging explicit and mandatory.
- Branching logic (if sample X, then do Y) must be visually clear before
  the user reaches the branch — not only after.
- Pause and resume states are critical — lab work is interrupted. The
  interface must make it easy to pick up exactly where the user left off.

**Results and data visualization:**
- Raw data must always be accessible alongside any derived results —
  scientists don't trust black-box transformations.
- Statistical confidence, error bars, and sample sizes must be visible
  on any chart or reported result.
- Anomaly highlighting (results outside expected range) is a required
  feature, not a nice-to-have — but must never hide or suppress raw data.

---

## What to Never Do

- **Never** allow data modification without a logged reason and user
  attribution — in regulated biotech, overwriting data without an audit
  trail is a compliance violation.
- **Never** suppress or auto-correct scientific data — flag anomalies,
  never silently remove them.
- **Never** show a result without sufficient context for a scientist to
  evaluate it — parameters, methodology, and timestamps are mandatory.
- **Never** design a protocol execution flow that allows steps to be
  skipped without explicit acknowledgment and logging.
- **Never** use ambiguous units or allow unit-less numeric entry in any
  scientific data field.
- **Never** make audit logs difficult to access — they are a primary
  workflow for QA and regulatory users, not a hidden admin feature.

---

## Commerce Model Interactions

- **B2B (Lab software / LIMS / ELN):** All of the above applies. Procurement
  is often IT or QA — not the scientists who use it daily. Design for
  forced adoption by scientists who didn't choose the tool.
- **B2G (Regulatory submission software):** Compliance visibility is the
  primary UX requirement. Every step must be auditable and every output
  must meet submission format requirements.
- **B2B2C (Research platform → patient-facing clinical trial):** Maintain
  strict separation between the research-facing administrative layer and
  any patient-facing interface. Patient data flows must be separately
  designed with healthcare UX principles applied.
