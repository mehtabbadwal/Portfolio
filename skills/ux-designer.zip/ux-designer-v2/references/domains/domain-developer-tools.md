# Domain Reference: Developer Tools

Load this file when the product serves software engineers, DevOps engineers,
data engineers, platform teams, or any technical practitioner as the primary
user. This includes CLIs, IDEs, API dashboards, monitoring tools, CI/CD
pipelines, infrastructure consoles, and developer portals.

---

## Who the User Is

- **Software engineer (individual contributor):** Primary daily user. Optimizes
  for speed, keyboard efficiency, and minimal context switching. Deeply
  skeptical of UI that gets in the way. Has strong opinions about tools.
- **DevOps / platform engineer:** Manages infrastructure and pipelines at scale.
  Needs system-level visibility, alerting, and bulk operations. Often working
  under incident pressure.
- **Tech lead / engineering manager:** Less hands-on in the tool, but reviews
  outputs, monitors team activity, and makes adoption decisions. Needs
  summary views and reporting without losing access to detail.
- **Data engineer / ML engineer:** Works with pipelines, datasets, and model
  outputs. Data density and lineage visibility are critical. Debugging complex
  pipeline failures is a primary workflow.
- **Developer (onboarding / evaluating):** First impression is everything —
  time to first successful API call, first deploy, or first working integration
  is the activation metric. Friction here = churn.

**Emotional state at time of use:** Engineers in flow state are intolerant of
interruption. Engineers debugging are stressed and need information density.
Engineers evaluating are skeptical and will leave at the first sign of
unnecessary friction or lack of depth. Design for the expert, not the beginner
— but make the beginner path clear without hiding it.

---

## Key Psychological Shifts

**Experts first, always.** Developer tools fail when they optimize for the
onboarding experience at the expense of the expert daily-use experience.
A tool that takes 5 minutes to learn but is slow to use every day will be
replaced. The inverse — hard to learn, fast to use daily — will be adopted
and defended.

**Trust through transparency.** Engineers don't trust black boxes. They need
to see what the system is doing, why, and in what order. Log output, request/
response inspection, pipeline step visibility, error stack traces — these
aren't debug features, they're the product.

**The terminal is a mental model.** Engineers think in text, commands, and
composability. A GUI that can't be automated, scripted, or integrated via
API will always be seen as secondary to the CLI. Keyboard-first, CLI-parallel,
and API-complete are baseline requirements.

**Errors are information.** In consumer UX, errors are failures. In developer
tools, errors are data. Error messages must be specific, include the relevant
state, suggest the exact next step, and link to documentation. "Something went
wrong" is an insult to a developer.

---

## Critical UI Patterns

**Code and text:**
- Monospace font for all code, commands, log output, API responses, and
  configuration. Never use a proportional font for technical content.
- Syntax highlighting for code, JSON, YAML, SQL — it's not decoration,
  it's comprehension.
- One-click copy on all code blocks, commands, API keys, and IDs.
  Developers copy-paste constantly — every extra step is friction.
- Inline diff views for comparing configuration changes, code versions,
  or API responses.

**Search and filtering:**
- Developers navigate by search, not by browsing. Search must be fast,
  fuzzy, and global — across resources, logs, configs, and documentation.
- Filter by multiple parameters simultaneously. Boolean operators are
  expected by power users — support them or provide equivalent UI.
- Saved searches and filters — developers repeat the same queries constantly.

**Logs and output:**
- Log streams must be real-time or near-real-time. Polling with a visible
  refresh button is acceptable only if streaming isn't feasible.
- Log filtering by level (debug, info, warn, error), by time range, by
  service or resource — all mandatory.
- Timestamps in logs must be precise (milliseconds) and shown in a
  configurable timezone (UTC by default, local time optional).
- Log lines must be selectable, copyable, and linkable (shareable URL
  to a specific log entry or time range).

**API and integration:**
- Every action in the UI must have an equivalent API — and that API must
  be visible. Developers will automate whatever they do more than twice.
- API keys, tokens, and credentials must be easy to create, scope,
  rotate, and revoke. Audit trails on credential usage.
- Webhook configuration must be a first-class UI — not buried in settings.
- OpenAPI / Swagger documentation must be auto-generated and accurate.

**Status and monitoring:**
- System status must be visible without navigating away — a persistent
  status indicator or header badge.
- Alerts must be configurable by the user — thresholds, channels (Slack,
  PagerDuty, email), and severity levels.
- Incident history and postmortem links as part of the status page —
  developers want to understand patterns, not just current state.

**Keyboard and efficiency:**
- Command palette (⌘K or Ctrl+K) for global navigation and actions —
  the single highest-value feature for developer tools after core
  functionality.
- Keyboard shortcuts for all primary actions — document them inline,
  not in a buried help page.
- Vim keybindings option for text editors and log navigation.
- Bulk selection and bulk actions on any list or table.

---

## Documentation as UX

Documentation is not separate from the product — it is part of the UX.

- **Inline docs:** Every configuration field, parameter, and API endpoint
  needs a tooltip or inline explanation. Don't force users to leave the
  UI to understand what a field does.
- **Runnable examples:** Code examples should be copyable and ideally
  runnable in a sandbox directly in the docs.
- **Error → docs linking:** Every error code or message should link to
  a specific docs page explaining the error and how to resolve it.
- **Changelog:** Developers need to know what changed and when. A
  versioned, detailed changelog is a trust signal.

---

## What to Never Do

- **Never** hide technical details behind a "simplified" view without
  providing access to the full detail — developers will find it hostile.
- **Never** use vague error messages — include the resource ID, the
  operation that failed, the error code, and the remediation path.
- **Never** make the CLI secondary — if the UI can do something the
  CLI can't, that's a bug.
- **Never** require a mouse for primary workflows — keyboard-first is
  not optional for developer tools.
- **Never** paginate logs without providing time-range filtering —
  "next page" is useless when debugging an incident.
- **Never** auto-renew or auto-rotate credentials without explicit
  notification and a deprecation period.
- **Never** make API documentation a static PDF — it must be searchable,
  versioned, and linked from the UI.

---

## Commerce Model Interactions

- **B2B (Enterprise developer tools):** Admin controls, SSO/SAML,
  role-based access, audit logs, and SLA commitments are requirements.
  Procurement involves security review — surface SOC 2, compliance docs
  in the product.
- **PLG (Product-Led Growth / self-serve):** Time to first successful
  API call or first working integration is the activation metric.
  Generous free tier with clear upgrade prompts at natural friction points.
- **B2C (Individual developer):** Developer experience is the product.
  Documentation quality, SDK quality, and community (Discord, GitHub) are
  as important as the core tool.
