# Domain Reference: AI / ML Products

Load this file when the product is primarily an AI or machine learning system —
where the core value proposition involves model inference, predictions,
recommendations, generated content, or automated decisions. Apply alongside
Step 8 (AI Product UX), which covers interaction patterns. This file covers
the user psychology and domain-specific context that Step 8 doesn't.

This domain covers two distinct user types who often coexist in the same product.
Read both sections and apply the relevant one based on who you're designing for.

---

## User Type 1: Business Users of AI Products

People who use AI-powered products to do their job — not to build or understand
the AI itself. Writers using AI writing tools, designers using AI design systems,
support teams using AI triage, sales teams using AI-generated insights.

### Who They Are

- **Adopters:** Curious, willing to experiment, but cautious. Building mental
  models of what the AI can and can't do through trial and error.
- **Skeptics:** Resistant, often forced to use the tool by their organization.
  Watching for failures that confirm their skepticism. One bad output can
  set adoption back weeks.
- **Power users:** Have internalized the AI's behavior and learned to prompt
  it effectively. Need advanced controls and batch capabilities.

**Emotional state at time of use:** Anxiety is the dominant emotion for new
users — "what if it gets this wrong and I don't catch it?" Power users feel
efficient, almost collaborative. Skeptics feel suspicious.

### Key Psychological Shifts

**The automation paradox.** The more an AI automates, the less the user
understands it — and the more catastrophic errors become. Don't optimize
purely for automation. Build in deliberate moments where the user reviews,
confirms, or steers. These aren't friction — they're trust anchors.

**Blame attribution.** When an AI makes a mistake, users attribute it
differently based on how the UI frames the AI's role. If the AI is framed
as a tool the user controls, mistakes feel correctable. If framed as an
autonomous agent, mistakes feel like betrayal. Frame AI as an assistant,
not an authority.

**Skill atrophy anxiety.** Many users worry that relying on AI will degrade
their own skills. Designs that make the AI's reasoning visible — not just
its output — help users feel like they're learning alongside the AI, not
being replaced by it.

**Output ownership.** Users need to feel that AI outputs become theirs once
they act on them. Make editing, personalizing, and reshaping AI outputs
the primary interaction, not accepting or rejecting them wholesale.

### Critical UI Patterns for Business Users

**Confidence and provenance:**
- Show what the AI based its output on — "Generated from your last 3
  project briefs" — not just what it produced.
- Distinguish between high-confidence and low-confidence outputs visually.
  Not percentages — qualitative language ("Based on limited data,"
  "High confidence based on 40 similar cases").
- Make it easy to see the source material behind any AI output.

**Correction and steering:**
- Every AI output must be directly editable without losing context.
- Inline correction beats modal feedback forms — "fix this" should happen
  where the problem is, not in a separate reporting flow.
- Regeneration with constraints: "Regenerate, but shorter" or "Regenerate
  in a more formal tone." Partial regeneration beats full replacement.

**Progressive AI involvement:**
- Start new users with AI as a suggester, not a decider. As trust builds,
  surface more autonomous capabilities.
- Never front-load the most powerful AI features — they require the most
  trust, which hasn't been built yet.

---

## User Type 2: ML Practitioners Building AI Systems

Data scientists, ML engineers, AI researchers, and platform teams building,
training, evaluating, and deploying machine learning models and pipelines.

### Who They Are

- **Data scientists:** Exploratory, hypothesis-driven. Work in notebooks,
  run experiments, evaluate model performance. Need flexible, composable tools
  more than polished UIs.
- **ML engineers:** Operationalize models. Care about pipeline reliability,
  reproducibility, and deployment stability. Closer to software engineering
  in mindset.
- **AI researchers:** Pushing the boundary of what's possible. Need deep
  control, full transparency, and the ability to inspect everything. Tolerant
  of complexity, intolerant of constraints.
- **AI product teams:** Non-technical stakeholders evaluating model performance
  and making product decisions based on AI outputs. Need accessible metrics
  and clear tradeoffs — not raw model output.

**Emotional state at time of use:** Data scientists during exploration are
curious but impatient — they want to iterate fast. ML engineers during
deployment are cautious and methodical. Researchers are focused and expect
the tool to get out of their way. Product teams are anxious — they need to
make decisions with imperfect information.

### Key Psychological Shifts

**Reproducibility is non-negotiable.** Every experiment, training run,
evaluation, and deployment must be reproducible. Users must be able to
return to any point in time and reconstruct exactly what happened, with
what data, using what parameters. This is not a feature — it's the product.

**Uncertainty is data.** ML practitioners don't treat uncertainty as a
problem to hide — they treat it as information to analyze. Show confidence
intervals, error distributions, and edge case performance. Hiding uncertainty
destroys trust faster than showing it.

**Iteration speed is the product.** The faster a practitioner can run an
experiment and see results, the more valuable the tool. Every second of
latency in the feedback loop is a product failure. Optimize for time-to-result
above almost everything else.

**The notebook is a mental model.** Data scientists think in cells, not
forms. Jupyter-like interaction patterns — sequential cells, inline output,
incremental execution — are deeply ingrained. Tools that fight this model
will face resistance.

### Critical UI Patterns for ML Practitioners

**Experiment tracking:**
- Every training run must be logged automatically — parameters,
  metrics, artifacts, environment. Never make practitioners manually
  log what the system can capture automatically.
- Comparison views across multiple runs — side-by-side parameter and
  metric comparison is a primary workflow.
- Tagging, filtering, and search across experiment history.
- Metric curves over training time — loss curves, accuracy curves — must
  be interactive and zoomable.

**Model evaluation:**
- Confusion matrices, precision/recall curves, ROC curves — standard
  evaluation visualizations must be built in, not bolted on.
- Slice analysis: performance broken down by subgroup (demographic,
  feature value, data source). This is how practitioners find bias
  and failure modes.
- Comparison against baseline and previous versions — practitioners
  need to know if a new model is actually better.

**Data lineage and pipeline visibility:**
- Every model must be traceable to its training data — what data,
  from when, with what preprocessing.
- Pipeline DAGs (directed acyclic graphs) are the primary mental model
  for ML pipelines. Visualize them — don't flatten them into a list.
- Failed pipeline steps must show: which step failed, the full error,
  the input data at that step, and a direct path to retry.

**Deployment and monitoring:**
- Model versioning with explicit promotion workflow (staging → production).
  Never silent deployments.
- Real-time inference monitoring: latency, throughput, error rate — plus
  drift detection (when live data distribution diverges from training data).
- Rollback to previous model version must be a one-action operation.
- A/B testing infrastructure for model comparison in production.

---

## What to Never Do

**For business users:**
- **Never** make AI outputs feel final — they should always feel editable
  and improvable.
- **Never** present AI confidence as a single percentage — it implies
  false precision and is misread as probability of being correct.
- **Never** auto-apply AI changes to anything the user hasn't reviewed,
  especially destructive or irreversible actions.
- **Never** design for the skeptic by removing AI features — design for
  trust by making the AI's reasoning visible.

**For ML practitioners:**
- **Never** hide model uncertainty or aggregate metrics that obscure
  subgroup failures.
- **Never** require manual logging of information the system can capture.
- **Never** make experiment comparison require navigation away from the
  primary experiment view.
- **Never** deploy a new model version without an explicit confirmation
  step and rollback path.
- **Never** flatten a pipeline DAG into a sequential list — practitioners
  need to see the actual dependency graph.

---

## Commerce Model Interactions

- **B2B SaaS (AI tools for teams):** Both user types often coexist.
  Practitioners build and tune the AI; business users consume its outputs.
  Design the admin/practitioner layer and the end-user layer with
  intentional separation.
- **B2C (Consumer AI products):** Business user psychology dominates.
  Trust calibration, progressive AI involvement, and output ownership
  are the primary design challenges.
- **PLG (Developer / practitioner tools):** Time to first successful
  model training or first API inference is the activation metric.
  Generous free tier, excellent documentation, and fast iteration loop.
- **Enterprise:** Governance, audit trails, role-based access to models
  and data, and compliance with AI regulations (EU AI Act, sector-specific
  rules) are requirements — not differentiators.
