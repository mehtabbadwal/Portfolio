# Domain Reference: IoT / Hardware

Load this file when the product involves connected devices, sensors,
physical hardware, firmware, or any interface that bridges the digital
and physical world. Apply these shifts across all design steps.

---

## Who the User Is

- **Consumer IoT user:** Connected home, wearables, personal devices.
  Expects "it just works." Low tolerance for setup complexity. Bluetooth
  pairing and Wi-Fi configuration are already the highest-friction moments
  in their experience.
- **Industrial / operational user:** Manages multiple devices at scale.
  Works in harsh environments (factory floor, field, warehouse). Needs
  status at a glance, hands-free interaction, and tolerance for network
  interruptions.
- **Technical installer / integrator:** Sets up and configures devices for
  others. Needs diagnostic depth, detailed logs, and manual override capability.
- **Developer / API user:** Building on top of the device platform. Needs
  documentation, webhooks, and developer tooling — but these users touch
  the hardware-facing UI too.

**Emotional state at time of use:** Consumer IoT users are frustrated when
they reach the setup flow — setup is never why someone bought the device.
Industrial users are time-pressured and often working in suboptimal conditions
(loud, bright, gloved hands). Design for the worst reasonable environment,
not the ideal office setting.

---

## Key Psychological Shifts

**The physical world is the ground truth.** Users trust what they can see
and touch over what the UI says. When the physical device state and the
UI state disagree, users will always believe the device. UI must reflect
physical reality instantly and accurately — or explain why there's a
discrepancy.

**Latency is a UX problem unique to IoT.** Commands sent to physical
devices have real-world latency — network round-trip, firmware processing,
physical actuation. Users interpret silence as failure. Every command needs
an immediate acknowledgment in the UI, even if the physical result
takes seconds.

**Connectivity is not guaranteed.** Unlike pure software products, IoT
interfaces must design for the offline and degraded-connection state as
a first-class experience. What can the user do when the device is offline?
The UI must answer this clearly, not just show an error.

**Setup and pairing is the highest churn moment.** More consumer IoT
products fail at first-run setup than at any other point. Bluetooth
pairing, Wi-Fi credential entry, and firmware updates during setup are
where users give up. Reduce every step, surface every error clearly, and
always offer an escape route.

---

## Critical UI Patterns

**Device state communication:**
- Every device needs a clear, always-visible status indicator: online,
  offline, syncing, error, updating. Never make users hunt for this.
- State changes must be timestamped — "Last updated 3 minutes ago" is
  more trustworthy than a static reading with no context.
- When UI state and physical state diverge, explain why and give a
  resolution path — "Device not responding. Try power cycling or check
  your network connection."

**Command feedback:**
- Immediate visual acknowledgment on every command (< 100ms) — even if
  the physical result takes longer.
- Distinguish between "command sent," "command received by device," and
  "command executed" — these are three distinct states in IoT and users
  experience all three.
- Failed commands must specify: did the command not send, not reach the
  device, or not execute? Each failure has a different resolution.

**Setup and onboarding:**
- Pairing flows must be step-by-step with visual confirmation at each step.
  Never batch steps that depend on physical actions.
- Every step that requires a physical action (press the button, plug in
  the device) needs a clear illustration or photo, not just text.
- Provide a recovery path at every step — "Something went wrong" with a
  restart option and a troubleshooting link.
- Firmware updates during setup must show progress and estimated time.
  A silent progress bar with no estimate creates abandonment.

**Multi-device management:**
- When users manage multiple devices, grouping and naming are primary UX
  features — let users organize their device topology.
- Bulk status views (all devices, room by room, zone by zone) must
  surface anomalies immediately — the one device with a problem should
  stand out, not hide in a list of 30.
- Device history and logs are critical for troubleshooting — make them
  accessible to standard users, not just admins.

**Offline and degraded states:**
- Clearly communicate when a device is offline vs. when the app cannot
  reach the cloud vs. when the user's internet is down — these are
  three different problems with different solutions.
- Where possible, preserve last-known-good state in the UI — a device
  showing its last known temperature is more useful than a blank state.
- Queue commands during offline periods and sync when connection is
  restored — never silently drop a command.

---

## What to Never Do

- **Never** show a UI state that contradicts the physical device state
  without explaining the discrepancy.
- **Never** send a command and show success before confirmation from
  the device — optimistic UI that fails silently destroys trust in IoT.
- **Never** design setup as a one-shot flow with no recovery — always
  allow restart from any step.
- **Never** leave a firmware update in progress without a visible
  progress indicator and estimated completion time.
- **Never** assume connectivity — every state must be designed for
  offline, partial, and degraded network conditions.
- **Never** use color alone to communicate device status — industrial
  environments may have color contrast issues under different lighting.

---

## Commerce Model Interactions

- **B2C (Consumer IoT):** Setup simplicity is the product. Users judge
  the entire hardware product by how painful or painless the app setup is.
  First-run experience is disproportionately weighted.
- **B2B (Industrial IoT):** Data density and multi-device management are
  primary. Role-based access (operator vs. administrator vs. technician)
  is critical. Integration with SCADA, ERP, or monitoring systems is
  often required.
- **B2B2C (IoT platform → consumer):** The hardware company's platform
  layer must enable the business customer to white-label and configure
  the consumer experience. Theming, configuration, and alert threshold
  management become the primary admin UX.
