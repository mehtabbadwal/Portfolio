# Domain Reference: Healthcare

Load this file when the product serves patients, clinicians, administrators,
or any healthcare workflow. Apply these shifts across all design steps.

---

## Who the User Is

Healthcare UX spans radically different users — and the same product often
serves more than one simultaneously:

- **Clinicians (physicians, nurses, PAs):** Time-pressured, high-stakes
  decisions, interrupted constantly. Cognitive load is already maxed. UI
  errors aren't annoyances — they're patient safety events.
- **Patients:** Anxious, often unfamiliar with medical concepts, variable
  health literacy, may be in pain or distress. Trust is fragile.
- **Administrators:** Process-driven, metrics-focused, less clinical context
  but high volume of repetitive tasks.
- **Researchers:** Data-intensive, precision-focused, comfortable with
  complexity, need reproducibility and auditability.

**Emotional state at time of use:** Clinicians are stressed and rushed.
Patients are anxious and often scared. Administrators are task-saturated.
Design for the emotional worst-case, not the calm ideal.

---

## Key Psychological Shifts

**Cognitive load reduction is non-negotiable for clinical users.**
A nurse in an ICU has no cognitive budget left for a confusing UI. Every
interaction must be obvious on first contact. Progressive disclosure,
sensible defaults, and zero-ambiguity copy are mandatory, not nice-to-have.

**Error gravity is different here.** In most products, an error means
frustration. In healthcare, an error can mean wrong medication, missed
diagnosis, or delayed care. Every error state must be: immediately visible,
clearly explained, and explicitly resolved — never silently failed.

**Trust is asymmetric.** Patients give clinicians enormous trust — they
need to see that trust reflected in how the product handles their data.
"Your data is safe" is not enough. Show them what's stored, who can see
it, and how to control it.

**Workflow integration beats workflow redesign.** Clinical workflows are
often legally or procedurally defined. Your product fits into them — it
doesn't replace them. Understand the existing workflow before designing
anything.

---

## Critical UI Patterns

**Alerts and flags:**
- Critical alerts must interrupt — not just appear in a sidebar. A missed
  alert in healthcare is a design failure.
- Use escalating severity levels (info → warning → critical) with distinct
  visual treatment at each level — never rely on color alone.
- Alert fatigue is a real clinical problem. Only flag what requires action.
  Every non-actionable alert reduces trust in all alerts.

**Data display:**
- Lab values, vitals, and medication dosages must be unambiguous — units,
  reference ranges, and timestamps always visible.
- Trend data (vitals over time) is more clinically useful than point-in-time
  data. Default to trend views where appropriate.
- Never truncate clinical data for aesthetics. A cut-off value is a
  patient safety issue.

**Forms and data entry:**
- Autofill and smart defaults reduce entry errors — but always make the
  default explicitly visible and easily overridable.
- Mandatory fields must be unambiguous. In clinical contexts, a missed
  required field isn't an annoyance — it can block care.
- Confirmation steps before any irreversible action (medication administered,
  order submitted, record finalized).

**Patient-facing UI:**
- Plain language mandatory — target 6th grade reading level for patient copy.
- Avoid clinical jargon entirely in patient-facing flows.
- Appointment booking, results viewing, and messaging must work for users
  with low digital literacy and high anxiety.

---

## Compliance and Privacy Signals

- HIPAA compliance must be visible in the UI where relevant — not buried
  in a footer link. Patients need to see it at the moment they share data.
- Consent flows must be explicit, granular, and easy to revisit.
- Access logs and audit trails are clinical and legal requirements — they
  are also trust features. Consider surfacing them to users.

---

## What to Never Do

- **Never** use color alone to convey clinical severity — colorblind clinicians
  exist and accessibility is a patient safety issue.
- **Never** auto-submit or auto-confirm anything in a clinical workflow
  without explicit user action.
- **Never** design for the ideal calm moment of use — design for the
  interrupted, stressed, time-pressured reality.
- **Never** use vague copy in error states ("Something went wrong") — clinical
  users need to know exactly what failed and what to do next.
- **Never** obscure what data is stored or who has access to it.

---

## Commerce Model Interactions

- **B2B (Hospital/clinic as buyer):** Procurement is IT or administration.
  The actual users (clinicians) had no say in the purchase. Design for
  forced adoption — assume initial resistance, not enthusiasm.
- **B2C (Patient-direct):** Emotional design applies fully. Reduce anxiety
  at every step. Social proof (doctor credentials, patient counts) matters.
- **B2B2C (Provider platform → Patient):** The clinician's trust in the
  tool must be visible to the patient. Design the handoff moment carefully.
