# Domain Reference: Finance

Load this file when the product serves banking, investment, insurance,
payments, accounting, or any financial workflow. Apply these shifts
across all design steps.

---

## Who the User Is

- **Retail investors / consumers:** Variable financial literacy, emotionally
  reactive to losses, often making infrequent but high-stakes decisions.
- **Professional traders / analysts:** Data-intensive, speed-critical,
  keyboard-first, comfortable with high information density.
- **Accountants / finance teams:** Process-driven, repetitive workflows,
  compliance-focused, often working across multiple clients or entities.
- **Banking customers:** Wide literacy range, high anxiety around money,
  trust-sensitive, often using mobile during short time windows.

**Emotional state at time of use:** Anxiety is the dominant emotion across
almost all finance contexts. Losses feel twice as bad as equivalent gains
(loss aversion). Users approaching anything financial are already primed for
risk. Design to reduce anxiety, not to project false confidence.

---

## Key Psychological Shifts

**Loss aversion dominates.** Every financial UI is operating in loss-aversion
territory. Users are not just evaluating features — they are evaluating risk.
"Don't lose my money" is more powerful than "grow my money." Frame actions
in terms of protection and control, not opportunity.

**Trust is the primary UX metric.** A fintech product that is fast, beautiful,
and confusing will lose to a slow, plain, and trustworthy one. Every design
decision must ask: does this make the user feel safer?

**Confirmation before commitment.** Financial actions are often irreversible —
wire transfers, trade executions, account closures. Every irreversible action
needs a dedicated confirmation step that clearly states: what will happen,
how much, to/from where, and that it cannot be undone.

**Transparency over cleverness.** Hidden fees, buried terms, and clever
defaulting are the source of the most damaging finance UX failures (and
regulatory action). Show everything. Label everything. No surprises.

---

## Critical UI Patterns

**Numbers and amounts:**
- Currency, units, and decimal precision must always be explicit.
  "$1,000" and "1000.00 USD" are different levels of clarity for different
  users — know which your context requires.
- Positive/negative values need clear visual distinction beyond color alone
  (+ / − prefix, parentheses for negative, directional indicators).
- Large numbers should use comma separators or abbreviated notation
  (1.2M, 4.5B) consistently — never mix formats in the same view.

**Transaction and account states:**
- Pending, processing, settled, failed — each state needs distinct visual
  treatment and a clear explanation of what it means and what happens next.
- Transaction history is a primary use case, not a secondary one. Default
  sort (newest first), clear timestamps, and fast filtering are mandatory.
- Balance displays should always be timestamped — users need to know
  if the number is real-time or delayed.

**Sensitive actions:**
- Transfers, payments, and withdrawals require: summary screen → explicit
  confirmation → success/failure state. Never compress these into one step.
- Allow users to review and cancel before anything executes.
- Confirmation copy must be specific: "Send $500.00 to Chase ••••4821 —
  this cannot be undone" not "Confirm transaction."

**Charts and data visualization:**
- Always show time range selection — users need context for any number.
- Avoid misleading Y-axis truncation — it exaggerates gains/losses and
  destroys trust when users catch it.
- Performance charts need benchmark context — a 5% gain means nothing
  without a comparison point.

---

## Compliance and Regulatory Signals

- Regulatory disclosures must be present where required — but design them
  to be readable, not buried. A disclosure no one reads is a liability.
- Data privacy (what's shared, with whom, and why) must be easily
  accessible — not hidden in a 40-page terms document.
- Audit trails are often legally required. Surface them as a trust feature,
  not just a compliance checkbox.

---

## What to Never Do

- **Never** obscure fees, rates, or terms — even if they're unfavorable.
  Surprise charges are the #1 trust-killer in finance UX.
- **Never** use color alone to distinguish positive and negative values —
  colorblind users need another signal.
- **Never** execute a financial action without explicit confirmation.
- **Never** show a number without its timestamp if it could be stale.
- **Never** make account closure, transfer cancellation, or dispute
  resolution difficult to find — hiding these flows creates regulatory
  and trust risk.
- **Never** design for the calm, informed user — design for the anxious
  user checking their account at 11pm after market volatility.

---

## Commerce Model Interactions

- **B2C (Consumer finance / fintech):** Emotional design applies — but
  delight must never come at the expense of clarity. Every animation or
  celebration must reinforce trust, not distract from it.
- **B2B (Finance software / accounting tools):** Data density is a feature.
  Power users need keyboard navigation, bulk actions, and fast filtering.
- **B2G (Government financial systems):** Compliance visibility is the
  primary UX requirement. Audit logs, access controls, and data residency
  must be front and center.
