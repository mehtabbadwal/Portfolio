# Domain Reference: B2B SaaS

Load this file when the product is a software-as-a-service tool sold to
businesses — project management, CRM, analytics, HR, communication,
developer tools, or any team-based workflow software. Apply these shifts
across all design steps.

---

## Who the User Is

- **Admin / owner:** Configures the product, manages billing and permissions,
  accountable for ROI. Often less frequent user, higher stakes per session.
- **Power user / team lead:** Daily user, deeply invested in workflow
  efficiency, likely to advocate for or against the tool internally.
- **Standard user:** Regular daily use, task-focused, often resistant to
  change, may have had no say in the tool selection.
- **Occasional user / guest:** Low frequency, needs to accomplish one
  specific task without learning the full product.

**Emotional state at time of use:** Power users are focused and efficiency-
driven. Standard users are often working under deadline pressure. Admins
are evaluating — they're always implicitly asking "is this worth what we
pay?" Design for all three states simultaneously.

---

## Key Psychological Shifts

**Adoption is often forced, not chosen.** The person using your product
didn't necessarily select it — the decision was made above them. Design
to win over reluctant users, not just enthusiastic early adopters.
First-run experience must demonstrate value immediately.

**The tool must fit the workflow, not replace it.** B2B SaaS that asks
teams to change their behavior fundamentally will face resistance.
Integrate with existing tools (Slack, email, calendar, Google Drive)
and map to existing mental models before introducing new ones.

**Efficiency compounds.** Small friction multiplied across 50 people × 200
days = enormous waste. Optimize for the repeated action, not the one-time
setup. Keyboard shortcuts, bulk actions, and saved views are not advanced
features — they are the product for power users.

**Trust is built through reliability, not personality.** Uptime, data
accuracy, and predictable behavior matter more than visual delight. A
beautiful product that loses data once is remembered as the product that
lost data.

---

## Critical UI Patterns

**Onboarding and activation:**
- Time-to-value is the key onboarding metric — how quickly can a new user
  accomplish their first meaningful task?
- Separate admin setup (workspace config, permissions, integrations) from
  user onboarding (how to do your daily job here).
- Empty states must provide a clear starting action — never show an empty
  state without a path forward.
- Progressive onboarding beats upfront wizards — teach the product through
  use, not through tutorials before use.

**Navigation and IA:**
- B2B SaaS users navigate by task, not by feature. Organize around jobs
  to be done, not around product capabilities.
- Breadth over depth — flat navigation with clear labels beats nested menus
  that require exploration.
- Saved views, filters, and search are primary navigation for power users.
  Invest in them proportionally to their usage frequency.

**Collaboration and multi-user:**
- Presence indicators (who's viewing, who's editing) prevent collision and
  build confidence in shared workflows.
- Change history and undo are trust features — users need to know mistakes
  are recoverable.
- Notifications must be actionable, not just informational. "X commented"
  with no way to respond in-context is friction.

**Roles and permissions:**
- Every screen must be designed for its full permission range. A view that
  looks broken to a viewer (because an admin action is missing) is a
  UX failure.
- Permission errors must explain why access is denied and who to contact —
  never a generic "you don't have access" with no next step.
- Admins need visibility into what their users see — a preview-as-role
  feature is a high-value, often-missing pattern.

**Data and reporting:**
- Export is a primary feature, not an afterthought — B2B users need data
  out of the product as much as in it.
- Reporting dashboards should default to the most action-relevant view,
  not the most comprehensive one.
- Empty report states should explain why there's no data, not just that
  there isn't any.

---

## What to Never Do

- **Never** design only for the happy path. B2B workflows have exceptions,
  edge cases, and error states that happen daily — they are not edge cases.
- **Never** change behavior without warning. B2B users build muscle memory
  and workflows around your UI — silent changes destroy trust.
- **Never** hide bulk actions or keyboard shortcuts — they are the product
  for your most valuable users.
- **Never** make integrations feel like an advanced feature — in B2B SaaS,
  integrations are how the product fits into the user's world.
- **Never** design the admin experience as an afterthought — admins are your
  primary champions and the decision-makers at renewal.

---

## Commerce Model Interactions

- **B2B (Standard):** All of the above applies. Prioritize power user
  efficiency and admin control.
- **B2B2C (SaaS platform → end consumer):** Maintain a strict separation
  between the admin/business layer and the consumer-facing layer.
  They need different design languages.
- **PLG (Product-Led Growth):** When the product has a self-serve trial
  or freemium model, time-to-value is the activation metric. The first
  session must deliver a result, not just explain the product.
