# Commerce Models: UX Behavioral Shifts

This file is loaded when a commerce model is identified in Step 1.
Apply these behavioral shifts across all subsequent design steps.

---

## B2B — Business to Business

**User relationship to the product:** High stakes, long sessions, multiple
stakeholders involved in the same decision. The person using the UI often
didn't choose the product — procurement did.

**Key behavioral shifts:**
- Users are professionals. Efficiency and control matter more than delight.
- Multiple roles interact with the same data — design for the full permission
  matrix, not just the primary user.
- Adoption is often mandated, not voluntary. Onboarding must overcome
  resistance, not just explain features.
- ROI must be visible — users need to justify the tool to their manager.
  Surface metrics, outputs, and time-saved signals in the UI.

**Design priorities:** Role-based access, bulk actions, audit trails,
integrations with existing tools (Slack, email, calendar), data export,
keyboard shortcuts for power users.

**Never:** Hide how the system works. B2B users need to trust the tool
completely before they trust it with their work.

---

## B2C — Business to Consumer

**User relationship to the product:** Voluntary, emotional, low switching cost.
Users chose to be here and can leave just as easily.

**Key behavioral shifts:**
- First impressions are disproportionately important — 3 seconds to hook or lose.
- Emotional resonance drives retention more than features.
- Users have short sessions and fragmented attention — design for interruption.
- Social proof (reviews, ratings, user counts) reduces decision anxiety.

**Design priorities:** Onboarding speed, visual delight, personalization,
notifications done right (not spam), frictionless checkout or sign-up,
clear value proposition above the fold.

**Never:** Make users work to understand what the product does. Confusion
equals churn in B2C — there is no IT helpdesk forcing them to figure it out.

---

## D2C — Direct to Consumer

**User relationship to the product:** The brand *is* the product. Users
chose this brand specifically, bypassing retail. That relationship is the
moat.

**Key behavioral shifts:**
- Brand consistency across every touchpoint is a UX requirement, not just
  a marketing one. Tone, color, copy — all of it is the experience.
- Loyalty loops matter more than single transactions. Repeat purchase,
  referral, and community are the core metrics.
- Users expect to feel like insiders — exclusivity, early access, and
  behind-the-scenes content are UX, not just marketing.
- Unboxing, post-purchase, and return flows are often neglected — they're
  where loyalty is won or lost.

**Design priorities:** Brand-forward UI, seamless checkout, loyalty programs,
post-purchase experience, subscription management, referral mechanics.

**Never:** Make the brand feel generic. A D2C user chose you specifically —
every screen should reinforce that choice.

---

## B2G — Business to Government

**User relationship to the product:** Procurement-driven, compliance-first,
risk-averse. The buyer and the user are almost never the same person.

**Key behavioral shifts:**
- Risk aversion dominates every decision. No user wants to be the person
  who introduced a problem. Design for safety, not speed.
- Compliance is a feature. WCAG AA accessibility, FISMA, FedRAMP, data
  residency — make compliance visible and verifiable in the UI.
- Process is sacred. Government workflows are often legally defined.
  Your UI must fit the process, not redesign it.
- Audit trails and reporting are primary use cases, not secondary ones.

**Design priorities:** Accessibility (WCAG AA minimum), comprehensive audit
logs, role-based permissions, data export in standard formats, clear error
states with remediation paths, no surprising changes or auto-actions.

**Never:** Auto-anything without explicit user confirmation. B2G users need
to be able to explain every system action to an auditor.

---

## B2B2C — Business to Business to Consumer

**User relationship to the product:** Two distinct users with opposing needs
on the same platform. The business customer (your direct buyer) wants control,
reporting, and efficiency. Their end consumers want simplicity and speed.

**Key behavioral shifts:**
- You are designing two products that share infrastructure. Treat them that way.
- The business user's UI (admin, config, reporting) and the consumer user's UI
  (the experience the business deploys to their customers) need different
  design languages.
- The business user judges success by their consumers' outcomes — surface
  those metrics prominently.
- Branding is layered — your platform brand + the business customer's brand
  + the end consumer's expectation. White-labeling and customization are
  often UX requirements.

**Design priorities:** Clear separation of admin vs. end-user contexts,
white-label theming, consumer-facing simplicity, business-facing analytics,
onboarding flows for both user types.

**Never:** Design a single UI that tries to serve both users simultaneously.
Role detection and context switching must be explicit and reliable.

---

## C2C — Consumer to Consumer

**User relationship to the product:** The platform is a marketplace of trust
between strangers. The product's job is to make that trust possible.

**Key behavioral shifts:**
- Trust signals are the primary UI. Ratings, reviews, verification badges,
  response rates, profile completeness — these aren't metadata, they're the
  product.
- Both sides of the transaction are users. Design for the seller experience
  and the buyer experience with equal weight.
- Dispute resolution and safety features aren't edge cases — they're core
  flows that determine platform trust.
- Friction before commitment is good. Users want to feel safe before they
  transact, not after.

**Design priorities:** Identity verification flows, reputation systems,
messaging with safety guardrails, clear transaction states (listed, pending,
sold, disputed), dispute resolution UX, fraud detection signals in UI.

**Never:** Obscure how the platform handles problems. In C2C, users need
to know what happens if something goes wrong before they commit to anything.

---

## C2B — Consumer to Business

**User relationship to the product:** Individual consumers offer something of
value to businesses — services, skills, content, data, or feedback. Freelance
platforms, influencer marketplaces, UGC platforms, survey/research panels,
and gig economy tools all follow this model.

**Key behavioral shifts:**
- The consumer is the supplier. They have a seller mindset — they're evaluating
  whether the platform gives them fair value, visibility, and control over
  what they offer.
- Power asymmetry is visible and felt. The business (buyer) typically has
  structural advantages — the platform design must signal fairness to the
  consumer side or they'll disengage.
- Reputation is currency. Ratings, reviews, portfolio visibility, and
  social proof aren't metadata — they're the consumer's primary asset on
  the platform. Design them as such.
- Payout experience is the most emotionally loaded moment. Payment timing,
  clarity of fees, and ease of withdrawal are trust-critical.

**Design priorities:** Clear earnings dashboards, transparent fee structures,
portfolio/profile control, rating and review visibility, payout flow clarity,
notification design for new opportunities, and simple proposal or application flows.

**Never:** Obscure platform fees until after work is submitted. Make the
consumer's profile or portfolio hard to find. Design payouts as an afterthought.

---

## C2G / C2A — Consumer to Government / Consumer to Administration

**User relationship to the product:** Citizens interacting with government
or administrative bodies — submitting applications, filing taxes, reporting
issues, accessing services, or participating in civic processes.

**Key behavioral shifts:**
- High-anxiety context by default. Government interactions carry stakes —
  financial, legal, or civic. Users approach with stress, not curiosity.
- Low digital literacy range. C2G products must work for the full spectrum
  of the population — not just the digitally fluent. Plain language,
  accessible design, and patient flows are baseline requirements.
- Trust in the institution is variable and often low. The UI must signal
  legitimacy: official branding, clear attribution, HTTPS, privacy statements
  at the moment of data collection.
- One chance to get it right. Many government processes have hard deadlines,
  limited submission windows, or significant consequences for errors.
  Error prevention is more important than error recovery.
- Offline and low-connectivity contexts are common. Not all citizens have
  reliable internet access — design for intermittent connectivity and
  provide clear save/resume functionality.

**Design priorities:** Plain language throughout (6th–8th grade reading level),
progress saving at every step, clear deadline and consequence communication,
accessible design (WCAG AA minimum, AAA preferred), multilingual support,
print-friendly confirmation pages, and phone/in-person alternatives at every
key step.

**Never:** Use government jargon or acronyms without explanation. Make the
process feel like it could be lost at any step. Require account creation before
allowing the user to understand what they're applying for. Design only for
desktop — mobile access is primary for many citizens.

---

## Social Commerce

**User relationship to the product:** Discovery and purchase happen within a
social context — through creator content, peer recommendations, live streams,
or social feeds. The boundary between content consumption and shopping is
intentionally blurred.

**Key behavioral shifts:**
- Purchase intent is often impulsive, not planned. The design window between
  discovery and purchase must be as short as possible — friction kills impulse.
- Social proof is structural, not decorative. The creator's credibility,
  community engagement, and peer reviews are the primary trust signals.
  Product specs are secondary.
- FOMO (Fear of Missing Out) is a real design lever — limited quantities,
  live stream exclusives, and community moments create urgency. But fake
  scarcity destroys trust permanently.
- Entertainment first, commerce second. If the content stops being
  interesting, the purchase intent disappears. Never interrupt content
  flow with heavy-handed commerce mechanics.
- The creator relationship matters more than the brand. Users are buying
  because of who recommended it, not necessarily because of the product
  alone. Design should surface and reinforce that relationship.

**Design priorities:** Frictionless in-content purchase (one tap to buy from
a post or stream), social proof integration (comments, reactions, creator
endorsement), live commerce features (real-time inventory, live chat,
exclusive offers), seamless checkout that doesn't exit the social context,
and creator analytics for commission and performance tracking.

**Never:** Force users to leave the social context to complete a purchase —
every redirect loses a percentage of intent. Use deceptive scarcity signals.
Deprioritize the creator's content in favor of product listings.

---

## When Models Overlap

Many products combine models. Apply both sets of shifts:

- **B2B2C:** See dedicated section above — the most complex overlap.
- **B2B with D2C elements:** (e.g., a SaaS with strong brand loyalty)
  Lead with B2B efficiency; layer D2C brand consistency on top.
- **B2C with C2C elements:** (e.g., marketplace with social features)
  Lead with B2C emotional design; add trust signals from C2C at transaction points.
- **B2C with Social Commerce:** Lead with content and creator relationship;
  minimize checkout friction to capture impulse intent.
- **C2B with C2C elements:** (e.g., freelance platform with peer reviews)
  Reputation system design becomes the primary UX challenge.
- **D2C with B2B buyers:** (e.g., wholesale portal) Separate the UX
  contexts entirely rather than merging them.
- **C2G with B2G elements:** (e.g., contractor submitting to government)
  Apply both the citizen anxiety model and the B2G compliance model.

