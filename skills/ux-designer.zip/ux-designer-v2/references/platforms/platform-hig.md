# Platform Reference: Apple Human Interface Guidelines (HIG)

Load this file when designing for iOS, iPadOS, macOS, watchOS, tvOS, or
visionOS. Apply these platform conventions alongside domain and commerce
model context. HIG conventions override generic UX defaults when they conflict.

---

## Core Philosophy

Apple's HIG is built on three principles: **clarity** (content is paramount,
UI recedes), **deference** (the interface serves the content, never competes),
and **depth** (visual layers and realistic motion communicate hierarchy and
position). Every design decision on Apple platforms should be traceable to
one of these three.

Users on Apple platforms have deeply ingrained mental models from years of
system-consistent interaction. Violating these models — even slightly — creates
friction that feels wrong before users can articulate why.

---

## Navigation Patterns

**iOS / iPadOS:**
- **Tab bar** for top-level navigation (max 5 items). Each tab represents a
  distinct mode of the app. Never use tabs for sequential flows.
- **Navigation stack** (push/pop) for hierarchical content. Back button always
  top-left. Users expect the back gesture (swipe from left edge) — never block it.
- **Modal sheets** for tasks that are self-contained and temporary. Full-screen
  modals for immersive tasks; bottom sheets for contextual actions.
- **Sidebar** on iPadOS for persistent navigation in complex apps (Split View).

**macOS:**
- **Toolbar** for frequently used actions. Keep it sparse — every toolbar item
  should be something users need constantly, not occasionally.
- **Sidebar** for navigation between collections or sections.
- **Menu bar** is the primary action surface — every action must be discoverable
  here, even if it's also in the UI.
- Keyboard shortcuts are mandatory for all primary actions on macOS.

---

## Interaction Conventions

**Touch (iOS/iPadOS):**
- Standard gestures are sacred: swipe to go back, pull to refresh, swipe to
  delete in lists. Never reassign these gestures to custom actions.
- Tap targets: 44×44pt minimum. The pt unit, not px — account for device scale.
- Long press reveals contextual menus (context menus). Use for secondary actions,
  not primary ones.
- Pinch to zoom is expected on any content that can meaningfully scale.

**Pointer (macOS):**
- Hover states are required — users explore with the cursor before committing.
- Right-click context menus must mirror the menu bar structure.
- Drag and drop is a primary interaction — support it wherever it makes sense.

**Keyboard (all platforms):**
- Tab key navigation must work logically through all interactive elements.
- Return/Enter submits the primary action. Escape cancels or dismisses.
- On macOS, ⌘ shortcuts for all primary actions, ⌥⌘ for secondary.

---

## Visual Language

**Typography:**
- Use San Francisco (SF Pro, SF Compact, SF Mono) as the system font. Never
  substitute a different sans-serif for body text on Apple platforms.
- Use Dynamic Type — respect user font size preferences. Size your layouts to
  accommodate the full accessibility size range, not just the default.
- Text styles (Title, Headline, Body, Caption) map to semantic roles — use them
  consistently, not arbitrarily.

**Color:**
- Use system colors (systemBlue, systemRed, etc.) for interactive elements —
  they automatically adapt to light/dark mode and accessibility settings.
- Tint color is the app's accent — apply it consistently to all interactive
  elements. Never use multiple accent colors in one app.
- Support Dark Mode — it's not optional on Apple platforms. Test every screen
  in both modes before shipping.

**Iconography:**
- SF Symbols is the system icon library — prefer it over custom icons for
  standard actions. SF Symbols automatically scale with Dynamic Type.
- Custom icons should feel consistent with SF Symbols in weight, optical size,
  and visual style.

**Spacing and layout:**
- Use the standard margin (16pt on iPhone, 20pt on iPad) as the baseline.
  Don't crowd content to the edges — the safe area insets exist for a reason.
- Respect safe areas: status bar, home indicator, Dynamic Island, notch.
  Never place interactive elements in these zones.

---

## Platform-Specific Patterns

**iOS:**
- Action sheets (bottom sheet with buttons) for destructive or multiple-choice
  actions. Destructive actions always in red, always at the bottom.
- Alerts for critical information requiring immediate attention. Two buttons
  max — cancel left, confirm right. Destructive confirm in red.
- Share sheet for sharing — never build a custom sharing flow.
- In-app purchases follow StoreKit conventions exactly — no custom payment flows.

**iPadOS:**
- Design for both portrait and landscape — iPad users rotate freely.
- Support multitasking (Split View, Slide Over) — your app must behave correctly
  at non-full-screen widths.
- Pointer support is required — hoverable, cursor-adaptive UI.
- Keyboard shortcuts panel (⌘ held) must be populated for productivity apps.

**macOS:**
- Preferences/Settings in a dedicated window, not in-app panels.
- Window resizing — your app must work at any reasonable window size.
- Services menu integration for contextual actions.
- Drag and drop between apps is a first-class feature.

**watchOS:**
- Glanceable design — information readable in 2 seconds or less.
- Digital Crown navigation for vertical scrolling lists.
- Complications are often the primary interface — design them as carefully
  as the app itself.

---

## Accessibility (Apple-Specific)

- **VoiceOver:** Every element needs a meaningful accessibility label. Group
  related elements. Test the full flow with VoiceOver enabled.
- **Dynamic Type:** Layout must not break at any font size. Use flexible
  containers, not fixed heights.
- **Reduce Motion:** Respect `UIAccessibility.isReduceMotionEnabled` — provide
  non-animated alternatives for all motion.
- **Reduce Transparency:** Respect `isReduceTransparencyEnabled` — blur and
  translucency must have opaque fallbacks.
- **Color contrast:** 4.5:1 minimum, 7:1 preferred. Never rely on color alone.

---

## What to Never Do on Apple Platforms

- **Never** use a hamburger menu on iOS — Apple has not endorsed it and users
  expect tab bars or navigation controllers.
- **Never** block the swipe-back gesture with custom gesture recognizers.
- **Never** use custom fonts for body text if they compromise readability.
- **Never** ignore Dark Mode — half your users will be in it.
- **Never** place interactive elements behind the home indicator or Dynamic Island.
- **Never** build custom alerts or action sheets — use system components.
- **Never** use Android/Material patterns on Apple platforms (floating action
  buttons, bottom navigation with icons only, snackbars).
