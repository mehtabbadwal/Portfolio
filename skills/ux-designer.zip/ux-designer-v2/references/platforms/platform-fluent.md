# Platform Reference: Microsoft Fluent Design System

Load this file when designing for Windows 11, Microsoft 365, Xbox,
Surface devices, or any Microsoft ecosystem product. Also apply when
building web apps that target enterprise Windows environments or integrate
with Microsoft 365 (Teams apps, Office add-ins, SharePoint).

---

## Core Philosophy

Fluent Design is built around five principles: **Light** (purposeful
illumination to guide focus), **Depth** (layered surfaces communicating
hierarchy), **Motion** (meaningful animation reinforcing cause and effect),
**Material** (translucent, tactile surfaces), and **Scale** (working across
devices from Surface Pen to Xbox controller to keyboard).

In practice, Fluent 2 (the current system) has evolved toward **clarity and
efficiency** — particularly for enterprise contexts. It prioritizes content
density, keyboard-first interaction, and integration with Microsoft 365's
ecosystem. The aesthetic is polished but restrained — never decorative at
the expense of productivity.

---

## Navigation Patterns

**Windows 11 / Desktop:**
- **NavigationView** (left nav panel) is the primary navigation component —
  collapsible, with top-level items and nested hierarchy support.
- **Pivot / Tab** for secondary navigation within a section.
- **Command bar** (toolbar equivalent) for contextual actions — appears at
  top or bottom depending on context.
- **Context menus** (right-click) are a primary interaction surface on Windows.
  Every meaningful action should be accessible via right-click.

**Microsoft 365 / Web:**
- Teams apps use the **Teams UI Kit** (built on Fluent) — navigation is
  constrained by the Teams shell. Don't fight the shell; extend it.
- Office add-ins work within task panes — narrow, vertical layouts with
  limited navigation. Design for the constraint.
- SharePoint web parts are placed in page grids — design for composability,
  not full-page ownership.

**Xbox / Controller:**
- **D-pad and stick navigation** between focusable elements — every
  interactive element must be reachable via controller.
- Focus visual (the highlight ring) must be visible and correctly positioned
  on every focusable element.
- **10-foot UI** — content is viewed from across a room. Minimum text size
  24px equivalent, high contrast, clear focus states.

---

## Interaction Conventions

**Keyboard (primary for enterprise):**
- Enterprise Windows users are keyboard-first. Tab through all interactive
  elements in logical order. Arrow keys navigate within components (menus,
  lists, grids).
- Access keys (Alt + letter) for menu bar and ribbon navigation.
- Shortcut keys for all primary actions — document them in tooltips.
- F6 moves between panes in multi-panel layouts.

**Mouse:**
- Hover states on all interactive elements — reveal secondary actions,
  show tooltips, indicate interactivity.
- Right-click context menus mirror the command bar.
- Drag and drop for reordering, moving, organizing.

**Touch (Surface / Windows tablets):**
- Touch targets: 40×40px minimum, 48×48px preferred.
- Swipe gestures for navigation in touch-optimized layouts.
- Pen input for drawing, annotation, and handwriting — if your app handles
  documents or images, pen support is expected.

---

## Visual Language

**Typography:**
- **Segoe UI Variable** is the Windows 11 system font — use it for all
  UI text. Segoe UI (non-variable) for Windows 10 compatibility.
- Type ramp: Caption (12px), Body (14px), Body Strong (14px/semibold),
  Subtitle (20px), Title (28px), Title Large (40px), Display (68px).
- Line height: 1.4–1.5 for body text. Tighter for headings.

**Color:**
- **Accent color** is user-defined in Windows — your app should respect it
  for interactive elements (links, selected states, focus indicators).
- Use semantic color tokens, not hardcoded hex values — they adapt to
  light/dark mode and high contrast themes automatically.
- **High Contrast** support is mandatory for enterprise and accessibility
  compliance. Test in all four HC themes (Black, White, Aquatic, Desert).

**Layering and Depth (Mica, Acrylic):**
- **Mica** material: integrates with desktop wallpaper, used for app
  backgrounds. Subtle, non-distracting.
- **Acrylic** material: blur + transparency for transient surfaces (flyouts,
  menus, tooltips). Use sparingly — not for primary content areas.
- Layer system: Base → Content → Flyout → Dialog. Each layer sits above the
  previous, communicating hierarchy through elevation and material.

**Iconography:**
- **Fluent System Icons** — the official icon library. Filled and regular
  variants. 16px, 20px, 24px, 28px, 32px, 48px sizes.
- Icons must be available in both light and dark variants.
- Never use Material or SF Symbols icons in a Fluent product.

**Corner Radius:**
- Windows 11 uses rounded corners throughout: 4px for small controls,
  8px for medium (cards, inputs), 16px for overlays and dialogs.
  Sharp corners signal legacy or intentional density.

---

## Enterprise-Specific Patterns

Fluent is the design language of Microsoft 365 — the most widely deployed
enterprise software suite. Most Fluent products live in enterprise contexts.

**Density modes:**
- Fluent supports compact, normal, and comfortable density. Enterprise users
  often prefer compact — more data visible, fewer clicks.
- Provide a density toggle or respect the system density setting.

**Data grids and tables:**
- Enterprise users live in data grids. The DataGrid component must support:
  sorting, filtering, column reordering, row selection, inline editing,
  and pagination or virtual scrolling for large datasets.
- Frozen columns and rows for large tables.
- Export to Excel is expected in any enterprise data table.

**Command bar and ribbon:**
- For document-centric apps, the ribbon (CommandBar) organizes actions into
  logical groups. Follow Microsoft 365 ribbon conventions — users have
  15+ years of muscle memory with them.
- For non-document apps, use a simpler command bar — don't over-ribbon.

**Integration points:**
- Microsoft Graph data (calendar, email, people, files) should use
  Microsoft's standard UI patterns for those entities — persona cards,
  file pickers, people pickers. Don't reinvent them.
- Single Sign-On via Microsoft Entra (Azure AD) — authentication UI must
  match Microsoft's auth flow, not custom login screens.

---

## Accessibility (Fluent / Windows)

- **Narrator** (Windows screen reader) support — test with Narrator enabled.
  Every interactive element needs an accessible name and role.
- **High Contrast** modes — four system themes, all must be tested.
- **Keyboard navigation** — full app usable without a mouse.
- **Focus indicators** — Fluent's focus rect must be visible in all themes.
- **UI Automation** — Windows accessibility API. Use standard Fluent
  components and it's handled automatically; custom components need
  explicit UI Automation support.

---

## What to Never Do on Fluent / Windows

- **Never** ignore right-click context menus — they're a primary Windows
  interaction surface.
- **Never** hardcode colors — use semantic tokens so HC modes work correctly.
- **Never** design only for mouse — keyboard-first is mandatory in enterprise.
- **Never** use iOS/HIG or Material components in a Fluent product — the
  visual language and interaction patterns conflict fundamentally.
- **Never** skip High Contrast testing — enterprise environments often
  enforce HC modes for accessibility compliance.
- **Never** build a data table without sort, filter, and export — enterprise
  users consider these table basics, not advanced features.
- **Never** fight the Teams or Office shell — extend it, don't replace it.
