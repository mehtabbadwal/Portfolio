# Platform Reference: Material Design (Google)

Load this file when designing for Android, Android tablets, Wear OS,
or any Google/Android-ecosystem product. Also apply when building
cross-platform apps where Material is the chosen design system.
Material 3 (Material You) is the current standard — Material 2 patterns
are legacy and should not be used in new products.

---

## Core Philosophy

Material Design is built on the metaphor of **physical material** — surfaces,
elevation, and light. In Material 3, this evolved toward **personal expression**:
dynamic color derived from the user's wallpaper, adaptive layouts, and emphasis
on individual customization. The system is explicitly more flexible than HIG —
it provides components and tokens, not rigid rules about every interaction.

Users on Android have significant variation in their mental models — Android is
used across a wider range of devices, manufacturers, and overlay skins than iOS.
Design for the system, but assume users have seen variations.

---

## Navigation Patterns

**Android (Phone):**
- **Navigation bar** (bottom) for top-level destinations — 3 to 5 items,
  icon + label. The Material 3 standard replaced the older bottom nav with
  the Navigation Bar component.
- **Navigation drawer** (left side) for apps with many top-level destinations
  or complex IA. Modal drawer on phone, persistent on tablet/desktop.
- **Navigation rail** for tablet layouts — vertical icon nav on the left edge.
  The rail replaces the bottom bar at larger screen sizes.
- Back navigation: Android system back button/gesture is always active. Never
  block it. Handle it correctly — popping the stack, dismissing sheets, etc.

**Android (Tablet / Foldable):**
- Use the **canonical layouts** (list-detail, supporting panel, feed) for
  adaptive design across screen sizes.
- Foldables introduce a **hinge** — never place critical content or interactive
  elements across the hinge line.
- Navigation rail + navigation drawer combination for large screens.

**Wear OS:**
- **Rotary input** (crown/bezel) for scrolling — support it on every scrollable
  surface.
- **Swipe to dismiss** (left swipe) closes the current screen — never interfere.
- Complications and tiles are often the primary interface.

---

## Interaction Conventions

**Touch:**
- **Ripple effect** on every tappable surface — it's the primary feedback
  mechanism on Material and users expect it.
- Touch targets: 48×48dp minimum. dp (density-independent pixels), not px.
- **Swipe** patterns: swipe to dismiss cards/notifications, swipe between tabs.
- Long press for multi-select mode in lists — standard Android pattern.

**Gesture navigation (Android 10+):**
- Swipe from left or right edge = system back. Don't use edge swipe for
  in-app navigation — it conflicts.
- Swipe up from bottom = home. Swipe up and hold = recent apps.
- Design around gesture navigation as the default, not button navigation.

**Keyboard (Android / ChromeOS):**
- Tab navigation through all interactive elements.
- ChromeOS users expect full keyboard shortcut support — treat it like desktop.
- Hardware keyboard presence changes layout expectations significantly on tablets.

---

## Visual Language

**Typography:**
- **Roboto** is the default system font, but Material 3 explicitly supports
  custom brand fonts. Use the type scale (Display, Headline, Title, Body, Label)
  semantically, not arbitrarily.
- Type scale roles map to UI roles — Label Small for captions, Body Large for
  primary reading content.

**Color (Material You / Dynamic Color):**
- Material 3 introduces a **dynamic color system** derived from the user's
  wallpaper. Your app should support dynamic color or provide a thoughtful
  fallback palette using the Material color roles.
- Color roles: Primary, Secondary, Tertiary, Error — plus their container
  and on-color variants. Use roles, not hardcoded values.
- Surface tones replace pure white/black surfaces — surfaces carry a subtle
  primary color tint based on elevation.
- Support both light and dark themes — dark theme is a first-class requirement
  on Android.

**Elevation and surfaces:**
- Elevation is communicated through **tonal color** in Material 3 (not shadows
  as in Material 2). Higher elevation = more primary color tint on the surface.
- Shadows still exist but are secondary signals — don't rely on them alone.

**Iconography:**
- Material Symbols is the system icon library (replacing Material Icons).
  Supports variable font axes: fill, weight, grade, optical size.
- Round, outlined, and sharp variants — choose one and apply consistently.

**Shape:**
- Material 3 has an expressive shape system: extra small (4dp) to extra large
  (28dp+) corner radius. Shape communicates component type and emphasis.
- FAB (Floating Action Button) uses large shape. Cards use medium. Chips use
  full (pill). Apply the shape scale consistently.

---

## Key Components (Material 3)

**FAB (Floating Action Button):**
- For the single most important action on a screen. One FAB per screen.
- Small FAB for compact spaces, extended FAB (icon + label) when space allows
  and the action needs clarity.
- Never use FAB for navigation — only for actions.

**Bottom Sheet:**
- Modal bottom sheet for temporary content or actions (dismissible).
- Standard bottom sheet for persistent content that coexists with the screen.
- Never use bottom sheets for navigation.

**Snackbar:**
- For brief, non-critical feedback. Single line. Optional single action.
  Auto-dismisses. Never use for errors requiring user action — use dialogs.

**Chips:**
- For filtering, selection, and input. Not for navigation or primary actions.
  Four types: assist, filter, input, suggestion — use the right type.

**Cards:**
- Elevated, filled, and outlined variants. Choose based on hierarchy and
  background surface. Never mix card types arbitrarily.

---

## Adaptive Design (Material You)

Material 3 is explicitly built for adaptive layouts across screen sizes.

- **Compact** (phone portrait): bottom navigation, single column
- **Medium** (phone landscape, small tablet): navigation rail, two columns
- **Expanded** (large tablet, desktop): navigation drawer, three columns

Design all three breakpoints. Don't design only for compact and hope it scales.

---

## What to Never Do on Material / Android

- **Never** use iOS patterns on Android: tab bar at the bottom with HIG styling,
  swipe-back navigation indicators, iOS-style alerts and action sheets.
- **Never** ignore the system back gesture — handle it at every screen and modal.
- **Never** use Material 2 components (old FAB, bottom nav, card shadows) in
  new Material 3 products.
- **Never** hardcode colors — use Material color roles so dynamic color works.
- **Never** place content across the hinge on foldables.
- **Never** design only for one screen size — adaptive layouts are required.
- **Never** use snackbars for errors that require user action.
