# Motion Designer — Claude Skill

**AI Design Skills Series by Mehtab Badwal**

A Claude skill that functions as a senior motion designer. Drop it into your Claude setup and it handles the full motion design stack — from choreography rationale to developer-ready Figma annotations, Lottie/Rive specs, and CSS code.

Built for product and UX designers who need to spec, justify, and hand off motion — not just describe it.

---

## What it covers

**UI / Product motion**
Micro-interactions, screen transitions, component animation, loading states, skeleton screens, gesture-driven motion, scroll-triggered animation, stagger choreography, and stateful animation systems.

**Brand motion**
Logo animation, brand identity motion, marketing video direction, style frame specs, and motion language documentation.

**Design system motion**
Motion token architecture, semantic naming, CSS custom properties, Figma variable structure, and multi-theme motion systems.

**Accessibility**
WCAG 2.1 compliance (2.2.2, 2.3.1, 2.3.3), `prefers-reduced-motion` implementation in CSS, React, and Lottie, and a reduce vs. remove decision table.

**AI product motion**
Dedicated rules for chat interfaces, agents, streaming output, generative content, and loading states in AI-powered products. Includes a full anti-patterns table and Claims vs. Signals audit framework.

**Domain-specific rules**
Motion defaults and constraints for 8 product domains: Healthcare, Enterprise SaaS, Fintech, E-commerce, Developer Tools, Consumer/Social, Education, and AI products.

---

## What makes it different

**Motion Claims vs. Signals** — an audit framework built into every output. Every animation makes an implicit claim about your system. This skill surfaces that claim and checks if it's true before you ship.

> A progress bar claims you know how much time is left. A typing indicator (•••) claims a person is composing. A sparkle effect on AI output claims something special was made. When the claim doesn't match reality, trust erodes — slowly, then all at once.

**Domain-aware defaults** — motion in a healthcare product and motion in a consumer social app are fundamentally different constraints. The skill applies the right register automatically once it knows what domain you're designing for.

**Haptics pairing** — motion specs for mobile include paired haptic feedback recommendations (iOS UIFeedbackGenerator and Android HapticFeedbackConstants), because on mobile, motion and haptics are co-designed.

---

## Folder structure

```
motion-designer/
├── SKILL.md                          ← Entry point. Load this as your skill.
└── references/
    ├── ui-motion.md                  ← UI patterns, timing, easing, gesture, performance
    ├── brand-motion.md               ← Brand identity and marketing motion
    ├── motion-tokens.md              ← Design system motion layer
    ├── accessibility.md              ← WCAG, reduced-motion, implementation code
    ├── ai-motion.md                  ← AI product motion rules and anti-patterns
    └── domain-motion.md              ← Domain-specific constraints by industry
```

The skill routes to the correct reference files based on what you're building. For complex requests, it loads multiple files. `accessibility.md` is always loaded on final specs. `domain-motion.md` is always loaded when the product's industry is known.

---

## How to install

1. Drop the `motion-designer` folder into your Claude skills directory (wherever your other skills live)
2. Load `SKILL.md` as the skill file — the references folder must stay alongside it
3. That's it

The skill is product-agnostic. It loads context from your brief — no hardcoded product knowledge.

---

## Example prompts

Once installed, use it naturally:

```
Spec the entrance animation for our bottom sheet modal.
Platform: iOS. Design system: yes, tokens exist.
```

```
I'm designing a streaming AI response component for our chat product.
What should the motion look like for the loading, streaming, and complete states?
```

```
We need a motion token system for our enterprise SaaS design system.
Duration scale, easing scale, and Figma variable structure.
```

```
Spec a swipe-to-complete gesture for our mobile task card.
Needs a snap-back if the user doesn't pass the threshold.
```

```
Our logo animates on load. Run a Claims audit on the current spec —
it uses a typing-dots-style pulse on the logomark while the app loads.
```

```
What are the motion rules for a fintech product?
We're about to add animated number counters to our account balance screen.
```

---

## Output formats

Every output follows a consistent structure:

1. **Motion Intent** — what the animation is doing for the user and why
2. **Choreography Map** — what moves, when, in what order, with exact timing values
3. **Output Layer** — Figma annotation spec, Lottie/Rive plain-language spec, or CSS code
4. **Reduced-Motion Fallback** — always included, no exceptions

---

## Part of the AI Design Skills Series

This skill is one of a growing set of product-agnostic Claude skills built for designers:

- UX Researcher
- PM
- UI Designer
- UX Designer
- UX Copywriter
- QA Tester
- Design System
- Stakeholder Design Review
- **Motion Designer** ← you are here

Each skill is built to work standalone or as part of an orchestrated design pipeline.

Follow along on LinkedIn → **Mehtab Badwal**

---

*Built and maintained by Mehtab Badwal. If you find issues, improve it and share back.*
