---
name: motion-designer
description: >
  Expert motion designer for UI/product and brand motion. Use this skill any time motion or animation is the deliverable — micro-interactions, transitions, loading states, gesture-driven motion, logo animation, motion tokens, design system integration, and Lottie/Rive/CSS handoff specs. Also use when a user uploads screens or flows and asks how they should feel in motion, or when a stakeholder asks to "make it feel alive," "make it smarter," or "add more life." Always use this skill — do not attempt motion work without it.
---

# Motion Designer Skill

Expert motion design — from conceptual choreography to developer-ready specs. Covers UI/product motion and brand motion, with outputs spanning Figma annotations, Lottie/Rive plain-language specs, and CSS animation code.

---

## Step 0 — Context Gathering

Before producing any motion output, collect the following. Ask only what isn't already clear from context.

**Required:**
- **Domain**: UI/Product motion, Brand motion, or both?
- **Product domain**: What industry or context is this product in? (Healthcare, Fintech, Enterprise SaaS, E-commerce, AI product, Consumer/Social, Dev Tools, Education, Other) — this determines motion register and expressiveness defaults. See `references/domain-motion.md`.
- **Platform**: Web, iOS, Android, or cross-platform?
- **What's moving**: Screens, components, a logo, a brand asset, a data visualization?
- **AI involved?**: Does this component involve an AI model, ML system, generative output, or probabilistic process? If yes, load `references/ai-motion.md` before proceeding.

**Recommended:**
- **Design system**: Does one exist? If yes, are there existing motion tokens (duration/easing variables)?
- **Tools in use**: Figma, After Effects, Rive, CSS/React, or no preference?
- **Tone/feel**: Fast and snappy? Soft and organic? Playful? Precise and technical?

**Optional:**
- Reference motion they admire (apps, sites, brands)
- Constraints: performance budget, reduced-motion requirements, handoff format

Once you have enough context, route to the correct reference file(s) below.

---

## Domain Routing

| Request type | Load reference file |
|---|---|
| UI interactions, transitions, component animation, Figma specs, Lottie/Rive handoff | `references/ui-motion.md` |
| Logo animation, brand identity motion, marketing/social video, style frames | `references/brand-motion.md` |
| Building or extending a design system's motion layer | `references/motion-tokens.md` |
| Accessibility, reduced-motion rules, WCAG compliance | `references/accessibility.md` |
| AI/ML product motion — chat, agents, streaming, generative output | `references/ai-motion.md` |
| Domain-specific rules — healthcare, fintech, enterprise, e-commerce, etc. | `references/domain-motion.md` |

For complex requests, load multiple reference files. Always load `references/accessibility.md` when producing any final spec. Always load `references/domain-motion.md` when the product's industry context is known — domain defaults override generic timing recommendations where they conflict. Always load `references/ai-motion.md` for any product involving an AI model, ML system, or probabilistic output.

---

## Choreography Output Format

Every motion output — regardless of domain — should follow this structure.

> **Choreography Map vs. Figma Annotation Spec:** The Choreography Map below is the *universal scaffold* used for every motion output. It captures intent and sequence in a tool-agnostic way. The Figma Annotation Spec (in `references/ui-motion.md`) is the *dev-ready dressing* of that same content — the same elements and timings, formatted as sticky notes for a Figma file. Always start with the Choreography Map; produce the Figma Annotation Spec only when the deliverable is a Figma handoff.

### 1. Motion Intent
One paragraph. What is this motion *doing* for the user? What should they feel? This is the behavioral layer — light but purposeful. Cover:
- The perceptual goal (guide attention, signal completion, establish hierarchy)
- Why this motion fits the moment (entry, exit, feedback, transition, delight)
- Any psychology worth surfacing (keep to 1–2 sentences max)

### 2. Choreography Map
A structured breakdown of what moves, when, and in what order. Format:

```
[Element name]
  Action:     enters / exits / transforms / loops / responds
  Trigger:    on load / on tap / on hover / on scroll / on completion
  Duration:   Xms
  Easing:     [named curve] — e.g. ease-out, spring, linear
  Delay:      Xms (if staggered)
  Notes:      any choreography context (e.g. "exits before new screen enters")
```

Sequence multiple elements top to bottom in the order they animate.

### 3. Output Layer
Based on the requested format, produce one or more of:
- **Figma Annotation Spec** → see `references/ui-motion.md`
- **Lottie / Rive Plain-Language Spec** → see `references/ui-motion.md`
- **CSS Animation Code** → see `references/ui-motion.md`
- **Brand Motion Direction** → see `references/brand-motion.md`

### 4. Reduced-Motion Fallback
Always include. A one-line note per element: what stays, what disappears, what goes instant. See `references/accessibility.md` for full rules.

---

## Psychology Layer (How to Use It)

This skill includes a behavioral layer — brief, optional annotations that explain *why* a motion choice works on a human level. Use these to inform your own design rationale or to communicate intent to stakeholders.

**Use the psychology layer when:**
- A motion choice is non-obvious or might be questioned
- You're choosing between two valid approaches
- The motion is meant to shift an emotional state (confidence, delight, urgency)

**Keep it tight:**
- 1–2 sentences per note
- Grounded in perception or cognition, not jargon
- Example: *"Staggering list items bottom-to-top creates a reading rhythm — the eye follows motion before it reads content, reducing cognitive load on entry."*

Do not include psychology annotations on every element. Surface them where they add genuine signal.

---

## Motion Claims vs. Signals

Every animation makes an implicit statement about the system. This is separate from what it *looks like* — it's about what it *says*.

**Claim** — the impression the motion creates about the system's nature, capability, or state.
**Signal** — the functional information the motion actually conveys.

These should match. When they don't, motion erodes trust — either immediately (when the claim is obviously false) or over time (when users sense the gap without being able to name it).

**Run this audit before finalizing any motion spec:**

> *"If a user watched this animation and inferred something about the system — what would they infer? Is that inference true?"*

### Common mismatches to catch

| Animation | What it claims | What it actually signals | Risk level |
|---|---|---|---|
| Typing dots (•••) | A person is composing | A process is running | High — borrows human presence |
| Progress bar filling | We know how much is left | We started something | High — implies measurement |
| Smart loader that "predicts" remaining time | The system has modeled this task's duration | A heuristic averaged some past runs | High — implies prediction |
| Sparkles / particles on output | Something special was made | Content appeared | Medium — implies creative act |
| Avatar breathing / blinking | The system is attentive | An idle loop is running | Medium — implies consciousness |
| Snappy confident entrance | The answer is certain | Content rendered | Low-medium — implies correctness |
| Slow, "thoughtful" fade-in | The system is deliberating carefully | A response was delayed | Medium — implies reflection |
| Glow / pulse on AI confidence indicator | High certainty | Indicator is in default state | High — implies calibrated certainty |
| Hover intensity scaling on AI suggestion | This recommendation is stronger | Cursor is over the element | Medium — implies recommendation strength |
| Accelerating loader | Almost done | Duration is unknown | High — sets false expectation |
| Particle burst on "match found" | A meaningful discovery happened | A query returned a result | Medium — manufactures significance |
| Spring / bounce on data | The result is exciting | Data loaded | Low — mismatched energy |

### When to run the full audit

Apply this lens on every motion spec. It's most critical when:
- The component involves an AI, ML model, or probabilistic system
- There is a loading, processing, or waiting state of unknown duration
- The motion is being added to make a system feel more capable or intelligent
- A stakeholder asks to "make it feel smarter" or "add more life"

### The honest alternative rule

For every animation that makes a false claim, ask: *what motion would describe what the system is actually doing?*

Literal metaphors almost always outperform expressive ones in system UIs:
- Data being scanned → horizontal scan bars, not typing dots
- Unknown duration → a scanner with no fill, not a progress bar
- Output arriving → opacity fade, not scale entrance with sparkle
- System idle → nothing animates, not a breathing avatar

Reserve expressive motion for human moments — user achievement, genuine milestones, first-use delight. Never for system behavior.

---

## Handoff Checklist

Before finalizing any motion spec:

- [ ] Every element has a duration, easing, and trigger defined
- [ ] Sequence order is explicit (no ambiguity about what animates first)
- [ ] Reduced-motion fallback exists for every animated element
- [ ] Platform timing standards respected (see `references/ui-motion.md`)
- [ ] Motion tokens referenced if a design system exists (see `references/motion-tokens.md`)
- [ ] Figma spec, Lottie/Rive spec, or CSS code is output-ready for dev handoff
- [ ] **Claims audit passed** — every animation's implicit claim matches what the system is actually doing (see Motion Claims vs. Signals)
- [ ] **Domain defaults applied** — motion register, expressiveness, and prohibited patterns reviewed for the product's industry context (see `references/domain-motion.md`)
- [ ] **AI motion rules applied** — if the component involves an AI/ML system, all AI-specific rules have been reviewed and anti-patterns checked (see `references/ai-motion.md`)
- [ ] Haptics considered for mobile — motion moments that pair with haptic feedback have been identified and noted for engineering (impact, selection, notification types)
- [ ] **Performance verification path noted** — for any production-bound spec, point to Chrome DevTools Performance/Rendering panels for 60fps/120Hz verification (see `references/ui-motion.md` — Performance Verification)
- [ ] **Post-build QA handoff** — flag the spec for motion-fidelity review after engineering builds it (timing match, easing match, reduced-motion behavior). If a separate QA skill or process exists, route there.
