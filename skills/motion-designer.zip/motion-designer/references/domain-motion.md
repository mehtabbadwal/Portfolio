# Domain Motion Reference

Motion design rules and defaults by product domain. Use this to calibrate motion decisions — duration, expressiveness, purpose — based on where the product lives and who uses it.

Domain context is not a style preference. It reflects real constraints: user cognitive load, trust requirements, performance expectations, and emotional register.

---

## How to Use This Reference

1. Identify the primary domain of the product from the table below
2. Read the motion principles and constraints for that domain
3. Apply them as defaults — they override generic motion recommendations where they conflict
4. If a product spans two domains (e.g. an AI-powered fintech tool), apply the *more conservative* domain's constraints as the baseline

---

## Domain Matrix

| Domain | Motion register | Expressiveness | Key constraint |
|---|---|---|---|
| **Healthcare / Medical** | Minimal, calm | Very low | Never distract from critical information |
| **Enterprise SaaS** | Functional, efficient | Low | Performance and clarity over personality |
| **Fintech / Finance** | Precise, trustworthy | Low-medium | No false progress signals on financial data |
| **AI Products** | Honest, restrained | Low-medium | See `references/ai-motion.md` |
| **E-commerce** | Responsive, rewarding | Medium | Conversion-aware — motion should reduce friction |
| **Consumer / Social** | Expressive, playful | Medium-high | Motion is part of the product personality |
| **Developer Tools** | Crisp, informative | Low | Respect workflow — no distraction |
| **Gaming / Interactive** | Dynamic, physics-heavy | High | Different timing model entirely |
| **Education / Learning** | Guiding, clear | Medium | Motion should orient, not entertain |

---

## Healthcare / Medical

**Motion register:** Calm, minimal, invisible when right.

**The core rule:** Motion near clinical or diagnostic content must never draw attention away from the information being read. A doctor scanning a lab result or a patient reviewing medication instructions cannot afford to be pulled off-task by ambient animation.

**Defaults:**
- Duration: prefer `motion-fast` (100ms) or `motion-quick` (150ms) for all UI interactions
- Easing: ease-out only — no spring, no overshoot
- Reduced-motion: treat as the effective default, not an edge case. Design for reduced-motion first, then add subtle motion as enhancement

**Prohibited patterns:**
- No looping ambient animations in any clinical view
- No decorative motion anywhere near data displays (vitals, lab values, dosage)
- No celebration animations on clinical task completion — completion of a clinical action is not a delightful moment, it's a serious one
- No motion that could be misread as a status indicator (a pulsing element near a heart rate display is a UX failure)

**Permitted patterns:**
- Fade transitions for screen/panel changes (opacity only, no translate)
- Subtle hover states on interactive elements (color/border transitions, 100ms)
- Loading indicators for data fetching — indeterminate, calm rhythm, muted color

**Accessibility note:** Users in healthcare contexts may include people under stress, people with cognitive impairment, or people using assistive technology. `prefers-reduced-motion` must be respected without exception. Flash and strobe rules (WCAG 2.3.1) are non-negotiable.

---

## Enterprise SaaS

**Motion register:** Functional, efficient. Motion should be invisible — users notice it when something is wrong, not when it's right.

**The core rule:** Enterprise users are power users in workflow. Every animation that interrupts their scan path or adds duration to a task reduces productivity. Motion earns its place by providing clarity, not personality.

**Defaults:**
- Duration: `motion-quick` (150ms) to `motion-standard` (250ms). Almost never `motion-slow`
- Easing: ease-out for entrances, ease-in for exits. No spring, no bounce
- Expressiveness: zero for functional interactions. Reserve any personality for onboarding or empty states only

**Prohibited patterns:**
- No stagger animations on dense data tables or lists — stagger adds perceived latency in data-heavy views
- No page-level decorative motion
- No loading screens with ambient animation — a spinner is enough
- No celebration animations on routine task completion (closing a ticket, updating a field)

**Permitted patterns:**
- Component entrance/exit (modals, drawers, dropdowns) with standard timing
- Status change indicators (color + icon transition on state change)
- Hover states on interactive elements
- Toast/notification entrance (slide in, 250ms)

**Performance note:** Enterprise SaaS often runs in managed browser environments on older hardware. Respect the performance budget strictly. Avoid will-change on large surfaces. Test on lower-spec machines.

---

## Fintech / Finance

**Motion register:** Precise, trustworthy, controlled.

**The core rule:** Financial products are trust products. Motion that implies false precision or manufactured confidence directly undermines the product's core value proposition.

**Defaults:**
- Duration: `motion-standard` (250ms) for transitions, `motion-fast` (100ms) for feedback
- Easing: ease-out for entrances, linear for any data-driven progress, no spring
- Number animations: be deliberate about animating financial values

**Prohibited patterns:**
- No count-up animations on financial values unless the number is actually being calculated in real time. Animating a stored account balance from 0 to $12,435.67 implies precision computation — it's a stored lookup.
- No progress bars on processes where completion timing is unknown (payment processing, fraud check, transfer clearing)
- No urgency-inducing motion (pulsing, flashing alerts) unless the situation is genuinely urgent
- No spring/bounce on anything related to money movement — the energy is wrong

**Permitted patterns:**
- Chart and data visualization transitions: values can animate when data changes (new data point entering, chart re-rendering on date range change)
- Confirmation states: checkmark or success indicator with a clean 250ms fade
- Transaction status changes: calm color + icon transition, no movement
- Loading states for financial data: indeterminate scanner, calm rhythm

**Data visualization motion:** Animating chart updates is appropriate and expected — with rules:
- Enter: new data points fade in (200ms, ease-out)
- Update: value changes interpolate smoothly (300ms, ease-in-out)
- Exit: removed data points fade out (150ms, ease-in)
- Axis changes: animate smoothly (300ms) so users can track the range shift

---

## E-commerce

**Motion register:** Responsive, rewarding, frictionless.

**The core rule:** Motion in e-commerce serves conversion. Every animated moment should either reduce cognitive effort in a decision or provide satisfying confirmation of an action. Neither decoration nor slowdown is tolerable.

**Defaults:**
- Duration: `motion-quick` (150ms) to `motion-standard` (250ms)
- Expressiveness: medium — a spring on add-to-cart is appropriate; a spring on checkout confirmation is appropriate; a spring on a filter dropdown is too much

**Key patterns:**

*Add to Cart:*
- Product image: brief scale pulse (1.0→1.05→1.0, 200ms) or fly-to-cart animation (product thumbnail travels to cart icon)
- Cart icon: badge count increments with a spring bounce (scale 1.0→1.3→1.0, 300ms)
- Confirmation toast: slides in from top-right or bottom, 250ms, ease-out

*Product Image Gallery:*
- Thumbnail to hero: crossfade (200ms) or slide depending on interaction direction
- Zoom: scale centered on cursor/touch point, 200ms, ease-out
- Swipe: follow-finger with momentum-based release (see `ui-motion.md` — gesture-driven motion)

*Checkout Flow:*
- Step transitions: slide in direction of progress (left→right for forward, right→left for back), 300ms
- Form validation feedback: field-level error (red border transition, 150ms) — no shake unless used sparingly
- Order confirmation: this is a genuine celebration moment. A checkmark animation, a brief scale entrance on the confirmation card — earned expressiveness

*Wishlist / Save:*
- Heart icon: fill animation (path draw or color fill, 250ms, spring) — this is a personal action and earns a small delight moment

---

## Developer Tools

**Motion register:** Crisp, informative. Motion serves orientation and feedback, never aesthetics.

**The core rule:** Developers are keyboard-first users in high-focus states. Animation that adds duration to a workflow or distracts from terminal output, code, or logs is actively harmful.

**Defaults:**
- Duration: `motion-fast` (100ms) to `motion-quick` (150ms) for everything
- Easing: ease-out. Linear for any process indicator
- Respect `prefers-reduced-motion` aggressively — developer tools users skew toward this preference

**Prohibited patterns:**
- No stagger on file trees, search results, or list outputs
- No entrance animations on code output or terminal responses — content should appear at native render speed
- No decorative loading screens
- No celebration animations on builds, deploys, or test passes (a subtle checkmark is appropriate; a burst of confetti is not)

**Permitted patterns:**
- Tab switch: content crossfade (100ms), no slide
- Dropdown / command palette: scale + fade entrance (150ms)
- Status changes: color/icon transition (100ms)
- Notification/toast: slide in (150ms), stays, fades out (100ms)
- Inline diff animation: highlight fade-in on changed lines (150ms)

---

## Consumer / Social

**Motion register:** Expressive, personal, emotionally resonant.

**The core rule:** In consumer and social products, motion is part of the personality. Users feel the difference between a product that moves with life and one that doesn't. This is the domain where spring physics, staggered lists, and delight moments are fully earned — but purposefulness still applies.

**Defaults:**
- Duration: `motion-standard` (250ms) to `motion-deliberate` (350ms) for key interactions
- Easing: spring physics for interactive moments, ease-out for standard transitions
- Expressiveness: medium-high for identity-driven moments, standard for functional UI

**Key patterns:**

*Social reactions / likes:*
- Icon: spring scale (1.0→1.4→1.0, 300ms) + color fill
- Count: number increments with a vertical slide (previous number exits up, new number enters from below, 200ms each)

*Feed / content entrance:*
- Cards load with stagger (30–40ms offset), fade + translate-Y (8px→0), 250ms
- Max stagger chain: 400ms. Beyond that, show content without stagger

*Stories / full-screen transitions:*
- Entrance: scale from thumbnail origin (hero animation from card), 350ms, ease-out
- Exit: reverse, 250ms, ease-in

*Profile / identity moments:*
- Avatar upload confirmation: spring pulse, checkmark overlay
- Achievement / milestone: this is the domain where confetti, particles, and celebration animations are fully appropriate — but scoped to the achievement moment only

---

## Education / Learning

**Motion register:** Guiding, clear, paced to support comprehension.

**The core rule:** Motion in educational products should aid learning — directing attention, confirming understanding, and making abstract concepts concrete. It should never compete with the content being learned.

**Defaults:**
- Duration: `motion-standard` (250ms) to `motion-deliberate` (350ms)
- Easing: ease-out for entrances; ease-in-out for repositioning (content is often rearranging to teach)
- Expressiveness: medium — use delight for correct answers and progress milestones; keep it functional elsewhere

**Key patterns:**

*Correct answer / quiz feedback:*
- Positive: green highlight + subtle scale (1.0→1.03→1.0) + checkmark entrance, 300ms
- Incorrect: red highlight + gentle shake (error shake pattern from `ui-motion.md`) — brief, not punishing

*Progress indicators:*
- Progress bars are appropriate here because progress is real and measurable
- Animate on increment: smooth fill (500ms, ease-out) — the slowness is intentional, it makes progress feel meaningful

*Concept reveal / step-by-step:*
- Stagger is appropriate for sequenced content — each step or concept arrives in order (50ms offset)
- This mirrors the pedagogical pace of instruction

*Streak / achievement:*
- Earned. This is a genuine emotional milestone in learning. Spring animation, brief celebration — scoped tightly to the achievement moment.

---

## Domain Routing Quick Reference

When a request comes in, identify domain first:

```
Is this a clinical/healthcare tool?          → Apply Healthcare defaults
Is this an internal enterprise product?      → Apply Enterprise SaaS defaults
Is this handling financial transactions?     → Apply Fintech defaults
Is this AI-powered (chat, generation)?       → Apply AI Motion (references/ai-motion.md)
Is this an online store or marketplace?      → Apply E-commerce defaults
Is this a code editor or dev workflow tool?  → Apply Developer Tools defaults
Is this a consumer app or social product?    → Apply Consumer/Social defaults
Is this a learning or training product?      → Apply Education defaults
Spans two domains?                           → Use the more conservative domain as baseline
```
