# Brand Motion Reference

Covers logo animation, brand identity in motion, marketing/social video, style frames, and After Effects direction. Used when the motion work is expressive, brand-driven, or intended for video/broadcast rather than UI interaction.

---

## Brand Motion vs. UI Motion

| Dimension | UI Motion | Brand Motion |
|---|---|---|
| Purpose | Guide, inform, confirm | Express, impress, emote |
| Duration | 150–500ms | 500ms–10s+ |
| Easing | Functional, physics-grounded | Expressive, stylized |
| Loop | Rare, purposeful | Common, intentional |
| Output | Figma spec, Lottie, CSS | MP4, GIF, After Effects comp |
| Feel | Invisible when right | Noticed and remembered |

Brand motion has *personality*. It's allowed to be slow, dramatic, bouncy, or weighted in ways UI motion never should be.

---

## Motion Personality Framework

Before designing brand motion, establish the motion personality. This maps to the brand's character:

| Personality | Motion traits | Avoid |
|---|---|---|
| **Confident / Premium** | Slow, weighty, minimal bounce, long ease-outs | Fast cuts, excessive elements |
| **Energetic / Playful** | Fast, springy, staggered chaos, overshoots | Static, too-smooth, formal |
| **Warm / Approachable** | Gentle eases, soft scale, organic paths | Sharp cuts, rigid geometry |
| **Technical / Precise** | Linear progress, exact timing, no overshoot | Softness, organic curves |
| **Bold / Disruptive** | Snap cuts, high contrast timing, unexpected | Predictability, softness |

*Psychology note: Motion personality triggers emotional priming before a word is read. A logo that snaps into place signals precision; one that bounces in signals approachability. Audiences form micro-impressions in under 200ms.*

---

## Logo Animation Framework

Logo animations follow a sequence of decisions:

### 1. Reveal Strategy
How does the logo *arrive*?

| Strategy | Description | Good for |
|---|---|---|
| **Draw on** | Strokes draw in, filled shapes fade after | Logos with strong line work |
| **Assemble** | Parts arrive from different directions, compose | Geometric logos, letterforms |
| **Emerge** | Scales up or fades from center | Simple, symbol-driven logos |
| **Transform** | Morphs from a shape or icon into the logo | Animated idents, openers |
| **Cascade** | Elements arrive one by one in sequence | Wordmarks, letter-by-letter |

### 2. Hold Duration
After reveal, the logo holds still before any exit. Hold = 500ms minimum. For social/marketing, 1–2 seconds.

### 3. Exit Strategy
- For looping: crossfade back to first frame
- For ident: fade to black or cut
- For web: stay visible (no exit)

### 4. Timing Structure
```
Logo animation duration breakdown (example: 2-second ident):
  0ms–800ms    → Reveal (elements arrive)
  800ms–1500ms → Hold (logo fully visible)
  1500ms–2000ms → Exit (fade or cut)
```

---

## Style Frame Direction

Style frames are static images that define the visual language of a motion piece *before* animation begins. They're used to align with stakeholders early.

When producing style frame direction, describe:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━
STYLE FRAME DIRECTION — [Project Name]
━━━━━━━━━━━━━━━━━━━━━━━━━━

FRAME 1: Opening / Establishing
  Visual:       [Describe what's on screen — background, key element, typography]
  Color:        [Primary palette in use]
  Typography:   [Font, weight, size, position]
  Mood:         [1–2 adjectives that describe the feel of this frame]

FRAME 2: Core Message / Product Moment
  Visual:       [Describe the hero element — screenshot, illustration, icon, etc.]
  Motion hint:  [How does this element arrive or behave?]
  Mood:         [How does this feel different from or build on Frame 1?]

FRAME 3: End Card / Closer
  Visual:       [Logo position, CTA if any, background state]
  Hold:         [How long should this hold before end?]

TONE DIRECTION:
  [2–3 sentences on the overall aesthetic — lighting, texture, motion energy]
━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## After Effects Composition Direction

When producing direction for an After Effects motion designer (or for your own After Effects work), use this format. This is conceptual direction, not a technical comp setup guide.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━
AE COMPOSITION DIRECTION — [Project Name]
━━━━━━━━━━━━━━━━━━━━━━━━━━
Canvas: [e.g. 1920×1080 / 1080×1080 / 9:16]
FPS: 30 (or 60 for premium/fluid feel)
Duration: [total seconds]
Color space: sRGB (web) / Rec.709 (broadcast)

SCENE SEQUENCE:

Scene 1 — [Name, e.g. "Logo Reveal"]
  Duration:     0:00–0:03
  Key elements: [list layers/elements visible]
  Motion:       [how they move — e.g. "logo draws on via stroke, then fills with brand color"]
  Easing feel:  [e.g. "ease out, weighted, not bouncy"]
  Music/SFX:    [if applicable — e.g. "soft rise, no percussion"]

Scene 2 — [Name, e.g. "Feature Highlight"]
  Duration:     0:03–0:07
  Key elements: [product screenshots, text, icons]
  Motion:       [e.g. "screens slide in from right, text fades up with 40ms stagger per line"]
  Transition:   [how scene 1 exits — crossfade / cut / wipe]

OVERALL DIRECTION:
  [2–3 sentences: energy level, color behavior, typographic animation style, what to avoid]

EXPORT:
  Format: H.264 MP4 (web), ProRes 422 (broadcast/client master)
  Sizes: 1×, and [any additional cuts — 9:16, 1:1, etc.]
━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Marketing & Social Motion Formats

| Format | Dimensions | Duration | Key constraint |
|---|---|---|---|
| Instagram Feed | 1080×1080 | 3–15s | No audio assumed |
| Instagram Story / Reel | 1080×1920 | 5–15s | Safe zones: 250px top/bottom |
| LinkedIn | 1920×1080 or 1:1 | 3–30s | Autoplays muted |
| Twitter/X | 1280×720 | 2–30s | Autoplay muted |
| YouTube Intro | 1920×1080 | 3–5s | Must not delay content |
| Email GIF | 600px wide | 2–5s | Keep under 2MB |
| Web Hero | Any (16:9 or full-bleed) | Loops 5–10s | Performance critical |

**Muted autoplay rule:** All marketing motion must communicate without audio. Motion, typography, and visual rhythm carry the message — sound is an enhancement, not a dependency.

---

## Storyboard Format (Text-Based)

When visual storyboards aren't available, use this text-based structure to communicate narrative motion:

```
STORYBOARD — [Project Name]

[00:00–00:02] — BEAT 1: Brand Entry
  On screen:    Background color fills frame from center
  Text:         None
  Motion:       Radial scale from center, ease-out, 800ms
  Feeling:      Confident, quiet arrival

[00:02–00:05] — BEAT 2: Product Moment
  On screen:    Product screenshot appears, slight shadow
  Text:         Headline slides up from below
  Motion:       Screenshot: scale 0.9→1, ease-out, 400ms
                Headline: translateY(20px)→0 + fade, ease-out, 350ms, 200ms delay
  Feeling:      Clarity, product confidence

[00:05–00:07] — BEAT 3: Close
  On screen:    Logo + tagline
  Text:         CTA or URL if needed
  Motion:       Logo fades in, 400ms. Tagline follows, 200ms delay.
  Feeling:      Resolved, memorable
```

---

## Brand Motion Checklist

Before finalizing brand motion direction:

- [ ] Motion personality established and consistent throughout
- [ ] Logo animation has: reveal strategy, hold duration, exit strategy
- [ ] Style frames described for key moments
- [ ] Duration fits platform format
- [ ] Muted autoplay considered for social formats
- [ ] Export formats specified (web vs. broadcast vs. social)
- [ ] Reduced-motion version noted (static frame or short opacity fade)
