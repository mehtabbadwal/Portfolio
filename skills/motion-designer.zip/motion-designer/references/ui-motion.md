# UI Motion Reference

Covers micro-interactions, transitions, component animation, platform timing standards, and developer handoff formats for product/UI motion work.

---

## Glossary (Quick Reference)

For designers newer to motion. Skip if these are familiar.

| Term | What it means |
|---|---|
| **Easing** | The curve that describes how an animation accelerates or decelerates over its duration. The same start and end state can feel different depending on whether the change is linear, eases out, or springs. |
| **Ease-out** | Decelerates into the end state. Feels natural for things *arriving* (modals, dropdowns). |
| **Ease-in** | Accelerates out of the start state. Feels natural for things *leaving*. |
| **Ease-in-out** | Symmetric — slow at both ends, fast in the middle. Feels natural for repositioning. |
| **Linear** | No acceleration. Steady rate. Used for loops (spinners, progress fills) where any curve would feel mechanical. |
| **Spring** | Physics-based curve with a slight overshoot before settling. Feels playful, organic. Use sparingly. |
| **Keyframe** | A defined point in an animation timeline (start, end, or any in-between). The browser/runtime tweens between keyframes. |
| **Stagger** | Sequential delay applied across multiple elements so they animate one after another, not all at once. |
| **Tween** | The interpolated frames between two keyframes. Short for "in-between." |
| **Choreography** | The full plan for how a set of elements moves together — what moves first, what overlaps, what waits. Motion at the *system* level. |
| **Lottie** | A JSON-based animation format, typically authored in After Effects and exported via the Bodymovin plugin. Best for one-shot animations like loaders or success states. |
| **Rive** | An interactive animation tool with state machines and runtime inputs. Best for stateful UI animations (toggles, multi-state loaders). |
| **Smart Animate** | Figma's prototype transition feature that auto-tweens between matching layers across frames. Not a motion language — a prototyping shortcut. |
| **Compositor / GPU layer** | The browser's optimization layer for cheap animations. Animating `transform` and `opacity` stays on the GPU; animating `width` or `top` does not, and causes jank. |
| **prefers-reduced-motion** | An OS-level user preference declaring that animation should be reduced or removed. A direct accessibility signal — must be respected. |

---

## Platform Timing Standards

| Platform | Fast | Standard | Complex | Max recommended |
|---|---|---|---|---|
| **iOS** | 200ms | 300ms | 400ms | 500ms |
| **Android** | 200ms | 300ms | 400ms | 500ms |
| **Web (desktop)** | 150ms | 250ms | 350ms | 400ms |
| **Web (mobile)** | 200ms | 300ms | 400ms | 500ms |

**Rule of thumb:** If an animation feels too slow, cut 50ms. If it feels jarring, add 50ms and soften the easing.

---

## Easing Reference

### Named Curves (CSS-ready)

| Name | CSS value | Use case |
|---|---|---|
| **Ease Out** | `cubic-bezier(0.0, 0.0, 0.2, 1)` | Elements entering — decelerates into position |
| **Ease In** | `cubic-bezier(0.4, 0.0, 1, 1)` | Elements leaving — accelerates out of view |
| **Ease In-Out** | `cubic-bezier(0.4, 0.0, 0.2, 1)` | Repositioning — smooth symmetric arc |
| **Standard** | `cubic-bezier(0.2, 0.0, 0, 1.0)` | General purpose, Material Design standard |
| **Spring (approx)** | `cubic-bezier(0.34, 1.56, 0.64, 1)` | Slight overshoot, iOS-feel, use for delight |
| **Linear** | `linear` | Looping animations, progress bars |

### Psychology note
*Ease-out feels natural on entry because it mirrors how physical objects decelerate — they arrive with diminishing energy. Ease-in on exit mirrors acceleration away from rest. Matching motion physics to mental models reduces cognitive friction.*

---

## Common UI Motion Patterns

### Entrance Patterns
- **Fade in**: opacity 0→1, ease-out, 200–250ms. Use for overlays, tooltips, contextual UI.
- **Slide up + fade**: translateY(12px)→0 + opacity 0→1, ease-out, 250–300ms. Use for bottom sheets, drawers, modals.
- **Scale up + fade**: scale(0.95)→1 + opacity 0→1, ease-out, 200–250ms. Use for dropdowns, popovers, cards.
- **Slide in from edge**: translateX(100%)→0, ease-out, 300–350ms. Use for navigation panels, sheets.

### Exit Patterns
Exit should always be faster than entrance — 70–80% of the entrance duration.
- **Fade out**: opacity 1→0, ease-in, 150–200ms.
- **Slide down + fade**: translateY(0)→12px + opacity 1→0, ease-in, 200ms.
- **Scale down + fade**: scale(1)→0.95 + opacity 1→0, ease-in, 150–200ms.

### Feedback Patterns
- **Success pulse**: scale(1)→scale(1.05)→scale(1), ease-in-out, 300ms total. Subtle confirmation.
- **Error shake**: translateX: 0 → -6px → 6px → -4px → 4px → 0, linear, 400ms. Use sparingly.
- **Loading spin**: rotate 360deg, linear, 800ms, infinite. Use for indeterminate states.
- **Progress fill**: width 0→X%, ease-out or linear depending on real vs. estimated progress.

### Transition Patterns
- **Page/screen transition**: outgoing fades + slides out (ease-in, 200ms), incoming fades + slides in (ease-out, 300ms). Overlap by 50–100ms for continuity.
- **Tab switch**: content crossfades (150ms), selected indicator slides (ease-in-out, 200ms).
- **Accordion expand**: max-height 0→auto + opacity 0→1, ease-out, 250–300ms.
- **Stagger list**: each item delays by 30–50ms, total stagger chain should not exceed 400ms.

---

## Figma Annotation Spec Format

When producing a Figma motion spec, use this annotation format — it's designed to be placed as sticky notes or an annotation layer on the mockup:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━
MOTION SPEC — [Component/Screen Name]
━━━━━━━━━━━━━━━━━━━━━━━━━━

[Element 1: e.g. Modal overlay]
  Trigger:    On CTA tap
  Action:     Fade in
  Duration:   250ms
  Easing:     Ease Out (cubic-bezier 0.0, 0.0, 0.2, 1)
  Properties: opacity 0 → 1

[Element 2: e.g. Modal card]
  Trigger:    On CTA tap (50ms after overlay)
  Action:     Slide up + fade
  Duration:   300ms
  Easing:     Ease Out
  Properties: translateY(16px) → 0, opacity 0 → 1

[Element 3: e.g. Modal content]
  Trigger:    After card reaches position
  Action:     Fade in
  Duration:   200ms
  Easing:     Ease Out
  Properties: opacity 0 → 1

EXIT:
[All elements]: Reverse order, ease-in, 70% of entrance duration.

Reduced motion: All animations → instant opacity toggle only.
━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Figma Smart Animate note:** Use "Smart Animate" in Figma prototype transitions. Set duration in the transition panel. For staggered sequences, use component variants with separate connection arrows, each with its delay baked in.

---

## Lottie Plain-Language Spec

Lottie is JSON-based animation typically authored in After Effects and exported via the Bodymovin plugin, or created directly in LottieFiles. When writing a Lottie spec for a developer or motion designer, use this format:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━
LOTTIE SPEC — [Animation Name]
━━━━━━━━━━━━━━━━━━━━━━━━━━
Canvas: [e.g. 400×400px]
Frame rate: 60fps (or 30fps for simpler animations)
Duration: [total ms / frames]
Loop: Yes / No / [X times]

LAYER SEQUENCE (top to bottom = front to back):

Layer 1: [Name, e.g. "checkmark-stroke"]
  Type:       Shape layer / Image / Text
  Animation:  Stroke draw from 0% to 100%
  Frames:     0–30 (500ms at 60fps)
  Easing:     Ease out (handle: out=0.2,0 / in=1,1)
  Notes:      Stroke width 3px, color #FFFFFF

Layer 2: [Name, e.g. "circle-fill"]
  Type:       Shape layer
  Animation:  Scale 0 → 1, opacity 0 → 1
  Frames:     10–40 (offset 10 frames from layer 1)
  Easing:     Spring overshoot (out=0.34,1.56 / in=0.64,1)
  Notes:      Circle 48px diameter, fill #22C55E

NOTES FOR DEVELOPER:
- Import via @lottiefiles/lottie-player or lottie-web npm package
- Set autoplay: true, loop: false
- Trigger on [event — e.g. form submit success]
- Reduced motion: hide entirely, show static checkmark icon instead
━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Rive Plain-Language Spec

Rive is used for interactive, stateful animations — particularly strong for animations that respond to user input, game states, or UI states.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━
RIVE SPEC — [Animation Name]
━━━━━━━━━━━━━━━━━━━━━━━━━━
Artboard: [name, e.g. "Toggle Switch"]
Dimensions: [e.g. 80×40px]

STATE MACHINE: [e.g. "Toggle States"]

States:
  OFF (default)     → thumb left, track grey
  ON                → thumb right, track green
  HOVER             → subtle scale 1.0→1.02 on thumb

Transitions:
  OFF → ON
    Trigger:     On tap / click
    Duration:    250ms
    Easing:      Ease in-out
    Properties:  thumb translateX(0→32px), track color #9CA3AF→#22C55E

  ON → OFF
    Trigger:     On tap / click
    Duration:    200ms
    Easing:      Ease in-out
    Properties:  Reverse of above

  Any → HOVER
    Trigger:     On hover enter
    Duration:    100ms
    Easing:      Ease out

Inputs (for developer):
  Boolean: "isOn" → drives OFF↔ON transition
  Trigger: "hover" → drives hover state

NOTES FOR DEVELOPER:
- Use @rive-app/react-canvas npm package
- Expose "isOn" boolean as a prop
- Reduced motion: disable transitions, snap to final state immediately
━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## CSS Animation Code Format

When generating CSS animations, always output:
1. The keyframe block
2. The animation property applied to the element
3. A `prefers-reduced-motion` override

### Template:

```css
/* ── [Animation name] ── */
@keyframes fadeSlideUp {
  from {
    opacity: 0;
    transform: translateY(12px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.element-entering {
  animation: fadeSlideUp 300ms cubic-bezier(0.0, 0.0, 0.2, 1) both;
}

/* Reduced motion fallback */
@media (prefers-reduced-motion: reduce) {
  .element-entering {
    animation: none;
    opacity: 1;
    transform: none;
  }
}
```

For React, use inline `style` with a `useReducedMotion` hook or the `motion` prop from Framer Motion when that library is in use.

---

## Stagger Logic

When animating lists, grids, or sequential elements:

- **Stagger offset:** 30–50ms per item
- **Max total stagger:** 400ms (8–10 items max before it feels slow)
- **Direction:** top-to-bottom or left-to-right mirrors natural reading order
- **Easing:** each item uses the same easing; the stagger is delay-based only

```css
.item:nth-child(1) { animation-delay: 0ms; }
.item:nth-child(2) { animation-delay: 40ms; }
.item:nth-child(3) { animation-delay: 80ms; }
/* etc. */
```

*Psychology note: Sequential stagger creates a perception of order and hierarchy. Items that arrive in sequence feel intentionally organized, not randomly placed — this reduces the cognitive work of parsing a list.*

---

## Scroll-Triggered Animation

Rules for animations that trigger on scroll:

- **Threshold:** trigger when 15–20% of the element is visible (IntersectionObserver threshold: 0.15)
- **Animation:** always entrance-style (fade + translate), never exit on scroll-up unless intentional
- **Duration:** same as standard entrance (250–350ms)
- **Performance:** use `transform` and `opacity` only — never animate `width`, `height`, `top`, `left` (these cause layout reflow)
- **Reduced motion:** remove all scroll animations; elements should be visible by default

```javascript
// IntersectionObserver pattern
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
    }
  });
}, { threshold: 0.15 });
```

---

## Gesture-Driven Motion

Gesture-driven animation is fundamentally different from trigger-based animation: the motion follows the user's input in real time, with no fixed duration or easing curve during the gesture itself. Duration and easing only apply *after* the gesture releases.

This pattern is critical for mobile UX. It should be designed as an interaction model, not a traditional animation spec.

### Core Principle: Follow the Finger

While a gesture is active, the animated element tracks the input 1:1 — no easing, no delay. Easing applies only on release (settle, snap-back, or fling).

### Drag / Pan

```
Active gesture:
  - Element follows touch point 1:1 (no timing, no easing)
  - Optional: apply a resistance multiplier if dragging past a boundary
    (e.g. 0.4× movement past threshold = rubber band feel)

On release:
  - If threshold met → complete the action (dismiss, reorder, reveal)
    Duration: 250–300ms, ease-out
  - If threshold not met → snap back to origin
    Duration: 200ms, spring (cubic-bezier 0.34, 1.56, 0.64, 1)
```

**Threshold guidance:** 40–50% of the element width/height for destructive or irreversible actions; 25–30% for reversible ones.

### Swipe-to-Dismiss / Swipe-to-Action

```
Active swipe:
  - Element translates with touch, 1:1
  - Reveal action layer underneath as element moves (background opacity scales 0→1 as offset increases)

On release — dismiss:
  - Velocity threshold met (>300px/s) OR displacement threshold met (>50% width)
  - Element exits at swipe velocity: calculate remaining distance ÷ velocity, cap at 300ms
  - Easing: ease-in (accelerates out of view)

On release — snap back:
  - Neither threshold met
  - Spring back to origin: 250ms, spring easing
  - Action layer fades out: 150ms, ease-in
```

**Reduced motion:** Snap-back and dismiss should be instant. Remove all reveal animation.

### Fling / Momentum Scrolling

Fling extends the gesture past release using a deceleration curve, not a fixed duration.

- **Deceleration factor:** 0.95 per frame (5% velocity loss per frame at 60fps) — tune to feel
- **Friction boundary:** When the element reaches a boundary (edge of list, end of scroll), apply resistance and spring back
- **Snap points:** If the surface has defined snap positions (carousels, page-based navigation), calculate the nearest snap point from fling velocity and animate to it: duration based on remaining distance at a comfortable speed (200–400ms, ease-out)

```javascript
// Simplified fling deceleration
function applyFling(velocity, position, bounds) {
  let v = velocity;
  function tick() {
    v *= 0.95; // deceleration
    position += v;
    if (Math.abs(v) < 0.5) return; // stop
    if (position < bounds.min || position > bounds.max) {
      // spring back from boundary
    }
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}
```

### Overscroll / Rubber Banding

When content is dragged past its bounds, resistance increases proportionally to distance.

- **Resistance formula:** `offset × 0.4` — movement is 40% of input past boundary
- **Spring back on release:** 400ms, spring easing (the extended position needs extra energy to return)
- **Visual:** The surface stretches slightly; nothing underneath is revealed unless intentional (pull-to-refresh)

### Pinch-to-Zoom

```
Active gesture:
  - Scale origin: midpoint between two touch points (updated continuously)
  - Scale: 1:1 with finger spread ratio
  - Min/max clamp: enforce scale bounds (e.g. 0.5× min, 4× max)

On release:
  - If within valid range: stop at current scale (no settle animation)
  - If below min or above max: spring back to nearest bound, 300ms, spring easing
```

**Note:** Scale origin must update as fingers move — a fixed origin creates a jarring pivot shift. This requires tracking the midpoint per frame.

---

## Haptic Feedback Pairing

On iOS and Android, motion and haptics are co-designed. Every significant animated moment on mobile should be evaluated for a haptic counterpart — together they form a complete sensory response.

Haptics are never added to web (desktop). On mobile web, the Vibration API exists but should be used sparingly and only where it matches native convention.

### iOS — UIFeedbackGenerator Types

| Type | When to use | Motion pairing |
|---|---|---|
| **Impact — Light** | Small UI interactions: toggle on, item select | Spring scale on icon/toggle |
| **Impact — Medium** | Drag snap, swipe-to-action threshold | Snap settle on release |
| **Impact — Heavy** | Destructive confirms, force-press activations | Bold entrance on action sheet |
| **Selection** | Scrolling through picker values, changing selection | Per-item highlight transition |
| **Notification — Success** | Task complete, payment confirmed, upload done | Checkmark entrance animation |
| **Notification — Warning** | Non-critical alert, recoverable error | Amber state transition |
| **Notification — Error** | Failed action, form error | Error shake / color transition |

### Android — HapticFeedbackConstants

| Constant | Equivalent to |
|---|---|
| `VIRTUAL_KEY` | Light impact on tap |
| `KEYBOARD_TAP` | Selection feedback |
| `LONG_PRESS` | Heavy impact on hold |
| `CONFIRM` | Success notification |
| `REJECT` | Error notification |
| `GESTURE_START / GESTURE_END` | Drag initiation and release |

### Pairing Rules

- **Never add haptics without motion** — a haptic with no visual response feels broken
- **Never add motion without considering haptics** — on mobile, a motion-only response feels incomplete for significant interactions
- **Destructive actions require both** — swipe-to-delete, confirm-to-clear: the combination of motion + haptic makes the weight of the action legible
- **Delight moments earn both** — a streak, a milestone, an achievement: motion + success haptic creates a memorable moment
- **Routine interactions should stay silent** — scrolling a list, tapping a tab, opening a drawer: no haptic unless the platform convention expects one

### Spec format addition

Add a haptics line to the Choreography Map when relevant:

```
[Element name]
  Action:     enters / settles / snaps
  Trigger:    on swipe release at threshold
  Duration:   250ms
  Easing:     spring
  Haptic:     Impact — Medium (iOS) / GESTURE_END (Android)
  Notes:      fire haptic at moment of snap, not at gesture start
```

---

## Performance Constraints

Animation performance directly affects product quality. A 60fps animation that causes jank or layout reflow is worse than no animation. These rules are non-negotiable for production motion work.

### The Compositing Model

Browsers and native rendering engines offload certain CSS properties to the GPU compositor. Animating these properties is cheap and smooth. Animating everything else causes the CPU to recalculate layout or paint, which drops frames.

**Safe to animate (GPU composited):**
- `transform` (translate, scale, rotate)
- `opacity`

**Never animate these (causes layout reflow or repaint):**
- `width`, `height`, `top`, `left`, `right`, `bottom`
- `padding`, `margin`
- `border-width`
- `font-size`
- `background-color` *(repaint, not reflow — but still costly on large elements)*

If a design requires a size change (e.g. expanding a card), use `transform: scaleY()` as a visual approximation rather than animating `height`.

### `will-change`

`will-change` promotes an element to its own compositor layer before animation begins, reducing the cost of the first animated frame.

```css
/* Apply before animation starts */
.modal {
  will-change: transform, opacity;
}

/* Remove after animation ends — orphaned layers waste GPU memory */
.modal.animation-complete {
  will-change: auto;
}
```

**Use sparingly.** Overusing `will-change` consumes GPU memory and can cause worse performance than not using it. Apply only to elements about to animate, and remove it afterward.

### 60fps vs. 120Hz

Modern iOS devices (ProMotion) and high-refresh Android screens run at 120Hz. At 120fps, each frame is 8ms (vs. 16ms at 60fps).

**Timing implications:**
- Animations designed for 60fps may feel slightly slow at 120Hz — the same duration covers more visual distance
- Spring animations particularly benefit from 120Hz — they feel noticeably more fluid
- No changes required for CSS/Lottie — these adapt to display refresh rate automatically
- Rive natively supports 120Hz rendering

**Perception note:** Users on 120Hz devices who downgrade to 60fps notice the difference immediately. Avoid capping animations at 60fps on high-refresh devices.

### Animation Performance Budget

| Context | Frame budget | Guideline |
|---|---|---|
| Mobile web | Strict — 16ms/frame | `transform` + `opacity` only. No shadows during motion. |
| Native iOS / Android | Relaxed | Platform compositor handles more. Still prefer transform/opacity. |
| Desktop web | Standard — 16ms/frame | More latitude, but same rules apply |
| Low-spec devices | Conservative | Reduce simultaneous animated elements. Stagger less. |

**Testing rule:** Always test animations on a mid-range device (e.g. iPhone SE, mid-tier Android), not just your development machine. 

### Detecting Jank

Watch for these symptoms during testing:
- **Frame drops:** visible stuttering, especially on scroll-triggered or stagger animations
- **Layout thrashing:** JS reading layout properties (offsetWidth, getBoundingClientRect) inside an animation loop — always read before writing, never interleave
- **Compositor layer explosion:** too many `will-change` elements simultaneously — use browser DevTools → Layers panel to inspect

---

## Skeleton / Shimmer Loading Patterns

Skeleton screens are the preferred loading pattern for content-heavy UIs. They communicate structure before content arrives, reducing perceived wait time and preventing layout shift.

### When to Use Skeleton vs. Spinner

| Use skeleton | Use spinner |
|---|---|
| Content has a known structural shape (cards, lists, profiles) | Content shape is unknown until loaded |
| Load time is expected to be 300ms–3s | Action is near-instant (<300ms) or very long (>5s) |
| Multiple content regions loading simultaneously | Single small action |
| The loaded state is visually complex | Simple feedback is sufficient |

### Skeleton Design Rules

- **Match the real content shape** — skeleton blocks should approximate the height, width, and position of the content they represent. Generic full-width bars do not reduce layout shift; accurate skeletons do.
- **Never use exact dimensions** — slight variation in skeleton block sizes (e.g. some lines at 70% width, some at 90%) looks more natural and avoids the "identical bars" uncanny valley.
- **Color:** Use `background-color` at surface +1 tone — in light mode, slightly darker than page background; in dark mode, slightly lighter. Never use brand colors on skeletons.
- **No text in skeletons** — the skeleton represents text, it does not contain it.

### Shimmer Animation

Shimmer is a light sweep across the skeleton surface, communicating that loading is active.

```css
/* Shimmer keyframe */
@keyframes shimmer {
  from {
    background-position: -200% 0;
  }
  to {
    background-position: 200% 0;
  }
}

.skeleton {
  background: linear-gradient(
    90deg,
    var(--skeleton-base) 25%,
    var(--skeleton-highlight) 50%,
    var(--skeleton-base) 75%
  );
  background-size: 200% 100%;
  animation: shimmer 1400ms ease-in-out infinite;
}
```

**Direction:** Always left to right. This matches reading direction (LTR) and feels natural. For RTL interfaces, reverse the direction.

**Timing:** 1200–1600ms per cycle. Faster feels frantic; slower feels broken.

**Easing:** `ease-in-out` for a smooth wave. Avoid `linear` — it creates a mechanical feel.

### Transition from Skeleton to Content

When content loads, the transition should feel like a reveal, not a replacement:

```
Skeleton → Content transition:
  Duration:   200ms
  Pattern:    Skeleton fades out (opacity 1→0, ease-in, 150ms)
              Content fades in (opacity 0→1, ease-out, 200ms, 50ms delay)
  No layout shift: content must occupy the same space as the skeleton during transition
```

**Avoid a hard swap** — skeleton disappearing and content appearing simultaneously creates a flash. The 50ms overlap softens this.

### Reduced Motion

Under `prefers-reduced-motion`: remove the shimmer animation entirely. The skeleton itself (static colored blocks) remains visible — the structure is still useful, even without motion.

```css
@media (prefers-reduced-motion: reduce) {
  .skeleton {
    animation: none;
    background: var(--skeleton-base); /* static, no gradient */
  }
}
```

---

## Stateful Animation Systems

When a component has **3 or more distinct states** that transition into each other (loading → slow → success/failure, idle → active → complete → error), treat it as a **state machine** — not a collection of independent animations.

This distinction matters because:
- Transitions between states need to be choreographed, not just the states themselves
- Exit from one state should set up the entrance of the next
- The full emotional arc across all states needs to cohere

### When to identify a stateful system

Trigger this pattern when the request mentions:
- Loading, retrieving, fetching + multiple outcomes
- Multi-step flows (onboarding, checkout, form submission)
- Real-time data (dashboards, live feeds, status indicators)
- AI assistant or agent UX (thinking, responding, erroring)
- Any component described as having "states"

### State machine choreography structure

Before designing individual state animations, map the full machine:

```
STATE MAP

States:        IDLE → INVOKED → LOADING → SLOW → SUCCESS
                                        ↘           FAILURE
                                         → ERROR ↗

For each state, define:
  Visual:      What is visible and how does it look?
  Motion:      What is actively animating?
  Emotional tone: What should the user feel?

For each transition, define:
  Exit:        How does the outgoing state leave?
  Bridge:      Is there overlap or a clean cut?
  Entrance:    How does the incoming state arrive?
  Duration:    Total transition time (exit + entrance, accounting for overlap)
```

### CSS limitation: animation-duration cannot be tweened

CSS `animation-duration` cannot be transitioned smoothly. Changing it via class swap or JS causes an abrupt rhythm reset, not a smooth slowdown.

**Workaround options by fidelity level:**

| Fidelity | Approach | Best for |
|---|---|---|
| Prototype / web artifact | Swap CSS class (animation restarts, rhythm changes abruptly) | Demos, stakeholder reviews |
| Production CSS | Use `animation-play-state` + opacity crossfade between two overlapping animations | Simple cases, web only |
| Production interactive | JavaScript `requestAnimationFrame` loop controlling opacity directly | Full rhythm control in browser |
| Production (recommended) | **Rive state machine** — native smooth transitions between animation speeds | Apps, dashboards, any stateful UI |

**Rule:** If a motion design calls for a rhythm change mid-animation (e.g. a loading indicator slowing down to signal a delay), flag it in the spec with: *"Requires Rive or JS RAF — CSS class swap will cause an abrupt reset, acceptable for prototypes only."*

### State machine tool recommendation

For any stateful animation system with 3+ states and smooth transitions between them, **Rive is the recommended production tool**. It natively supports:
- State machines with boolean/trigger/number inputs
- Smooth transitions between animation timelines
- Blend states (transitioning between two speeds without cutting)
- Developer inputs that map directly to real system state

See `SKILL.md` for Rive plain-language spec format.
---

## Tone Vocabulary

When describing or naming motion feel, use consistent language:

| Feel | Characteristics |
|---|---|
| **Snappy** | Short duration (100–200ms), ease-out, no overshoot |
| **Smooth** | Standard duration (250–350ms), ease-in-out, no bounce |
| **Springy** | Spring physics or cubic-bezier with slight overshoot |
| **Soft** | Longer duration (350–500ms), gentle ease, low energy |
| **Crisp** | Instant or near-instant (0–100ms), linear or ease-out |
| **Expressive** | Longer arcs, personality, used sparingly for delight moments |

Use this vocabulary when writing the Motion Intent paragraph or briefing a stakeholder. Pair the feel word with the context — *"snappy on hover, soft on entrance"* — so the reader can hear the rhythm before reading the timing values.

---

## Prototyping Tools

When the design is past the spec stage and you need to *show* the motion — to a stakeholder, to engineering, or to test it on yourself — pick the right tool for the fidelity needed.

| Tool | Best for | Output | Fidelity |
|---|---|---|---|
| **Figma Smart Animate** | Quick demos of screen-to-screen transitions, simple component states | In-Figma prototype | Low–medium. Curves are limited; no real spring physics; cannot tween animation rhythm. Fine for stakeholder reviews, weak for production parity. |
| **Framer** | Web-targeted prototypes with real CSS-grade motion, scroll-driven animation, gesture-driven interactions | Live web URL or React code export | High. Closest to production web behavior. Native support for spring physics, gestures, scroll triggers. |
| **Origami Studio** | Complex stateful interactions, multi-input gesture systems, native iOS-feel prototypes | macOS prototype (no web export) | High for native feel. Steeper learning curve. Strong for one-off interaction studies, weak for cross-functional sharing. |
| **ProtoPie** | Cross-platform interaction prototypes with sensor inputs (tilt, voice, conditional logic), shareable to mobile | Mobile preview app, web link | High. Best for prototypes that need to *feel* like a real app on a real device. |
| **Principle** | Quick interaction studies on macOS, animation timeline approach | macOS / video export | Medium. Lighter than Origami, heavier than Smart Animate. Smaller community now. |
| **Web artifact (HTML/React)** | Demonstrating one specific motion in isolation, embedded in a doc or slide | HTML/JSX file | Production-grade. Use this when motion *is* the deliverable, not the prototype. |

### Web Artifact Generation

When the user wants to prototype or experiment on the web, generate a working artifact (React JSX or HTML/CSS) that demonstrates the motion. This is the fastest path from idea to preview when production parity matters more than tool ergonomics.

**Artifact defaults:**
- React: use Tailwind for layout, inline keyframes or `style` props for animation
- HTML: use CSS `@keyframes` and `animation` shorthand
- Keep it self-contained — no external animation libraries unless user requests (Framer Motion, GSAP, etc.)
- Include a `prefers-reduced-motion` media query in all CSS output

Offer this proactively when the request sounds experimental ("I want to try...", "what would it look like if...", "can we test...").

### Tool selection rule of thumb

- **Stakeholder review of a flow** → Figma Smart Animate
- **Production-parity web motion** → Framer or web artifact
- **Native iOS-feel interaction study** → Origami
- **On-device mobile prototype with sensors** → ProtoPie
- **Documenting a single motion in a doc/slide** → web artifact (HTML/CSS)

For motion specs intended for engineering handoff, the prototype is *supplementary*. The spec is the source of truth. A prototype that drifts from the spec is a bug in the prototype.

---

## Performance Verification

A motion spec that hits 60fps in design preview but drops frames in production is a failed spec. Build verification into the handoff, not the post-mortem.

### Chrome DevTools — Performance Panel

The Performance panel records what the browser actually did frame by frame. For motion verification:

1. Open DevTools → Performance tab
2. Click record, trigger the animation, stop recording
3. Look at the **Frames** track at the top
   - Green bars = frames within budget
   - Yellow bars = frames at risk
   - Red bars = dropped frames

**What to verify:**
- No red frames during the animation window
- No long yellow streaks at the start or end (entrance/exit jank)
- The "Main" thread isn't doing layout work mid-animation (search for purple "Layout" or green "Paint" blocks during the animated frames — these mean an expensive property is being animated)

### Chrome DevTools — Rendering Panel

The Rendering panel exposes real-time rendering overlays. For motion verification, three matter:

| Overlay | What it shows | What to watch for |
|---|---|---|
| **Frame Rendering Stats (FPS meter)** | Live FPS counter, GPU memory usage | FPS drops below 60 (or 120 on ProMotion) during the animation |
| **Paint Flashing** | Highlights any region the browser repainted | If paint flashing fires during a `transform` or `opacity` animation, something else is repainting alongside — likely a sibling element or a costly shadow |
| **Layer Borders** | Outlines GPU-composited layers | Confirms `will-change` is doing what you expect. If the animated element doesn't get its own layer, the GPU optimization isn't applying. |

### What to flag in the spec

For any motion bound for production, add a Performance Verification line to the spec:

```
PERFORMANCE VERIFICATION
━━━━━━━━━━━━━━━━━━━━━━━━
Target:        60fps minimum (120fps on ProMotion devices)
Verify with:   Chrome DevTools Performance panel — record + check Frames track
                Rendering panel — Paint Flashing should not fire during animation
                Test on:  mid-tier device (e.g. iPhone SE, mid-range Android)
                          NOT just dev machine
Expected GPU layers: [list elements that should be on their own compositor layer]
━━━━━━━━━━━━━━━━━━━━━━━━
```

**Rule:** Never sign off on a production motion spec without on-device verification. A dev machine animation hitting 60fps says nothing about a 3-year-old Android phone in a real user's hand.
