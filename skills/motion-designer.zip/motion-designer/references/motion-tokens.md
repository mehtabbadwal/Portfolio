# Motion Tokens Reference

How to define, structure, and integrate motion tokens into a design system. Covers duration scales, easing tokens, Figma variables, CSS custom properties, and integration with component libraries.

---

## What Are Motion Tokens?

Motion tokens are named, reusable values for animation properties — duration, easing, and delay. They work exactly like color or spacing tokens: instead of hardcoding `300ms ease-out` everywhere, you reference `--motion-standard` and `--ease-enter`.

**Why they matter:**
- Consistency across components without memorizing values
- Single source of truth — change one token, update everywhere
- Enables theming (a "playful" theme could swap the whole easing set)
- Handoff clarity — developers reference tokens, not magic numbers

---

## Duration Scale

A standard 6-step duration scale covers the full range of UI motion needs:

| Token name | Value | Use case |
|---|---|---|
| `motion-instant` | 0ms | State snaps, reduced-motion fallback |
| `motion-fast` | 100ms | Hover states, small feedback, tooltips |
| `motion-quick` | 150ms | Micro-interactions, icon swaps |
| `motion-standard` | 250ms | Most UI transitions — entrances, exits |
| `motion-deliberate` | 350ms | Complex transitions, page-level motion |
| `motion-slow` | 500ms | Expressive moments, first-load reveals |

**Rule:** Default to `motion-standard`. Go faster for small or peripheral elements. Go slower only for intentional focal moments.

---

## Easing Scale

A standard set of 6 easing tokens:

| Token name | CSS value | Use case |
|---|---|---|
| `ease-enter` | `cubic-bezier(0.0, 0.0, 0.2, 1)` | Elements entering the screen |
| `ease-exit` | `cubic-bezier(0.4, 0.0, 1, 1)` | Elements leaving the screen |
| `ease-standard` | `cubic-bezier(0.4, 0.0, 0.2, 1)` | Repositioning, bidirectional |
| `ease-spring` | `cubic-bezier(0.34, 1.56, 0.64, 1)` | Playful, elastic, delight moments |
| `ease-linear` | `linear` | Progress bars, spinners, loops |
| `ease-none` | `none` / `step-start` | Instant snaps, reduced motion |

---

## CSS Custom Properties

```css
:root {
  /* Duration */
  --motion-instant:    0ms;
  --motion-fast:       100ms;
  --motion-quick:      150ms;
  --motion-standard:   250ms;
  --motion-deliberate: 350ms;
  --motion-slow:       500ms;

  /* Easing */
  --ease-enter:    cubic-bezier(0.0, 0.0, 0.2, 1);
  --ease-exit:     cubic-bezier(0.4, 0.0, 1, 1);
  --ease-standard: cubic-bezier(0.4, 0.0, 0.2, 1);
  --ease-spring:   cubic-bezier(0.34, 1.56, 0.64, 1);
  --ease-linear:   linear;

  /* Composite tokens — duration + easing pairs */
  --transition-enter:    var(--motion-standard) var(--ease-enter);
  --transition-exit:     var(--motion-quick) var(--ease-exit);
  --transition-standard: var(--motion-standard) var(--ease-standard);
}

/* Usage */
.modal {
  transition: opacity var(--transition-enter),
              transform var(--transition-enter);
}
```

---

## Figma Variables Setup

Motion tokens in Figma use the **Variables** panel (number type for duration, string type for easing).

### Recommended variable structure:

```
Collection: Motion
├── Group: Duration
│   ├── motion/instant      → 0
│   ├── motion/fast         → 100
│   ├── motion/quick        → 150
│   ├── motion/standard     → 250
│   ├── motion/deliberate   → 350
│   └── motion/slow         → 500
│
└── Group: Easing (string variables)
    ├── ease/enter          → "cubic-bezier(0.0, 0.0, 0.2, 1)"
    ├── ease/exit           → "cubic-bezier(0.4, 0.0, 1, 1)"
    ├── ease/standard       → "cubic-bezier(0.4, 0.0, 0.2, 1)"
    ├── ease/spring         → "cubic-bezier(0.34, 1.56, 0.64, 1)"
    └── ease/linear         → "linear"
```

**Note:** Figma doesn't yet apply easing variables to prototype transitions natively — use string variables as reference/documentation values. Duration variables can be referenced in Figma plugin workflows or used for spec annotation.

---

## Design System Integration

When integrating motion tokens into an existing design system, follow this sequence:

### Step 1 — Audit existing motion
- Identify every animated component in the system
- Note all hardcoded duration/easing values in use
- Flag inconsistencies (e.g. modals at 200ms, drawers at 350ms, tooltips at 150ms)

### Step 2 — Map to token scale
- Which existing values map cleanly to the proposed token scale?
- Which are outliers that need to be brought in line?
- Document any intentional exceptions with rationale

### Step 3 — Token documentation page
Every design system needs a motion token documentation page. Include:
- The full token table (name, value, use case)
- Live examples of each easing curve (Figma prototype or embedded CodePen)
- Do/don't examples for common misuse patterns
- Reduced-motion section (see `accessibility.md`)

### Step 4 — Component annotation
For each existing component, add a motion annotation:
- Which token is used for which property
- Trigger conditions
- Reduced-motion behavior

---

## Token Naming Conventions

Follow semantic naming (what it means) over literal naming (what the value is):

| ✅ Semantic | ❌ Literal |
|---|---|
| `motion-standard` | `motion-250ms` |
| `ease-enter` | `ease-out-fast` |
| `motion-deliberate` | `motion-complex` |

Semantic names survive value changes. If `motion-standard` needs to shift from 250ms to 300ms, the name remains valid. `motion-250ms` becomes a lie.

---

## Motion Theming (Advanced)

If the design system supports multiple themes (e.g. default, playful, enterprise), motion tokens can be themed:

```css
/* Default theme */
:root {
  --motion-standard:   250ms;
  --ease-standard:     cubic-bezier(0.4, 0.0, 0.2, 1);
}

/* Playful theme */
[data-theme="playful"] {
  --motion-standard:   300ms;
  --ease-standard:     cubic-bezier(0.34, 1.56, 0.64, 1); /* spring */
}

/* Enterprise / reduced theme */
[data-theme="enterprise"] {
  --motion-standard:   150ms;
  --ease-standard:     cubic-bezier(0.4, 0.0, 0.2, 1);
}
```

*This means motion personality can be a design system decision, not a per-component decision.*
