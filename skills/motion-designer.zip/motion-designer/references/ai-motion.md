# AI Motion Reference

Motion design rules for AI-powered product interfaces — assistants, agents, generative outputs, and probabilistic systems. This reference applies whenever motion is being designed for a component that involves an AI model, ML system, or any non-deterministic process.

Read alongside `references/ui-motion.md` and always run the Claims vs. Signals audit from `SKILL.md` on every AI motion spec.

---

## The Foundational Rule: Don't Lie With Motion

AI systems are probabilistic, asynchronous, and often uncertain. Motion design must reflect that reality — not paper over it with borrowed human metaphors.

The single most common failure mode in AI product motion is **anthropomorphizing system behavior**: making a model feel like a thinking, aware, attentive person when it is running a computation. This erodes trust as soon as the gap between the claim and reality becomes apparent — and it always does.

**Default principle:** Motion in AI UIs should describe what the system is *actually doing*. Reserve expressive motion for genuine human moments — user achievement, first-use delight, successful task completion.

---

## The 5 AI Motion States

Every AI interaction has a recognizable set of states. Design motion for all of them — not just the loading and response states.

| State | What's happening | Motion goal |
|---|---|---|
| **Idle** | System is ready, waiting for input | Quiet presence — nothing animates unless purposeful |
| **Invoked** | User has submitted input, system acknowledged | Immediate feedback that input was received |
| **Processing** | Model is running | Honest indication of unknown duration |
| **Slow / Delayed** | Processing is taking longer than expected | Transparent signal that something is still happening |
| **Streaming** | Output is arriving token by token | Guide attention to arriving content without distraction |
| **Complete** | Output is finished | Clear, calm resolution — signal completion without fanfare |
| **Error / Failure** | Something went wrong | Direct, non-alarming error state — no apology theatrics |

Design the full arc as a state machine (see `ui-motion.md` — Stateful Animation Systems). The transitions between states matter as much as the states themselves.

---

## State-by-State Motion Rules

### Idle
- **Nothing should animate** in the idle state unless it serves a direct functional purpose.
- A breathing avatar, pulsing logo, or ambient particle effect communicates false attentiveness. The system is not "listening" — it is waiting for an HTTP request.
- If the input area needs to signal readiness, use a static visual (cursor, border highlight) rather than looping motion.

### Invoked
- Animate immediately on submit — within one frame (16ms).
- Input area should give clear visual feedback: border color change, subtle scale (1.0→0.98), or text fade. Duration: 100–150ms, ease-out.
- This is functional motion. Keep it snappy and certain.

### Processing (Unknown Duration)
- Use a **scanner** or **indeterminate indicator** — not a progress bar.
- A horizontal scan bar (left→right loop), a pulsing dot sequence with no fill level, or a simple spinner communicate "running" without implying known duration.
- **Do not use a fill-based progress bar** unless you have real-time data on completion percentage. Fill implies measurement.
- Loop timing: 1200–1600ms per cycle, linear easing. Slow enough to not feel frantic.

### Slow / Delayed
- If processing exceeds ~6–8 seconds, the motion should shift to signal patience — not urgency.
- Slow the indicator rhythm (increase loop duration by 30–40%). This is a perceptual cue that the system is doing something substantial, not struggling.
- **CSS limitation:** Cannot smoothly tween `animation-duration`. Use Rive state machine or JS `requestAnimationFrame` for smooth rhythm transitions. Flag in spec if CSS only.
- Add a text cue at ~10 seconds: "Still working…" or equivalent. Motion alone is not enough for long waits.

### Streaming Output
- As tokens arrive, **new content should enter softly** — opacity fade, 150ms, ease-out. No scale, no translate.
- Avoid animating every token individually — batch into short chunks (every 100–200ms of arrival) to reduce visual noise.
- The cursor or end-of-stream indicator should be the focal animation, not the content itself.
- **Do not use a typewriter effect** if the output is arriving in real-time. Typewriter simulates character-by-character arrival; streaming is already character-by-character. Adding animation on top creates false pacing.
- If the output is a complete block rendered at once (non-streaming), a fade-in over 200–250ms is the appropriate entrance.

### Complete
- Resolve cleanly and quietly. The indicator stops — no celebration, no flourish.
- If there is a copy button, rating control, or action tray: fade these in after content is complete (150ms delay, 200ms fade, ease-out). Don't introduce them mid-stream.
- Reserve any form of "success" motion (checkmark, pulse) for user-initiated actions that have a definitive success state — not for model output, which is inherently uncertain.

### Error / Failure
- Replace the indicator with a static error state immediately. No lingering animation.
- Error message entrance: opacity fade, 200ms, ease-out. No shake — the shake implies the user did something wrong. In AI UIs, errors are typically system failures.
- If it's a recoverable error (retry), animate the retry button into view (slide up + fade, 250ms) as a prompt to act.

---

## Streaming Output: Detailed Rules

Streaming is a distinct motion problem because the animation is driven by data rate, not a designer's timing values.

**Rendering approach:**
- Render incoming tokens as plain text, no animation per token
- Apply a CSS `animation: fadeIn 150ms ease-out both` to each new paragraph block or message chunk
- Keep the animated unit large (paragraph, not word, not character)

**The cursor:**
- A blinking cursor (|) at the end of the stream is acceptable and conventional
- Blink rate: 500ms on / 500ms off, or match the OS default cursor blink
- Remove cursor when stream is complete — snap to hidden, no fade

**Scroll behavior:**
- Auto-scroll to follow output as it streams — but only if the user is already at the bottom
- If the user has scrolled up to read, stop auto-scrolling immediately
- Animate the scroll: `scroll-behavior: smooth` or `scrollTo({ behavior: 'smooth' })`

---

## Common AI Motion Anti-Patterns

| Anti-pattern | Why it fails | Honest alternative |
|---|---|---|
| **Typing indicator (•••)** | Claims a person is composing | Indeterminate scanner; dots without human framing |
| **Progress bar with unknown duration** | Claims measurement exists | Scanner, loop, or open-ended pulse |
| **Sparkles / glitter on output** | Claims the result is special or magical | Simple fade; reserve celebration for user milestones |
| **Breathing / blinking avatar** | Claims consciousness and attentiveness | Static avatar; animate only on direct interaction |
| **Typewriter on streaming output** | Simulates what is already real — creates double simulation | Plain text rendering with soft block fade |
| **Accelerating loader near completion** | Claims the system knows it's almost done | Constant rhythm throughout unknown-duration processes |
| **Confidence-implying entrances** | Bold scale entrance implies the answer is certain | Soft opacity entrance; scale is for things the system is sure of |
| **"Thinking" imagery (gears, brain)** | Anthropomorphizes computation | Abstract, non-metaphorical processing indicators |

---

## AI Motion by Component Type

### Chat / Conversational Interface
- **User message:** enters immediately, no animation (already on screen from input)
- **AI response container:** fades in at 150ms as stream begins, so there's a visual anchor
- **Streaming text:** plain rendering, paragraph-level fade only
- **Action tray (copy, rate, share):** deferred — fades in after completion

### Agent / Multi-Step Task UI
- **Step entering:** fade + slide-up (200ms, ease-out)
- **Step in progress:** subtle pulse or scan on the active step indicator only
- **Step complete:** checkmark resolves at 250ms, next step activates with a 100ms delay
- **Step failed:** indicator changes color, error icon fades in — no shake
- Treat the full task as a state machine, not a list of independent animations

### Generative Content (Image, Code, Document)
- **Loading state:** scanner or abstract placeholder — not a content preview that may be wrong
- **Content reveal:** fade in at 250ms once fully generated. Do not reveal partial outputs with animation — wait for the complete artifact
- **Regenerate action:** previous content fades out (150ms, ease-in), loading state enters (50ms delay), new content fades in

### Suggestion / Autocomplete
- **Dropdown entrance:** scale(0.97)→1 + opacity 0→1, ease-out, 150ms
- **Item highlight:** background color transition, 100ms, ease-out
- **Acceptance:** input field updates instantly, suggestion list fades out (100ms)
- No stagger on suggestion items — they should feel immediately available, not choreographed

### Confidence / Uncertainty Signals
- If the system exposes confidence levels (high/low certainty on an answer), motion can reflect this:
  - **High confidence:** standard entrance (250ms, ease-out)
  - **Low confidence:** slightly softer, slower entrance (350ms, ease-out) + visual treatment (muted color, disclaimer)
- Never use motion alone to signal confidence — always pair with a text or visual indicator

---

## AI Motion Checklist

- [ ] Every processing state uses an indeterminate indicator (no fill-based progress unless real data)
- [ ] No typing dots unless a human is literally composing
- [ ] Streaming output renders at paragraph/chunk level, not token level
- [ ] Idle state has no looping ambient animation
- [ ] No sparkles, particles, or celebration motion on AI-generated output
- [ ] Error state resolves to static immediately — no lingering animation
- [ ] Complete state resolves quietly — action tray deferred until after stream ends
- [ ] Any rhythm change (slow → very slow) is flagged for Rive or JS — not CSS class swap
- [ ] Claims audit passed (see `SKILL.md`) — every animation's implicit claim matches system reality
- [ ] Reduced-motion fallback documented for all AI states
