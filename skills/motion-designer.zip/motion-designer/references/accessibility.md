# Motion Accessibility Reference

Rules, patterns, and WCAG compliance for accessible motion design. This section applies to every motion output — UI or brand, CSS or Lottie.

---

## The Core Rule

**If a user has requested reduced motion at the OS level, respect it without question.**

The `prefers-reduced-motion` media query reflects a user's explicit system preference. It's triggered by:
- macOS: System Settings → Accessibility → Reduce Motion
- iOS: Settings → Accessibility → Motion → Reduce Motion
- Android: Settings → Accessibility → Remove Animations
- Windows: System → Ease of Access → Show animations

This is not a "nice to have." It's a direct accessibility signal.

---

## WCAG 2.1 — Relevant Success Criteria

| Criterion | Level | What it means for motion |
|---|---|---|
| **2.2.2 Pause, Stop, Hide** | AA | Any motion that starts automatically, lasts more than 5 seconds, and is presented in parallel with other content must be pausable, stoppable, or hideable |
| **2.3.1 Three Flashes or Below Threshold** | AA | No content should flash more than 3 times per second |
| **2.3.3 Animation from Interactions** | AAA | Motion triggered by interaction can be disabled unless it's essential to the functionality |

**For most product work, AA compliance is the standard. Target it at minimum.**

---

## prefers-reduced-motion: Patterns

### CSS Implementation

```css
/* Default: animation on */
.element {
  animation: fadeSlideUp 300ms cubic-bezier(0.0, 0.0, 0.2, 1) both;
  transition: opacity 250ms ease-out, transform 250ms ease-out;
}

/* Reduced motion: remove movement, keep opacity */
@media (prefers-reduced-motion: reduce) {
  .element {
    animation: none;
    transition: opacity 150ms ease-out; /* Fade is acceptable */
    transform: none;
  }
}

/* Strict: remove all animation */
@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```

### React / JS Implementation

```javascript
// Hook to detect reduced motion preference
function useReducedMotion() {
  const [reducedMotion, setReducedMotion] = useState(
    window.matchMedia('(prefers-reduced-motion: reduce)').matches
  );
  
  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const handler = (e) => setReducedMotion(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);
  
  return reducedMotion;
}

// Usage
const reducedMotion = useReducedMotion();
const animationProps = reducedMotion
  ? { opacity: 1 }
  : { opacity: [0, 1], y: [12, 0] };
```

### Lottie Implementation

```javascript
// Check preference before playing
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

if (!reducedMotion) {
  lottiePlayer.play();
} else {
  // Show static final frame or hide animation entirely
  lottiePlayer.goToAndStop(lottiePlayer.totalFrames - 1, true);
}
```

---

## What to Reduce vs. What to Remove

Not all motion should be treated the same way under reduced-motion preferences:

| Motion type | Reduced-motion treatment | Rationale |
|---|---|---|
| Page/screen transitions | Remove translate, keep opacity fade | Spatial movement causes disorientation; fade is safe |
| Entrance animations | Remove translate + scale, keep opacity | Movement triggers vestibular issues; opacity is neutral |
| Loading spinners | Replace with static indicator or pulse | Continuous rotation is high-risk |
| Progress bars | Keep (linear, purposeful) | Functional motion — communicates real progress |
| Hover states | Keep opacity/color transitions | Small, direct feedback — expected and safe |
| Stagger animations | Collapse to simultaneous | Sequential motion amplifies effect |
| Lottie animations | Go to final frame or hide | Depends on content — assess case by case |
| Background motion / parallax | Remove entirely | High vestibular risk |
| Auto-playing video/loops | Pause | Meets WCAG 2.2.2 |
| Error shake | Replace with color change + icon | Rapid lateral movement is high-risk |

---

## Vestibular Disorders: The Higher Bar

Some users have vestibular disorders (inner ear conditions affecting balance and spatial perception). For them, motion — especially parallax, rotation, zooming, and rapid directional changes — can cause nausea, dizziness, or headaches.

**High-risk motion types:**
- Parallax scrolling
- Large-scale zoom animations
- Rotation (especially continuous)
- Motion that covers large screen distances
- Simultaneous multi-directional motion

**Design principle:** Default to subtle motion. Reserve large, expressive motion for intentional moments. Always offer a path out via `prefers-reduced-motion`.

---

## Flicker and Flash

**Hard rule:** Nothing on screen should flash or strobe more than **3 times per second**.

This is both a WCAG 2.3.1 requirement and a seizure prevention standard. Applies to:
- Animated GIFs
- Loading animations
- Notification badges
- Video content
- Particle effects

If you're creating a loading or celebration animation, verify frame rate and flash frequency before shipping.

---

## Reduced-Motion Spec Format

Include this in every motion spec output:

```
REDUCED MOTION FALLBACK
━━━━━━━━━━━━━━━━━━━━━━━━
[Element name]     → [What happens: instant / opacity only / static / hidden]
[Element name]     → [What happens]
[Element name]     → [What happens]

Implementation:    CSS @media (prefers-reduced-motion: reduce)
                   or useReducedMotion() hook in React
                   or Lottie: goToAndStop(finalFrame)
━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Accessibility Checklist

- [ ] `prefers-reduced-motion` handled in all CSS animation and transition blocks
- [ ] No element flashes more than 3 times per second
- [ ] Auto-playing animations longer than 5s have a pause mechanism (WCAG 2.2.2)
- [ ] Reduced-motion fallback documented in every motion spec
- [ ] Lottie/Rive animations have a reduced-motion code path
- [ ] Background/decorative motion is removed entirely under reduced-motion
- [ ] No motion conveys information that isn't also available in a static state
- [ ] High-risk motion types (parallax, rotation, zoom) have been flagged and assessed
